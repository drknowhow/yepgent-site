"""``yepgent tools`` — installed-tool operations, incl. OAuth (Model B, T6.8).

Subcommands::

    yepgent tools auth <tool> [--device-code]   authorize a tool's OAuth (loopback;
                                                --device-code for headless)
    yepgent tools auth <tool> --status          show auth status (NEVER tokens)
    yepgent tools auth <tool> --logout          forget the tool's stored tokens

Client model is **user-supplied** (PLAN.md §6 decision): the first time you
authorize a tool, you paste the ``client_id`` / ``client_secret`` from your OWN
Google Cloud (or other provider) OAuth client — see ``docs/oauth-google-setup.md``.
That client + the resulting tokens live in your OS keyring; nothing is shipped or
phoned home, and no token is ever printed.
"""

from __future__ import annotations

import argparse
import getpass
import sys
import time


def _loader():
    from local_yep.toolspace import loader as ml

    return ml


def _oauth():
    from local_yep.toolspace import oauth

    return oauth


def _prompt_client(tool_id: str) -> tuple[str | None, str | None]:
    """Prompt for a user-supplied OAuth client. Returns (client_id, client_secret)
    or (None, None) on abort. Seam: tests monkeypatch this."""
    print(
        f"\n{tool_id} needs a Google-style OAuth client that YOU own.\n"
        "Create one (OAuth client type: Desktop app) in your provider's console "
        "and paste it here — see docs/oauth-google-setup.md.\n",
        file=sys.stderr,
    )
    try:
        client_id = input("  client_id: ").strip()
        client_secret = getpass.getpass("  client_secret (hidden, may be blank for PKCE-only): ")
    except (EOFError, KeyboardInterrupt):
        print("\nAborted — nothing stored.", file=sys.stderr)
        return None, None
    if not client_id:
        print("No client_id given — aborted.", file=sys.stderr)
        return None, None
    return client_id, (client_secret or None)


def _cmd_auth(args: argparse.Namespace) -> int:
    ml = _loader()
    oauth = _oauth()
    from local_yep import secrets as credstore

    tool_id = args.tool
    auth = ml.get_installed_auth(tool_id)
    if auth is None:
        installed = {e["tool_id"] for e in ml.list_installed()}
        if tool_id not in installed:
            print(f"Tool {tool_id!r} is not installed.", file=sys.stderr)
        else:
            print(f"Tool {tool_id!r} declares no OAuth `auth` block — use "
                  f"`yepgent secrets set {tool_id} <NAME>` for key/env-var tools.",
                  file=sys.stderr)
        return 2

    if getattr(args, "status", False):
        return _print_status(tool_id, auth, oauth)
    if getattr(args, "logout", False):
        oauth.forget_tokens(tool_id)
        print(f"Forgot stored tokens for {tool_id}. Run `yepgent tools auth {tool_id}` to re-authorize.")
        return 0

    if not credstore.keyring_available():
        print(
            "Cannot store OAuth tokens: no OS keyring backend is available.\n"
            "Install the extra (`pip install 'local-yep[secrets]'`) or, on a "
            "headless host, a Secret Service.",
            file=sys.stderr,
        )
        return 2

    # Ensure a user-supplied client is on file (prompt + store on first auth).
    client_id, client_secret = oauth.load_client(tool_id)
    if not client_id:
        client_id, client_secret = _prompt_client(tool_id)
        if not client_id:
            return 1
        oauth.store_client(tool_id, client_id, client_secret)

    try:
        if getattr(args, "device_code", False):
            tokens = oauth.run_device_code_flow(
                auth, client_id=client_id, client_secret=client_secret, emit=print
            )
        else:
            tokens = oauth.run_loopback_flow(
                auth, client_id=client_id, client_secret=client_secret, emit=print
            )
    except oauth.OAuthError as exc:
        print(f"Authorization failed: {exc}", file=sys.stderr)
        return 1
    oauth.store_tokens(tool_id, tokens)
    print(f"\nAuthorized {tool_id}. Tokens stored in your OS keyring (not printed).")
    return 0


def _print_status(tool_id: str, auth: dict, oauth) -> int:
    has_client = oauth.has_client(tool_id)
    tokens = oauth.load_tokens(tool_id)
    print(f"{tool_id}:")
    print(f"  provider:      {auth.get('provider', '?')}")
    print(f"  scopes:        {', '.join(auth.get('scopes') or [])}")
    print(f"  client set:    {'yes' if has_client else 'no (will prompt on auth)'}")
    if tokens is None:
        print("  authorized:    no  — run `yepgent tools auth %s`" % tool_id)
        return 0
    expired = tokens.is_expired(now=time.time())
    refreshable = bool(tokens.refresh_token)
    state = "valid" if not expired else ("expired (auto-refreshes on use)" if refreshable else "expired, no refresh — re-auth needed")
    print(f"  authorized:    yes")
    print(f"  access token:  {state}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yepgent tools",
        description="Operate on installed tools (OAuth authorization, etc.).",
    )
    sub = parser.add_subparsers(dest="action", metavar="<action>")

    p_auth = sub.add_parser("auth", help="authorize a tool's OAuth (or --status / --logout)")
    p_auth.add_argument("tool", help="installed tool id")
    p_auth.add_argument(
        "--device-code",
        action="store_true",
        help="use the device-code flow (headless / no local browser)",
    )
    p_auth.add_argument("--status", action="store_true", help="show auth status (never tokens)")
    p_auth.add_argument("--logout", action="store_true", help="forget stored tokens")
    p_auth.set_defaults(func=_cmd_auth)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help(sys.stderr)
        return 1
    return int(func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
