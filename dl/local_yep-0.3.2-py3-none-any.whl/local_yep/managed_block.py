"""Managed CLAUDE.md / AGENTS.md fenced-block renderer (T1.3).

Local Yep, like C3, keeps its instructions inside a single fenced region of the
repo's ``CLAUDE.md`` / ``AGENTS.md``. Everything OUTSIDE the fence belongs to the
user and must survive every ``yepgent init`` / ``yepgent init --force`` / ``yepgent upgrade``
byte-for-byte. Everything INSIDE the fence is regenerated from the bundled
template (:mod:`local_yep.templates`).

Fence markers (mirroring the C3 ``<!-- C3:BEGIN … --> … <!-- C3:END -->`` pattern
visible in this repo's ``CLAUDE.md``)::

    <!-- YEP:BEGIN — regenerated on yepgent init/upgrade; content OUTSIDE this block is preserved -->
    ... managed body (template + a version stamp) ...
    <!-- YEP:END -->

Guarantees:

- **Out-of-fence bytes are preserved exactly.** Prose above and below the block
  is returned unchanged (we only splice the region between the markers).
- **Idempotent.** Re-rendering produces no duplicate fences; a file already
  containing a YEP block has only that block's body replaced. Running twice with
  the same version yields a byte-identical file.
- **Append-on-absence.** A file with no fence (or a brand-new file) gets exactly
  one block appended cleanly, separated by a blank line from any existing tail.
- **Defensive de-duplication.** If a malformed file somehow contains more than
  one YEP block, all of them are collapsed into a single canonical block at the
  position of the first one (the extras are removed) — so we never accumulate
  fences across runs.

This module is pure string/IO plumbing; it does not know about the CLI. The
installer (:mod:`local_yep.installer`) calls :func:`apply_managed_block` for each
target file.
"""

from __future__ import annotations

import re
from pathlib import Path

#: Sentinel words of the fence. We keep the human-readable BEGIN line stable so
#: it reads the same as C3's, but matching is done on the ``YEP:BEGIN`` /
#: ``YEP:END`` tokens so a user editing the descriptive tail of the BEGIN line
#: never breaks detection.
BEGIN_MARKER = (
    "<!-- YEP:BEGIN — regenerated on yepgent init/upgrade; "
    "content OUTSIDE this block is preserved -->"
)
END_MARKER = "<!-- YEP:END -->"

#: Matches one whole managed block, from the BEGIN comment through the END
#: comment, tolerant of any descriptive text between ``YEP:BEGIN`` and ``-->``
#: and any body in between. ``re.DOTALL`` so the body may span lines.
_BLOCK_RE = re.compile(
    r"<!--\s*YEP:BEGIN\b.*?-->.*?<!--\s*YEP:END\s*-->",
    re.DOTALL,
)

#: Marks the version stamp line inside the managed body.
_VERSION_LINE_RE = re.compile(r"^<!-- yep-version:.*?-->$", re.MULTILINE)


def _read_template() -> str:
    """Return the bundled managed-block body template.

    Resolved via ``importlib.resources`` when installed as a package, falling
    back to a path read for editable / source checkouts.
    """
    try:
        from importlib.resources import files

        return (
            files("local_yep.templates")
            .joinpath("claude_md.md")
            .read_text(encoding="utf-8")
        )
    except Exception:  # pragma: no cover - source-tree fallback
        here = Path(__file__).resolve().parent / "templates" / "claude_md.md"
        return here.read_text(encoding="utf-8")


def render_managed_body(version: str) -> str:
    """Render the inner managed body (between the fence markers).

    The body = a machine-readable version stamp + the bundled template. The
    stamp lets :func:`local_yep.installer.upgrade` re-stamp the version without
    otherwise changing the body, and lets tests assert the stamped version.
    """
    template = _read_template().rstrip("\n")
    stamp = f"<!-- yep-version: {version} -->"
    return f"{stamp}\n\n{template}"


def render_block(version: str) -> str:
    """Render a full fenced managed block (markers + body)."""
    body = render_managed_body(version)
    return f"{BEGIN_MARKER}\n{body}\n{END_MARKER}"


def extract_version(text: str) -> str | None:
    """Return the version stamped inside the managed block, or ``None``.

    Looks only inside the managed block so a coincidental ``yep-version`` line in
    the user's own prose is ignored.
    """
    match = _BLOCK_RE.search(text)
    region = match.group(0) if match else text
    vmatch = re.search(r"<!-- yep-version:\s*(.*?)\s*-->", region)
    return vmatch.group(1) if vmatch else None


def has_block(text: str) -> bool:
    """True if ``text`` already contains a YEP managed block."""
    return _BLOCK_RE.search(text) is not None


def apply_to_text(existing: str, version: str) -> str:
    """Return ``existing`` with the managed block inserted or replaced.

    - No block present: the rendered block is appended, separated from any
      existing content by a single blank line. An empty input yields just the
      block (trailing newline added).
    - One or more blocks present: the FIRST is replaced in place with the freshly
      rendered block, and any additional blocks are removed (de-duplication). All
      bytes outside the managed region(s) are preserved exactly.

    The function is idempotent: applying it twice with the same ``version`` is a
    fixed point.
    """
    block = render_block(version)

    matches = list(_BLOCK_RE.finditer(existing))
    if not matches:
        # No managed block yet — append one cleanly.
        if existing.strip() == "":
            return block + "\n"
        sep = "" if existing.endswith("\n\n") else ("\n" if existing.endswith("\n") else "\n\n")
        # Normalise to exactly one blank line between prior content and the block.
        prefix = existing.rstrip("\n")
        return f"{prefix}\n\n{block}\n"

    first = matches[0]
    # Splice: text before the first block + new block + text after the first
    # block, with every other (stray) block removed from the tail.
    head = existing[: first.start()]
    tail = existing[first.end() :]
    # Drop any extra managed blocks in the tail (defensive de-dup).
    tail = _BLOCK_RE.sub("", tail)
    return head + block + tail


def apply_managed_block(path: Path, version: str) -> bool:
    """Write the managed block into ``path`` (CLAUDE.md / AGENTS.md).

    Reads the file if it exists, splices the managed block (preserving all
    out-of-fence bytes), and writes it back only when the content actually
    changes. Returns ``True`` if the file was created or modified, ``False`` if
    it was already up to date (so callers can report idempotency).

    Newlines are written as ``\\n`` (``newline=""`` on open) so the file does not
    get CRLF-rewritten on Windows.
    """
    path = Path(path)
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    updated = apply_to_text(existing, version)
    if updated == existing:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(updated)
    return True


def strip_from_text(existing: str) -> str:
    """Return ``existing`` with every managed block removed.

    The inverse of :func:`apply_to_text`: all YEP managed regions are deleted
    and the out-of-fence prose is preserved. Whitespace left where a block was
    removed is collapsed (3+ newlines -> one blank line) and the result keeps a
    single trailing newline; an input that held nothing but the block yields the
    empty string. Idempotent — text with no block is returned unchanged.
    """
    if not _BLOCK_RE.search(existing):
        return existing
    stripped = _BLOCK_RE.sub("", existing)
    stripped = re.sub(r"\n{3,}", "\n\n", stripped)
    stripped = stripped.strip("\n")
    return stripped + "\n" if stripped else ""


def remove_managed_block(path: Path) -> bool:
    """Strip the managed block from ``path``, preserving out-of-fence prose.

    The inverse of :func:`apply_managed_block`. Returns ``True`` if the file
    existed and changed, ``False`` otherwise. The file is rewritten in place (it
    is not deleted even when it becomes empty — the caller decides that).
    """
    path = Path(path)
    if not path.exists():
        return False
    existing = path.read_text(encoding="utf-8")
    updated = strip_from_text(existing)
    if updated == existing:
        return False
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(updated)
    return True
