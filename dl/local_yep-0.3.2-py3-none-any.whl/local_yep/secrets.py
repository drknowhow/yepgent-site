"""Local, keyring-backed secret store for installed tools (PLAN.md §6 / P5, T6.1).

Model A of "Credentials & Tool Auth": bring-your-own creds, stored **100%
locally**, never in the cloud. An installed tool declares the env vars it needs
in its manifest ``env[]`` (each ``{name, prompt, secret}``); this module is where
those values actually live between install and call:

  * ``secret: true``  → the OS keyring (Windows Credential Manager / macOS
    Keychain / Linux Secret Service, via the optional ``keyring`` package). The
    plaintext value NEVER touches disk.
  * ``secret: false`` (config) → ``~/.local-yep/tool_config.toml`` as plaintext.
    Non-secret by definition; safe to read back and show.

Values are namespaced per ``tool_id`` so two tools that both want ``API_KEY`` do
not collide. The keyring has no portable "list" API, so the **names** of stored
secrets are registered (names only, never values) in the same
``tool_config.toml`` under a ``[secrets."<tool_id>"]`` table — that is what powers
``yepgent secrets list`` without ever reading a value.

Hard rules (from the spec):

  * **Fail loud, never silent plaintext.** When no keyring backend is available
    (e.g. a headless Linux box with no Secret Service), :func:`set_secret`
    raises :class:`NoKeyringError` with guidance. A secret is never quietly
    written to a plaintext file as a fallback.
  * **Values are never logged** and never returned by the listing/inspection
    surface — only names + which tool owns them + whether a value is present.

The ``keyring`` dependency is an OPTIONAL extra (``pip install
local-yep[secrets]``) so the free core stays lean; this module imports it lazily
and only the *secret-value* paths need it (config + the names registry work with
the stdlib TOML reader alone).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from local_yep import home

# stdlib `tomllib` (>=3.11) with the `tomli` backport for the 3.10 floor — the
# same pattern the rest of the package uses. Reading only; the writer below is
# a tiny, constrained TOML serializer (str/bool leaves) so config works without
# pulling a TOML *writer* dependency into the free core.
try:  # pragma: no cover - import shim
    import tomllib as _toml  # type: ignore[no-redef]
except ModuleNotFoundError:  # pragma: no cover - 3.10
    import tomli as _toml  # type: ignore[no-redef]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class SecretsError(RuntimeError):
    """Base for secret-store failures."""


class NoKeyringError(SecretsError):
    """No usable OS keyring backend is available, so a secret cannot be stored
    securely. We refuse rather than silently writing the secret to plaintext."""


_NO_KEYRING_GUIDANCE = (
    "No secure OS keyring backend is available, so this secret cannot be stored "
    "safely. Local Yep refuses to write secrets to plaintext.\n"
    "  • Install the keyring extra:  pip install 'local-yep[secrets]'\n"
    "  • On a headless Linux host, install/run a Secret Service "
    "(e.g. gnome-keyring + dbus, or KWallet), or use `keyrings.alt` deliberately.\n"
    "  • As a last resort you may pass the value via the process environment "
    "instead (it is read at call time as a fallback)."
)


# ---------------------------------------------------------------------------
# Keyring seam (lazy import; tests inject a fake)
# ---------------------------------------------------------------------------

_SERVICE_PREFIX = "local-yep"

#: Test seam: when set to an object exposing the ``keyring`` surface
#: (``get_password`` / ``set_password`` / ``delete_password`` and optionally
#: ``get_keyring``), it is used instead of the real ``keyring`` package. Lets the
#: suite run hermetically without touching the developer's real OS keyring and
#: without requiring the optional dependency to be installed.
_KEYRING_OVERRIDE: Any | None = None


def _service(tool_id: str) -> str:
    """Keyring *service* name for a tool. Per-tool so backends that group by
    service keep a tool's creds together; the env var name is the *username*."""
    return f"{_SERVICE_PREFIX}:{tool_id}"


def _keyring_module() -> Any:
    """Return the keyring module (or the injected fake). Raises
    :class:`NoKeyringError` if the optional ``keyring`` package is not installed."""
    if _KEYRING_OVERRIDE is not None:
        return _KEYRING_OVERRIDE
    try:
        import keyring  # type: ignore[import-not-found]
    except Exception as exc:  # noqa: BLE001 - any import failure ⇒ unavailable
        raise NoKeyringError(_NO_KEYRING_GUIDANCE) from exc
    return keyring


def keyring_available() -> bool:
    """Best-effort: True iff a real, writable keyring backend looks available.

    Detects the ``keyring`` "fail" backend (returned when no real store exists,
    e.g. headless Linux) so the CLI/provisioning can warn early. Never raises."""
    try:
        kr = _keyring_module()
    except NoKeyringError:
        return False
    get_backend = getattr(kr, "get_keyring", None)
    if not callable(get_backend):
        # An injected fake without get_keyring is assumed usable.
        return True
    try:
        backend = get_backend()
    except Exception:  # noqa: BLE001
        return False
    name = f"{type(backend).__module__}.{type(backend).__name__}".lower()
    # keyring.backends.fail.Keyring / "chainer with no viable backend" ⇒ no store.
    return "fail" not in name


def _set_password(tool_id: str, name: str, value: str) -> None:
    kr = _keyring_module()
    try:
        kr.set_password(_service(tool_id), name, value)
    except NoKeyringError:
        raise
    except Exception as exc:  # noqa: BLE001 - keyring.errors.NoKeyringError et al.
        # Treat ANY store failure as fail-closed: do NOT fall back to plaintext.
        raise NoKeyringError(_NO_KEYRING_GUIDANCE) from exc


def _get_password(tool_id: str, name: str) -> str | None:
    try:
        kr = _keyring_module()
    except NoKeyringError:
        return None
    try:
        return kr.get_password(_service(tool_id), name)
    except Exception:  # noqa: BLE001 - unreadable backend ⇒ treat as absent
        return None


def _delete_password(tool_id: str, name: str) -> bool:
    try:
        kr = _keyring_module()
    except NoKeyringError:
        return False
    try:
        kr.delete_password(_service(tool_id), name)
        return True
    except Exception:  # noqa: BLE001 - missing entry / no backend
        return False


# ---------------------------------------------------------------------------
# Config file (~/.local-yep/tool_config.toml) — non-secret values + name registry
# ---------------------------------------------------------------------------


def _config_path() -> Path:
    """Resolve the tool-config file. Honors ``YEP_TOOL_CONFIG`` (tests/headless
    point it at a scratch file) and otherwise lands at the canonical
    ``~/.local-yep/tool_config.toml``."""
    override = os.environ.get("YEP_TOOL_CONFIG")
    if override:
        return Path(override)
    return home.TOOL_CONFIG_TOML


def _load_doc() -> dict[str, Any]:
    """Parse the config file into ``{"config": {...}, "secrets": {...}}``.

    A missing/empty/corrupt file degrades to an empty doc — config is best-effort
    and a parse error must never crash a tool call (no values are logged)."""
    path = _config_path()
    try:
        if not path.exists():
            return {"config": {}, "secrets": {}}
        text = path.read_text(encoding="utf-8")
        if not text.strip():
            return {"config": {}, "secrets": {}}
        data = _toml.loads(text)
    except Exception:  # noqa: BLE001 - corrupt TOML ⇒ empty, never crash
        return {"config": {}, "secrets": {}}
    cfg = data.get("config")
    sec = data.get("secrets")
    return {
        "config": cfg if isinstance(cfg, dict) else {},
        "secrets": sec if isinstance(sec, dict) else {},
    }


def _toml_basic_string(s: str) -> str:
    """Serialize ``s`` as a TOML basic string (quoted, fully escaped). Used for
    both values and keys so arbitrary tool ids / values round-trip exactly."""
    out: list[str] = []
    for ch in s:
        if ch == "\\":
            out.append("\\\\")
        elif ch == '"':
            out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif ch == "\b":
            out.append("\\b")
        elif ch == "\f":
            out.append("\\f")
        elif ord(ch) < 0x20 or ord(ch) == 0x7F:
            out.append("\\u%04X" % ord(ch))
        else:
            out.append(ch)
    return '"' + "".join(out) + '"'


def _dump_doc(doc: dict[str, Any]) -> str:
    """Serialize the constrained ``{"config":{tid:{k:str}}, "secrets":{tid:{k:bool}}}``
    doc to TOML. Leaves are only ``str`` (config) or ``bool`` (secret-name marker),
    so a tiny hand serializer is sufficient and avoids a TOML-writer dependency.
    Re-parses byte-for-byte via :func:`_load_doc` (covered by tests)."""
    lines = [
        "# Local Yep — per-tool configuration & secret-name registry.",
        "# NON-SECRET config values are stored here in plaintext.",
        "# Secret VALUES live in the OS keyring; this file records only their NAMES",
        "# (under [secrets.\"<tool>\"]) so `yepgent secrets list` can work.",
        "",
    ]
    for section in ("config", "secrets"):
        table = doc.get(section) or {}
        for tid in sorted(table):
            items = table.get(tid) or {}
            if not items:
                continue
            lines.append(f"[{section}.{_toml_basic_string(str(tid))}]")
            for key in sorted(items):
                val = items[key]
                if isinstance(val, bool):
                    rendered = "true" if val else "false"
                else:
                    rendered = _toml_basic_string(str(val))
                lines.append(f"{_toml_basic_string(str(key))} = {rendered}")
            lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


def _save_doc(doc: dict[str, Any]) -> None:
    """Atomically write the config doc (tmp + ``os.replace``), mirroring the
    durable install-index write."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
    tmp.write_text(_dump_doc(doc), encoding="utf-8")
    os.replace(str(tmp), str(path))


def _prune_empty(table: dict[str, Any], tool_id: str) -> None:
    inner = table.get(tool_id)
    if isinstance(inner, dict) and not inner:
        del table[tool_id]


# ---------------------------------------------------------------------------
# Public API — secrets (keyring)
# ---------------------------------------------------------------------------


def set_secret(tool_id: str, name: str, value: str) -> None:
    """Store a secret value in the OS keyring under ``tool_id``/``name`` and
    register its NAME in the config file. Raises :class:`NoKeyringError` (with
    guidance) when no secure backend exists — never writes the value to disk."""
    _set_password(tool_id, name, value)  # fail-closed; raises before the registry write
    doc = _load_doc()
    doc["secrets"].setdefault(tool_id, {})[name] = True
    # A name cannot be both a secret and plaintext config — drop any stale config row.
    cfg = doc["config"].get(tool_id)
    if isinstance(cfg, dict):
        cfg.pop(name, None)
        _prune_empty(doc["config"], tool_id)
    _save_doc(doc)


def get_secret(tool_id: str, name: str) -> str | None:
    """Return the secret value from the keyring, or ``None`` if absent/unreadable."""
    return _get_password(tool_id, name)


def delete_secret(tool_id: str, name: str) -> bool:
    """Remove a secret from the keyring and deregister its name. Returns True if a
    registry entry was removed (the keyring deletion is best-effort)."""
    _delete_password(tool_id, name)
    doc = _load_doc()
    sec = doc["secrets"].get(tool_id)
    removed = False
    if isinstance(sec, dict) and name in sec:
        del sec[name]
        removed = True
        _prune_empty(doc["secrets"], tool_id)
        _save_doc(doc)
    return removed


# ---------------------------------------------------------------------------
# Public API — config (plaintext TOML)
# ---------------------------------------------------------------------------


def set_config(tool_id: str, name: str, value: str) -> None:
    """Store a NON-SECRET config value (plaintext) under ``tool_id``/``name``."""
    doc = _load_doc()
    doc["config"].setdefault(tool_id, {})[name] = str(value)
    # Mutually exclusive with a secret of the same name.
    sec = doc["secrets"].get(tool_id)
    if isinstance(sec, dict) and name in sec:
        del sec[name]
        _delete_password(tool_id, name)
        _prune_empty(doc["secrets"], tool_id)
    _save_doc(doc)


def get_config(tool_id: str, name: str) -> str | None:
    """Return the plaintext config value, or ``None`` if absent."""
    doc = _load_doc()
    inner = doc["config"].get(tool_id)
    if isinstance(inner, dict):
        val = inner.get(name)
        if isinstance(val, str):
            return val
    return None


def delete_config(tool_id: str, name: str) -> bool:
    """Remove a config value. Returns True if it existed."""
    doc = _load_doc()
    inner = doc["config"].get(tool_id)
    if isinstance(inner, dict) and name in inner:
        del inner[name]
        _prune_empty(doc["config"], tool_id)
        _save_doc(doc)
        return True
    return False


# ---------------------------------------------------------------------------
# Public API — resolution + inspection
# ---------------------------------------------------------------------------


def resolve(tool_id: str, name: str) -> str | None:
    """Resolve a declared env value for a tool: keyring secret first, then
    plaintext config, else ``None``. The call-time value source (T6.3). Never
    raises — an unreadable keyring degrades to ``None`` (the caller falls back to
    the process environment)."""
    doc = _load_doc()
    sec = doc["secrets"].get(tool_id)
    if isinstance(sec, dict) and sec.get(name):
        val = _get_password(tool_id, name)
        if val is not None:
            return val
    cfg = doc["config"].get(tool_id)
    if isinstance(cfg, dict):
        val = cfg.get(name)
        if isinstance(val, str):
            return val
    return None


def has_value(tool_id: str, name: str) -> bool:
    """True iff a value for ``tool_id``/``name`` is already provisioned in the
    store (registered secret OR present config). Used to skip re-prompting at
    install time. Does not consult the process environment (the loader does)."""
    doc = _load_doc()
    sec = doc["secrets"].get(tool_id)
    if isinstance(sec, dict) and name in sec:
        return True
    cfg = doc["config"].get(tool_id)
    if isinstance(cfg, dict) and name in cfg:
        return True
    return False


def is_secret(tool_id: str, name: str) -> bool:
    """True iff ``name`` is registered as a secret (value in keyring) for the tool."""
    doc = _load_doc()
    sec = doc["secrets"].get(tool_id)
    return bool(isinstance(sec, dict) and sec.get(name))


def list_names(tool_id: str | None = None) -> dict[str, list[dict[str, Any]]]:
    """List stored credential NAMES per tool — NEVER values.

    Returns ``{tool_id: [{"name", "secret", "present"}, ...]}``. ``present`` says
    whether a value can actually be read back right now (a registered secret with
    a wiped keyring reads as not-present). When ``tool_id`` is given, only that
    tool is returned (possibly an empty list)."""
    doc = _load_doc()
    tool_ids = (
        {tool_id}
        if tool_id is not None
        else (set(doc["config"]) | set(doc["secrets"]))
    )
    out: dict[str, list[dict[str, Any]]] = {}
    for tid in sorted(tool_ids):
        rows: list[dict[str, Any]] = []
        sec = doc["secrets"].get(tid) or {}
        for name in sorted(sec):
            rows.append(
                {
                    "name": name,
                    "secret": True,
                    "present": _get_password(tid, name) is not None,
                }
            )
        cfg = doc["config"].get(tid) or {}
        for name in sorted(cfg):
            rows.append(
                {"name": name, "secret": False, "present": cfg.get(name) is not None}
            )
        out[tid] = rows
    return out


def purge_tool(tool_id: str) -> dict[str, Any]:
    """Delete ALL stored creds (secrets + config) for a tool. Used when a tool is
    uninstalled so orphaned credentials don't linger. Returns a summary
    ``{"secrets": [names], "config": [names]}`` of what was removed (names only)."""
    doc = _load_doc()
    removed_secrets: list[str] = []
    removed_config: list[str] = []

    sec = doc["secrets"].get(tool_id)
    if isinstance(sec, dict):
        for name in list(sec):
            _delete_password(tool_id, name)
            removed_secrets.append(name)
        doc["secrets"].pop(tool_id, None)

    cfg = doc["config"].get(tool_id)
    if isinstance(cfg, dict):
        removed_config = list(cfg)
        doc["config"].pop(tool_id, None)

    if removed_secrets or removed_config:
        _save_doc(doc)
    return {"secrets": sorted(removed_secrets), "config": sorted(removed_config)}
