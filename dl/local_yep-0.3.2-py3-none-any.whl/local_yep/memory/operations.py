"""Read/write/edit operations for facts, episodes, reflections.

All reads and writes go through the :mod:`local_yep.memory.backend`
query-builder surface (``get_backend()``), which resolves to a local SQLite
store at ``~/.local-yep/memory.db``. Return shapes, ``_is_embeddable``, the
role→importance mapping, the ``_FACT_HISTORY_CAP`` drift ring, and the
note/tag ↔ content/category aliasing are all defined here.
"""
import json
from typing import Any, Optional
from .backend import get_backend
from .embeddings import embed
from ._subagent_ctx import get_current_subagent_run


def _current_agent_session_id() -> Optional[str]:
    """Return the current subagent run_id (uuid str) when called inside a
    subagent execution context, or None when called from the main loop.

    Used to stamp agent_session_id on memory-write rows for forensic
    traceability (gaps a/e from the 2026-05-16 session isolation audit).
    Never raises — absence of context is normal, not an error.
    """
    ctx = get_current_subagent_run()
    if ctx is None:
        return None
    return ctx.get("run_id")


# ---------- Facts ----------

# How many prior fact values to retain in the metadata history ring.
# Sibling Yep sessions can write the facts table concurrently, so any
# upsert may clobber a value another writer set out-of-band. We keep a
# bounded trail of overwritten values so nothing is silently lost (Rule 2).
_FACT_HISTORY_CAP = 5

# Upper bound on the recent-fact slice scanned in-Python for the
# value-substring path of ``search_facts``. The ``value`` column holds a
# JSON document, so the value-substring path fetches the most-recently-
# touched ``_VALUE_SCAN_LIMIT`` rows and substring-matches them in Python
# instead of relying on a backend-specific match over JSON text. Sized
# well above today's facts row count (~447) so it's effectively a full
# scan; if the table grows past this, the slice still biases toward
# freshly-written facts, which is the right bias.
_VALUE_SCAN_LIMIT = 1000


def write_fact(key: str, value: str, confidence: float = 1.0,
               source: Optional[str] = None) -> dict:
    """Upsert a fact by key, with overwrite/lost-update drift detection.

    The facts table can be written concurrently by sibling Yep sessions,
    so a blind upsert can silently clobber a value another writer set
    out-of-band — a Rule-2 ("confirm before destruction") hazard at the
    memory layer.

    Before writing, read the current row. When an existing value is being
    overwritten with a *different* value, snapshot the prior state into the
    row's ``metadata.fact_history`` ring (bounded by ``_FACT_HISTORY_CAP``)
    so it is recoverable, and attach a ``drift`` key to the returned row
    describing what was overwritten (prior value/source/writer/timestamp).
    Callers — and the model, via ``remember_fact`` — can surface or recover
    the prior value. No new table or migration: the trail rides in the
    existing ``metadata`` jsonb.

    A same-value re-write carries existing metadata forward unchanged and
    reports no drift.
    """
    sb = get_backend()
    prior = read_fact(key)

    payload: dict[str, Any] = {
        "key": key, "value": value, "confidence": confidence,
    }
    if source is not None:
        payload["source"] = source
    run_id = _current_agent_session_id()
    if run_id is not None:
        payload["agent_session_id"] = run_id

    drift: Optional[dict] = None
    if prior is not None:
        prior_value = prior.get("value")
        existing_meta = dict(prior.get("metadata") or {})
        if prior_value != value:
            # Overwriting a different existing value: preserve it losslessly.
            drift = {
                "key": key,
                "prior_value": prior_value,
                "prior_source": prior.get("source"),
                "prior_updated_at": prior.get("updated_at"),
                "prior_agent_session_id": prior.get("agent_session_id"),
                "overwritten_by": run_id,
            }
            history = list(existing_meta.get("fact_history") or [])
            history.append({
                "value": prior_value,
                "source": prior.get("source"),
                "updated_at": prior.get("updated_at"),
                "agent_session_id": prior.get("agent_session_id"),
                "overwritten_by": run_id,
            })
            existing_meta["fact_history"] = history[-_FACT_HISTORY_CAP:]
        # Carry metadata forward on both the changed and same-value paths so
        # an accumulated history ring is never dropped by a later touch.
        payload["metadata"] = existing_meta

    # Optional dense vector (best-effort). embed() raises EmbeddingUnavailable
    # in cold / BM25-only contexts (no embedder activated) — caught here so the
    # fact still stores WITHOUT a vector; `yepgent memory reindex` backfills it
    # later in a warm context. Key + value are embedded so a fact is recallable
    # by its namespace AND its content.
    try:
        payload["embedding"] = embed(f"{key}: {value}")
    except Exception:
        pass

    res = sb.table("facts").upsert(payload, on_conflict="key").execute()
    row = dict(res.data[0]) if res.data else {}
    if drift is not None:
        row["drift"] = drift
    return row


def recover_fact_prior(key: str, index: int = -1) -> Optional[dict]:
    """Return a prior snapshot of a fact from its metadata history ring.

    ``index`` selects which snapshot (default ``-1`` = the most recently
    overwritten value). Read-only: it does not mutate the fact. To actually
    restore a prior value, pass the returned ``value`` back through
    ``write_fact``. Returns None when the fact, its history ring, or the
    requested index is absent.
    """
    row = read_fact(key)
    if not row:
        return None
    history = (row.get("metadata") or {}).get("fact_history") or []
    if not history:
        return None
    try:
        return history[index]
    except IndexError:
        return None


def read_fact(key: str) -> Optional[dict]:
    res = get_backend().table("facts").select("*").eq("key", key).limit(1).execute()
    return res.data[0] if res.data else None


def list_facts(prefix: Optional[str] = None, limit: int = 100) -> list[dict]:
    q = get_backend().table("facts").select("*").order("updated_at", desc=True).limit(limit)
    if prefix:
        q = q.like("key", f"{prefix}%")
    return q.execute().data or []


def search_facts(query: str, limit: int = 10) -> list[dict]:
    """Lexical (case-insensitive substring) search over facts by key OR value.

    Facts carry no embedding column — unlike episodes/reflections they are
    content-addressable only by exact key or key-prefix. That's a real
    recall hole: a fact stored under ``agents.muninn`` is invisible to the
    query "Muninn" unless the caller already guesses the ``agents.`` key
    namespace. This adds a value-aware path so the fact is findable by its
    content, not just its key.

    Implementation note: the ``key`` column is text, so the key-substring
    path uses a direct ``.ilike("key", pattern)`` call — injection-safe
    (the pattern is encoded as a filter value, never inlined into an
    ``or()`` expression where commas/parens would misparse).

    The ``value`` column holds a JSON document rather than plain text, so
    the value-substring path doesn't ILIKE it directly: it fetches a
    bounded recent slice (``_VALUE_SCAN_LIMIT`` rows ordered by
    ``updated_at`` desc) and substring-matches in Python. With the current
    facts table (~447 rows) the slice covers the entire table; if facts
    ever exceeds the slice we still get the most-recently-touched window,
    which is the right bias for recall.
    """
    sb = get_backend()
    pattern = f"%{query}%"
    by_key = (sb.table("facts").select("*")
              .ilike("key", pattern)
              .order("updated_at", desc=True).limit(limit).execute().data or [])
    seen_keys: set = {r.get("key") for r in by_key}
    # Value-substring scan: the JSON value column isn't ILIKE'd directly.
    candidates = (sb.table("facts").select("*")
                  .order("updated_at", desc=True)
                  .limit(_VALUE_SCAN_LIMIT).execute().data or [])
    needle = query.lower()
    by_value: list[dict] = []
    for row in candidates:
        if row.get("key") in seen_keys:
            continue
        val = row.get("value")
        if isinstance(val, str):
            text = val
        elif val is None:
            text = ""
        else:
            try:
                text = json.dumps(val, ensure_ascii=False)
            except (TypeError, ValueError):
                text = str(val)
        if needle in text.lower():
            by_value.append(row)
            if len(by_value) >= limit:
                break
    merged: list[dict] = []
    seen: set = set()
    for row in (*by_key, *by_value):
        k = row.get("key")
        if k in seen:
            continue
        seen.add(k)
        merged.append(row)

    # Optional dense leg: when an embedder is active (a warm context — the MCP
    # server or reindex), also rank facts by cosine similarity to the query and
    # fill any remaining slots with high-similarity facts the lexical pass
    # missed. A no-op on the BM25-only path (embed() raises -> qv is None).
    if len(merged) < limit:
        try:
            qv = embed(query)
        except Exception:
            qv = None
        if qv is not None:
            from local_yep.memory.sqlite_backend import _cosine_relevance

            dense: list[tuple] = []
            for row in candidates:  # the bounded recent slice already fetched
                if row.get("key") in seen:
                    continue
                ev = row.get("embedding")
                if not isinstance(ev, (list, tuple)) or not ev:
                    continue
                cos = _cosine_relevance(qv, ev)
                if cos is None:
                    continue
                dense.append((cos, row))
            dense.sort(key=lambda t: t[0], reverse=True)
            for _cos, row in dense:
                if len(merged) >= limit:
                    break
                seen.add(row.get("key"))
                merged.append(row)
    return merged[:limit]


def delete_fact(key: str) -> bool:
    res = get_backend().table("facts").delete().eq("key", key).execute()
    return bool(res.data)


# ---------- Episodes ----------

# Skip embedding for trivially short content like "ok", "yes", "go ahead".
# Such episodes are still stored (the row + content), they just don't
# contribute to vector search — embedding "ok" hundreds of times pollutes
# semantic recall and wastes Ollama calls on the background path.
_EMBED_MIN_CHARS = 16


def _is_embeddable(text: str) -> bool:
    """True if `text` is substantive enough to be worth a vector embedding."""
    return len(text.strip()) >= _EMBED_MIN_CHARS


def log_episode(role: str, content: str, summary: Optional[str] = None,
                metadata: Optional[dict] = None, with_embedding: bool = True,
                thread_id: Optional[str] = None,
                episode_id: Optional[str] = None) -> dict:
    """Append an episode. By default also stores an embedding for recall.

    Trivial content (shorter than `_EMBED_MIN_CHARS` after strip) is logged
    without an embedding even when ``with_embedding=True`` — the episode is
    still recoverable via recent_episodes / SQL, just not via semantic search.

    `thread_id` (uuid str) attributes the episode to a conversation_threads
    row so the UI can render it as part of that thread's history. None for
    episodes logged outside a chat turn (e.g. tool dumps).

    `episode_id` (uuid str) lets the caller pre-allocate the row's primary
    key. The /chat/stream path uses this so the SSE stream can ship the
    final episode UUIDs to the client inside `turn_start` /
    `done`, eliminating the dedup race when mobile backgrounds the tab
    and the push_bus `episode_persisted` event is dropped (push_bus is
    fire-and-forget with no replay). Omitted → DB autogen (legacy
    behavior). The client merges this set with the existing
    `episode_persisted` push-event set — first one wins.
    """
    payload: dict[str, Any] = {
        "role": role,
        "content": content,
        "metadata": metadata or {},
    }
    if episode_id:
        payload["id"] = str(episode_id)
    if summary:
        payload["summary"] = summary
    if thread_id:
        payload["thread_id"] = str(thread_id)
    run_id = _current_agent_session_id()
    if run_id is not None:
        payload["agent_session_id"] = run_id
    if with_embedding:
        embed_target = summary or content
        if _is_embeddable(embed_target):
            try:
                payload["embedding"] = embed(embed_target)
            except Exception as e:
                # Embeddings are best-effort: never drop an episode because
                # the local embed service is down. The row is still
                # recoverable via recent_episodes / SQL — just not via
                # semantic search until embeddings come back. Logged at DEBUG
                # (silent by default): on the BM25-only default path embed()
                # raises on EVERY write, and a print() to stdout would also
                # corrupt hook JSON (the Stop hook writes episodes).
                import logging
                logging.getLogger("local_yep.memory").debug(
                    "embed unavailable, logging episode without vector: %s: %s",
                    type(e).__name__, e,
                )
    res = get_backend().table("episodes").insert(payload).execute()
    return res.data[0] if res.data else {}


def recent_episodes(limit: int = 10,
                    thread_id: Optional[str] = None) -> list[dict]:
    """Most recent episodes, chronologically ordered for prompt rendering.

    When ``thread_id`` is provided, only episodes attributed to that thread
    surface. None = unscoped (legacy behavior).
    """
    q = (get_backend().table("episodes")
         .select("id,role,content,summary,occurred_at")
         .order("occurred_at", desc=True)
         .limit(limit))
    if thread_id is not None:
        q = q.eq("thread_id", str(thread_id))
    res = q.execute()
    return list(reversed(res.data or []))  # chronological for prompt


def recent_event_episodes(since_hours: int = 24,
                          limit: int = 5) -> list[dict]:
    """Most recent role='event' episodes from the last ``since_hours`` hours.

    Returned newest-first (descending occurred_at). Cross-thread by design —
    role='event' rows are written by scheduler-dispatched sessions
    (post_merge_resume, pre_restart_handoff, fill_sync, daily_report, etc.)
    with thread_id=NULL, and they represent autonomous outcomes that should
    orient ANY thread's next user turn — independent of semantic similarity
    to the user's message.

    Closes the "I merged and nothing showed up" gap: previously the prelude
    only pulled semantic matches for the user message, so a `>>` or other
    low-signal user turn would miss a high-signal post-merge resume that
    had completed in a parallel scheduler session.
    """
    from datetime import datetime, timedelta, timezone
    since = (datetime.now(timezone.utc) - timedelta(hours=since_hours)).isoformat()
    res = (get_backend().table("episodes")
           .select("id,role,content,summary,occurred_at")
           .eq("role", "event")
           .gte("occurred_at", since)
           .order("occurred_at", desc=True)
           .limit(limit)
           .execute())
    return res.data or []


def search_episodes(query: str, threshold: float = 0.25, limit: int = 5,
                    thread_id: Optional[str] = None,
                    project_id: Optional[str] = None,
                    alpha_relevance: Optional[float] = None,
                    alpha_recency: Optional[float] = None,
                    alpha_importance: Optional[float] = None,
                    tau_days: Optional[float] = None,
                    hybrid: bool = True,
                    rrf_k: Optional[int] = None,
                    candidate_pool: Optional[int] = None,
                    lex_min_similarity: Optional[float] = None) -> list[dict]:
    """Semantic search via the match_episodes / match_episodes_hybrid RPC.

    ``threshold`` (local relevance-gate semantics, 2026-07-02, owner-approved
    divergence from the cloud contract): gates the RELEVANCE component of
    each candidate (BM25-squashed ``q/(1+q)`` or cosine), NOT the blended
    ``score`` — blend-gating made rows older than ~3 weeks structurally
    unrecallable (recency decay alone put the blend under the old 0.7
    default). Default 0.25, calibrated with tests/test_recall_quality.py:
    good BM25 matches land at rel 0.78-0.92 in a 20+-row store but only
    0.33-0.37 in a near-empty (cold-start) store because BM25's IDF collapses
    with tiny N — 0.25 admits cold-start true positives while still dropping
    zero-signal candidates; ranking + the top-N cap do the actual selection.
    (Hybrid mode forces 0.0 anyway — see below.)

    Scope params (forwarded to the RPC; both NULL = legacy global match):
      - ``thread_id``  (PR-Th1) — exact thread filter; rows from other
        threads OR with NULL thread_id (legacy + daemon-written) are
        excluded by design.
      - ``project_id`` (PR-P2)  — blend across every thread in the
        project. When set, ``thread_id`` is ignored — project-blend is a
        strict superset of single-thread. Use this when a thread belongs
        to a project and the model wants context from sibling threads in
        the same goal-shaped scope.

    The RPC also soft-demotes episodes whose thread is in a 'completed'
    project (similarity *= 0.7). That happens server-side regardless of
    which scope the caller picked — completed-project demotion is global,
    not scope-conditional.

    Weighting params (memory-recall-upgrade PR1; all optional, None =
    use SQL defaults α_rel=0.5, α_rec=0.3, α_imp=0.2, τ_days=14). The
    RPC computes ``score = α_rel*relevance + α_rec*recency +
    α_imp*importance`` per candidate. Bumping ``alpha_recency`` favors
    newer episodes; bumping ``alpha_importance`` favors role='event'
    rows (autonomous outcomes).

    Hybrid recall (memory-recall-upgrade PR2, default on):
      - ``hybrid=True`` routes to match_episodes_hybrid, which fuses the
        PR1 weighted dense score with a pg_trgm lexical similarity
        signal via Reciprocal Rank Fusion (k=60 default). Catches exact-
        token / proper-noun matches that pure cosine misses ("PR #617",
        "the Q3 budget"). Threshold is force-set to 0.0 in hybrid mode
        because RRF scores live on a different scale (max ~0.033) than
        PR1's weighted score; ranking still works the same — top-N by
        fused score.
      - ``hybrid=False`` falls back to the PR1 match_episodes RPC for
        benchmarking, regression diffs, or callers that don't want the
        lexical signal (e.g. an embedding-only ablation).
      - ``rrf_k``, ``candidate_pool``, ``lex_min_similarity`` are
        hybrid-only knobs (None = SQL defaults 60 / 50 / 0.1).
    """
    # Embedding is OPTIONAL (T2.7): the default local path is BM25-only and
    # has no embedder pack installed, so embed() raises EmbeddingUnavailable.
    # Catch it and recall lexically — the dense vector only adds a cosine
    # relevance signal WHEN a pack is present (the SQLite backend ignores a
    # missing query_embedding and ranks on BM25). Never let an absent embedder
    # turn semantic recall into a hard error.
    try:
        e = embed(query)
    except Exception:
        e = None
    rpc_name = "match_episodes_hybrid" if hybrid else "match_episodes"
    rpc_args: dict[str, Any] = {
        # In hybrid mode the threshold lives on the RRF scale (~0..0.033),
        # so the legacy 0.55/0.7 cutoffs would empty the result set.
        # Force 0.0 — rely on match_count for the top-N cap.
        "match_threshold": 0.0 if hybrid else threshold,
        "match_count": limit,
        # Always carry the raw query text so the LOCAL backend's FTS5 leg has
        # it in both hybrid and non-hybrid modes (the cloud RPC only needs it
        # for hybrid). Harmless to the cloud RPC, which keys off the embedding.
        "query_text": query,
    }
    if e is not None:
        rpc_args["query_embedding"] = e
    if thread_id is not None:
        rpc_args["p_thread_id"] = str(thread_id)
    if project_id is not None:
        rpc_args["p_project_id"] = str(project_id)
    if alpha_relevance is not None:
        rpc_args["alpha_relevance"] = alpha_relevance
    if alpha_recency is not None:
        rpc_args["alpha_recency"] = alpha_recency
    if alpha_importance is not None:
        rpc_args["alpha_importance"] = alpha_importance
    if tau_days is not None:
        rpc_args["tau_days"] = tau_days
    if hybrid:
        if rrf_k is not None:
            rpc_args["rrf_k"] = rrf_k
        if candidate_pool is not None:
            rpc_args["candidate_pool"] = candidate_pool
        if lex_min_similarity is not None:
            rpc_args["lex_min_similarity"] = lex_min_similarity
    res = get_backend().rpc(rpc_name, rpc_args).execute()
    return res.data or []


# ---------- Reflections ----------

def write_reflection(note: str, tag: Optional[str] = None,
                     weight: float = 1.0, with_embedding: bool = True,
                     failure_class: Optional[str] = None,
                     metadata: Optional[dict] = None) -> dict:
    # Canonical DB column names: the `reflections` table uses
    # `content`/`category`. Yep's internal + model-facing vocabulary
    # stays `note`/`tag` — we translate at this DB boundary only.
    payload: dict[str, Any] = {"content": note, "weight": weight}
    if tag:
        payload["category"] = tag
    if failure_class:
        payload["failure_class"] = failure_class
    # metadata is the carrier for C3 provenance + curator markers
    # (kind, do_not_archive, archived_count, etc.). Caller-provided dict
    # only; never auto-injected so existing writers stay byte-identical.
    if metadata is not None:
        if not isinstance(metadata, dict):
            raise TypeError(
                f"metadata must be a dict, got {type(metadata).__name__}")
        payload["metadata"] = metadata
    run_id = _current_agent_session_id()
    if run_id is not None:
        payload["agent_session_id"] = run_id
    if with_embedding:
        try:
            payload["embedding"] = embed(note)
        except Exception as e:
            # Best-effort embeddings (see log_episode). DEBUG, not stdout: the
            # BM25-only default path raises here on every write, and a stdout
            # print would corrupt hook JSON.
            import logging
            logging.getLogger("local_yep.memory").debug(
                "embed unavailable, writing reflection without vector: %s: %s",
                type(e).__name__, e,
            )
    res = get_backend().table("reflections").insert(payload).execute()
    return res.data[0] if res.data else {}


def active_reflections(limit: int = 50) -> list[dict]:
    """All non-superseded reflections, newest first."""
    res = (get_backend().table("reflections")
           # content/category are the canonical column names; alias back to
           # note/tag so the returned dict keeps Yep's vocabulary.
           .select("id,note:content,tag:category,weight,failure_class,created_at")
           .is_("superseded_by", "null")
           .order("created_at", desc=True)
           .limit(limit).execute())
    return res.data or []


def search_reflections(query: str, threshold: float = 0.25, limit: int = 5,
                       kinds: Optional[list[str]] = None,
                       alpha_relevance: Optional[float] = None,
                       alpha_recency: Optional[float] = None,
                       alpha_importance: Optional[float] = None,
                       tau_days: Optional[float] = None) -> list[dict]:
    """Semantic search over reflections.

    ``threshold`` (local relevance-gate semantics, 2026-07-02, owner-approved
    divergence from the cloud contract): gates the RELEVANCE component (BM25
    ``q/(1+q)`` or cosine), NOT the blended score. The old blend-gate at 0.7
    made every weight-1 reflection older than ~3 weeks mathematically
    unrecallable (30-day blend cap ≈ 0.635) — the exact anti-goal of a
    reflection store. Default 0.25, calibrated with
    tests/test_recall_quality.py: good matches score rel 0.78-0.92 in a
    populated store but only ~0.33 in a cold-start store (BM25 IDF collapses
    at tiny N), so the gate is a junk floor, not a selector — ranking + the
    top-N cap select.

    ``kinds`` filters by the reflection tag when provided — values like
    "behavior", "pattern", "mistake", "insight", "preference", "note".
    (In the live DB this column is ``category``; the match_reflections RPC
    aliases it back to ``tag``.) When omitted, all tags are searched. When
    provided, only reflections whose tag is in the list are returned
    (post-filter applied client-side after vector search since the
    match_reflections RPC does not expose a tag filter parameter).

    Weighting params (memory-recall-upgrade PR1; all optional, None =
    use SQL defaults α_rel=0.5, α_rec=0.3, α_imp=0.2, τ_days=14).
    Importance for reflections derives from ``weight``
    (least(coalesce(weight,1.0)/2.0, 1.0)) — a heavier reflection ranks
    higher all else equal.
    """
    # Embedding is OPTIONAL (T2.7) — see search_episodes. Default local path
    # is BM25-only with no embedder pack, so embed() raises; recall lexically.
    try:
        e = embed(query)
    except Exception:
        e = None
    # Pull a larger candidate set when filtering so the caller still gets
    # `limit` results after the tag filter removes some candidates.
    fetch_count = limit * max(3, len(kinds)) if kinds else limit
    rpc_args: dict[str, Any] = {
        "match_threshold": threshold,
        "match_count": fetch_count,
        # Carry raw text for the LOCAL FTS5 leg (cloud RPC keys off embedding).
        "query_text": query,
    }
    if e is not None:
        rpc_args["query_embedding"] = e
    if alpha_relevance is not None:
        rpc_args["alpha_relevance"] = alpha_relevance
    if alpha_recency is not None:
        rpc_args["alpha_recency"] = alpha_recency
    if alpha_importance is not None:
        rpc_args["alpha_importance"] = alpha_importance
    if tau_days is not None:
        rpc_args["tau_days"] = tau_days
    res = get_backend().rpc("match_reflections", rpc_args).execute()
    rows = res.data or []
    if kinds:
        rows = [r for r in rows if r.get("tag") in kinds]
    return rows[:limit]


def supersede_reflection(old_id: str, new_note: str,
                         tag: Optional[str] = None,
                         weight: float = 1.0,
                         failure_class: Optional[str] = None) -> dict:
    """Replace a reflection: insert the new one, point old at it."""
    new = write_reflection(new_note, tag=tag, weight=weight,
                           failure_class=failure_class)
    if new.get("id"):
        get_backend().table("reflections").update(
            {"superseded_by": new["id"]}
        ).eq("id", old_id).execute()
    return new
