"""The memory backend seam (PLAN.md §2 T2.1).

``operations.py`` is written against a fluent, chainable query-builder
surface — ``backend.table(name).select(...).eq(...).order(...).execute()``
plus ``backend.rpc(name, args).execute()`` for the semantic-search functions.
Memory is 100% local: that call surface is served by a local SQLite store at
``~/.local-yep/memory.db``.

This module defines:

* :class:`MemoryBackend` — a :class:`typing.Protocol` documenting the
  query-builder surface ``operations.py`` actually touches: ``.table()`` →
  ``insert / upsert / select / update / delete`` then the chainable filters
  (``eq / is_ / not_.is_ / like / ilike / gte / order / limit``) terminated by
  ``.execute()``; plus ``.rpc(name, args).execute()``. ``.execute()`` returns
  an object exposing ``.data`` (a ``list[dict]``).
* :func:`get_backend` — an ``lru_cache``'d accessor returning the local
  :class:`~local_yep.memory.sqlite_backend.SQLiteBackend`.

Nothing here imports SQLite at module load — the backend is imported lazily
inside :func:`get_backend`, so importing :mod:`local_yep.memory` has no
import-time cost or side effects.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Any, Protocol, Sequence, runtime_checkable


@runtime_checkable
class QueryResult(Protocol):
    """The terminal object ``.execute()`` returns — only ``.data`` is read."""

    data: list[dict]


@runtime_checkable
class QueryBuilder(Protocol):
    """The fluent, chainable query builder ``operations.py`` uses.

    Every filter/ordering method returns a builder (so calls chain) and
    ``execute()`` runs the query. Only the methods ``operations.py`` actually
    uses are declared. ``not_`` is a property exposing a negated-filter
    builder (``client.table(...).not_.is_(col, "null")``).
    """

    # --- statement kind (chosen once, off `.table(name)`) ---
    def insert(self, payload: dict | Sequence[dict]) -> "QueryBuilder": ...
    def upsert(self, payload: dict | Sequence[dict],
               on_conflict: str | None = ...) -> "QueryBuilder": ...
    def select(self, columns: str = ...) -> "QueryBuilder": ...
    def update(self, payload: dict) -> "QueryBuilder": ...
    def delete(self) -> "QueryBuilder": ...

    # --- chainable filters / modifiers ---
    def eq(self, column: str, value: Any) -> "QueryBuilder": ...
    def is_(self, column: str, value: Any) -> "QueryBuilder": ...
    def like(self, column: str, pattern: str) -> "QueryBuilder": ...
    def ilike(self, column: str, pattern: str) -> "QueryBuilder": ...
    def gte(self, column: str, value: Any) -> "QueryBuilder": ...
    def order(self, column: str, desc: bool = ...) -> "QueryBuilder": ...
    def limit(self, count: int) -> "QueryBuilder": ...

    @property
    def not_(self) -> "QueryBuilder": ...

    def execute(self) -> QueryResult: ...


@runtime_checkable
class MemoryBackend(Protocol):
    """The minimal client surface ``operations.py`` requires.

    Implemented by :class:`SQLiteBackend` (local). Exposes:

    * ``table(name)`` → a :class:`QueryBuilder` for that table.
    * ``rpc(name, args)`` → a :class:`QueryBuilder` whose ``execute()`` runs
      the named semantic-search function (``match_episodes`` /
      ``match_episodes_hybrid`` / ``match_reflections``).
    """

    def table(self, name: str) -> QueryBuilder: ...
    def rpc(self, name: str, args: dict | None = ...) -> QueryBuilder: ...


# ---------------------------------------------------------------------------
# Accessor — operations.py's singleton backend handle.
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def get_backend() -> MemoryBackend:
    """Return the process-wide memory backend.

    The local :class:`SQLiteBackend` over ``~/.local-yep/memory.db`` — no
    network, no env required. Cached so all callers share one instance.
    """
    from .sqlite_backend import SQLiteBackend

    return SQLiteBackend()
