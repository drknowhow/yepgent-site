"""Lightweight subagent context variable used to stamp memory writes.

Ported (trimmed) from the source repo's ``src/core/_subagent_ctx.py``. In the
source, ``src.core.subagent`` sets ``_CURRENT_RUN`` at the start of each
subagent execution and resets it in a ``finally`` block; ``operations`` reads
it via :func:`get_current_subagent_run` to stamp the writing run's id onto
facts / reflections / episodes for forensic traceability.

Local Yep has no in-process subagent stack yet, so this is effectively always
``None`` — but we keep the seam so :mod:`local_yep.memory.operations` ports
over byte-for-byte. The module is intentionally minimal (just the contextvar
and its accessor) and imports nothing Yep-internal, so it can be imported from
anywhere without pulling in heavier layers.
"""
from __future__ import annotations

import contextvars
from typing import Optional

# Task-local via contextvars so it stays correct even if multiple subagent
# executions ever run concurrently in-process.
#
# Value shape: {"run_id": <uuid-str>, "mode": <str>, ...}
# None when called from the main loop (no subagent context).
_CURRENT_RUN: contextvars.ContextVar[Optional[dict]] = contextvars.ContextVar(
    "_CURRENT_RUN", default=None,
)


def get_current_subagent_run() -> Optional[dict]:
    """Return the current subagent run dict, or ``None`` outside a subagent.

    The returned dict has at least ``run_id`` (uuid str) and ``mode`` when set.
    """
    return _CURRENT_RUN.get()
