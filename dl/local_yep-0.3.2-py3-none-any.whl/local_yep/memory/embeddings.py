"""Optional embeddings seam — NO model, NO Ollama, NO network in core.

Local Yep's default recall is FTS5 BM25 + the Generative-Agents scoring
formula in Python (PLAN.md D3). Semantic embeddings are an **optional
toolspace pack** (PLAN.md §2 T2.7 / T4.4), never required by the core path.

This module preserves the source repo's ``embed()`` surface so the ported
writers (``log_episode`` / ``write_reflection``) and the SQLite backend can
call it inside their existing best-effort ``try/except`` blocks. With no
embedder pack installed it simply raises ``EmbeddingUnavailable`` — which the
writers already swallow, logging the row WITHOUT a vector. Nothing here
imports Ollama or touches the network.

A pack installs an embedder by calling :func:`register_embedder` with a
callable ``str -> Sequence[float]`` (e.g. a local ONNX/fastembed model). Until
then, ``embed`` is a no-op that fails fast.

MRL truncation (Matryoshka Representation Learning)
----------------------------------------------------
If a registered model emits more dims than ``EMBEDDING_DIMS`` (env, default 0 =
native), the prefix is sliced and L2-renormalised so cosine recall still works
(nomic-style MRL). Off by default.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Callable, Optional, Sequence


class EmbeddingUnavailable(RuntimeError):
    """Raised by :func:`embed` when no embedder pack is installed.

    A subclass of ``RuntimeError`` so the writers' broad ``except Exception``
    keeps working unchanged — the row is logged without a vector and stays
    recoverable via FTS5 / SQL, just not via semantic search.
    """


# MRL truncation: set EMBEDDING_DIMS to a positive int <= the model's native
# dims to enable Matryoshka truncation. 0 or unset = native.
_EMBEDDING_DIMS_RAW = os.environ.get("EMBEDDING_DIMS", "0")
try:
    EMBEDDING_DIMS: int = max(0, int(_EMBEDDING_DIMS_RAW))
except ValueError:
    EMBEDDING_DIMS = 0

_EMBED_CACHE_SIZE = int(os.environ.get("YEP_EMBED_CACHE_SIZE", "256"))

# The currently-installed embedder, or None when no pack is present (default).
# A pack registers a callable ``str -> Sequence[float]``.
_EMBEDDER: Optional[Callable[[str], Sequence[float]]] = None


def register_embedder(fn: Optional[Callable[[str], Sequence[float]]]) -> None:
    """Install (or, with ``None``, uninstall) the embedder used by :func:`embed`.

    A toolspace embedder pack calls this at import/activation time. Passing
    ``None`` reverts to the default no-embedder state. Clears the per-process
    cache so a model swap takes effect immediately.
    """
    global _EMBEDDER
    _EMBEDDER = fn
    clear_embed_cache()


def has_embedder() -> bool:
    """True when an embedder pack is installed (semantic recall available)."""
    return _EMBEDDER is not None


def _mrl_truncate(vec: Sequence[float], dims: int) -> list[float]:
    """Truncate an MRL vector to ``dims`` and L2-normalise it.

    MRL vectors have meaningful prefixes, but cosine similarity requires a
    unit-length vector — renormalise after slicing.
    """
    sliced = list(vec[:dims])
    norm = sum(x * x for x in sliced) ** 0.5
    if norm == 0.0:
        return sliced
    return [x / norm for x in sliced]


@lru_cache(maxsize=_EMBED_CACHE_SIZE)
def _embed_cached(text: str) -> tuple[float, ...]:
    if _EMBEDDER is None:
        raise EmbeddingUnavailable(
            "no embedder pack installed — install a local-yep embedder pack "
            "to enable semantic recall (default recall is FTS5 BM25)"
        )
    vec = list(_EMBEDDER(text))
    if EMBEDDING_DIMS > 0 and len(vec) > EMBEDDING_DIMS:
        vec = _mrl_truncate(vec, EMBEDDING_DIMS)
    return tuple(vec)


def embed(text: str) -> list[float]:
    """Return the embedding vector for ``text`` from the installed pack.

    Cached per-process via LRU on the text. Returns a fresh list each call so
    callers may mutate it freely.

    Raises :class:`EmbeddingUnavailable` when no embedder pack is installed
    (the default local state) — writers catch this and store the row without
    a vector. Raises ``ValueError`` on empty input.
    """
    if not text or not text.strip():
        raise ValueError("Cannot embed empty text")
    return list(_embed_cached(text))


def clear_embed_cache() -> None:
    """Drop the embedding cache. Intended for tests / model swaps."""
    _embed_cached.cache_clear()
