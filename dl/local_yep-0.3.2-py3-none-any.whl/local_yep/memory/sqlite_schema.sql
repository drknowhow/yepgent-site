-- Local Yep — local SQLite memory store (PLAN.md §2 T2.2).
--
-- Defines the `facts` / `episodes` / `reflections` tables and their columns
-- (agent_session, threads, content/category) that operations.py reads and
-- writes. The storage engine is stdlib sqlite3 + FTS5 — entirely local.
--
-- Differences from the Postgres source, all storage-engine-driven:
--   * uuid PKs   -> TEXT (Python-side uuid4 hex; SQLite has no uuid type).
--   * jsonb      -> TEXT holding a JSON document (operations.py already
--                   round-trips dicts; the backend json.dumps/loads at the
--                   boundary so callers still see dicts).
--   * vector(768)-> nullable BLOB (raw float32 bytes). Embeddings are an
--                   OPTIONAL pack (T2.7); NULL on the default BM25-only path.
--   * timestamptz-> TEXT ISO-8601 UTC (e.g. 2026-06-25T10:00:00+00:00),
--                   default via strftime so they sort/compare lexically.
--
-- Lexical recall is FTS5: three external-content (`content=`) shadow tables
-- over the substantive text columns, kept in sync by AFTER INSERT/UPDATE/
-- DELETE triggers using the standard 'delete' rowid pattern. BM25 over these
-- shadows -> 0..1 relevance -> the Generative-Agents re-rank (done in Python,
-- T2.4). All three shadows use the `porter unicode61` tokenizer (schema v2,
-- 2026-07-02) so morphological variants match ("migrating" finds
-- "migration"); a tokenizer cannot be ALTERed, so pre-v2 stores are rebuilt
-- by the schema-version ladder in sqlite_backend._bootstrap_schema.
-- Idempotent: every object is `IF NOT EXISTS`, so this runs cleanly on
-- every `yepgent init`.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- meta — single-row-per-key store. Pins the embedding dimension at DB create
-- so a later embedder pack can't silently mix incompatible vector widths
-- (T2.7 refuses to mix dims). Also a natural home for a schema-version tag.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- ---------------------------------------------------------------------------
-- facts — content-addressable key/value store. `key` UNIQUE drives the upsert
-- (write_fact uses ON CONFLICT(key)). `metadata` carries the fact-history
-- drift ring (write_fact's _FACT_HISTORY_CAP). `value` shadowed for search.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS facts (
    id                TEXT PRIMARY KEY,
    key               TEXT NOT NULL UNIQUE,
    value             TEXT NOT NULL,
    embedding         BLOB,                         -- float32 bytes, NULL by default (optional pack)
    confidence        REAL DEFAULT 1.0,             -- 0..1 uncertainty marker
    source            TEXT,                         -- where this came from
    metadata          TEXT,                         -- JSON: fact_history ring etc.
    agent_session_id  TEXT,                         -- writing subagent run id
    created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS facts_updated_idx ON facts (updated_at DESC);

-- ---------------------------------------------------------------------------
-- episodes — append-only turn/event log. role in
-- ('user'|'assistant'|'system'|'event'); importance re-rank keys off it.
-- summary+content shadowed for search; embedding nullable (optional pack).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS episodes (
    id                TEXT PRIMARY KEY,
    role              TEXT NOT NULL,                -- user|assistant|system|event
    content           TEXT NOT NULL,
    summary           TEXT,                         -- optional retrieval summary
    embedding         BLOB,                         -- float32 bytes, NULL by default
    metadata          TEXT,                         -- JSON
    thread_id         TEXT,                         -- conversation attribution
    agent_session_id  TEXT,                         -- writing subagent run id
    occurred_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS episodes_occurred_idx ON episodes (occurred_at DESC);
CREATE INDEX IF NOT EXISTS episodes_role_idx     ON episodes (role);
CREATE INDEX IF NOT EXISTS episodes_thread_idx   ON episodes (thread_id);

-- ---------------------------------------------------------------------------
-- reflections — self-knowledge. Canonical column names are content/category;
-- operations.py aliases them back to note/tag at the boundary.
-- superseded_by chains revisions. content shadowed for search.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reflections (
    id                TEXT PRIMARY KEY,
    content           TEXT NOT NULL,                -- the reflection body (note)
    category          TEXT,                         -- surface tag
    weight            REAL DEFAULT 1.0,             -- behavioral influence
    embedding         BLOB,                         -- float32 bytes, NULL by default
    failure_class     TEXT,                         -- reasoning-failure label
    superseded_by     TEXT REFERENCES reflections(id),
    source_episodes   TEXT,                         -- JSON array of episode ids
    metadata          TEXT,                         -- JSON
    agent_session_id  TEXT,                         -- writing subagent run id
    created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS reflections_active_idx
    ON reflections (created_at DESC) WHERE superseded_by IS NULL;

-- ===========================================================================
-- FTS5 external-content shadows. `content=` points each shadow at its base
-- table; `content_rowid=rowid` ties FTS rows to the base table's rowid. We do
-- NOT store the text twice — FTS reads the base table for content. Triggers
-- keep the inverted index in step using the documented 'delete' command.
-- ===========================================================================

-- episodes(summary, content)
CREATE VIRTUAL TABLE IF NOT EXISTS episodes_fts USING fts5(
    summary,
    content,
    content='episodes',
    content_rowid='rowid',
    tokenize = 'porter unicode61'
);

CREATE TRIGGER IF NOT EXISTS episodes_ai AFTER INSERT ON episodes BEGIN
    INSERT INTO episodes_fts(rowid, summary, content)
    VALUES (new.rowid, new.summary, new.content);
END;
CREATE TRIGGER IF NOT EXISTS episodes_ad AFTER DELETE ON episodes BEGIN
    INSERT INTO episodes_fts(episodes_fts, rowid, summary, content)
    VALUES ('delete', old.rowid, old.summary, old.content);
END;
CREATE TRIGGER IF NOT EXISTS episodes_au AFTER UPDATE ON episodes BEGIN
    INSERT INTO episodes_fts(episodes_fts, rowid, summary, content)
    VALUES ('delete', old.rowid, old.summary, old.content);
    INSERT INTO episodes_fts(rowid, summary, content)
    VALUES (new.rowid, new.summary, new.content);
END;

-- reflections(content)
CREATE VIRTUAL TABLE IF NOT EXISTS reflections_fts USING fts5(
    content,
    content='reflections',
    content_rowid='rowid',
    tokenize = 'porter unicode61'
);

CREATE TRIGGER IF NOT EXISTS reflections_ai AFTER INSERT ON reflections BEGIN
    INSERT INTO reflections_fts(rowid, content) VALUES (new.rowid, new.content);
END;
CREATE TRIGGER IF NOT EXISTS reflections_ad AFTER DELETE ON reflections BEGIN
    INSERT INTO reflections_fts(reflections_fts, rowid, content)
    VALUES ('delete', old.rowid, old.content);
END;
CREATE TRIGGER IF NOT EXISTS reflections_au AFTER UPDATE ON reflections BEGIN
    INSERT INTO reflections_fts(reflections_fts, rowid, content)
    VALUES ('delete', old.rowid, old.content);
    INSERT INTO reflections_fts(rowid, content) VALUES (new.rowid, new.content);
END;

-- facts(value)
CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
    value,
    content='facts',
    content_rowid='rowid',
    tokenize = 'porter unicode61'
);

CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts BEGIN
    INSERT INTO facts_fts(rowid, value) VALUES (new.rowid, new.value);
END;
CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, value)
    VALUES ('delete', old.rowid, old.value);
END;
CREATE TRIGGER IF NOT EXISTS facts_au AFTER UPDATE ON facts BEGIN
    INSERT INTO facts_fts(facts_fts, rowid, value)
    VALUES ('delete', old.rowid, old.value);
    INSERT INTO facts_fts(rowid, value) VALUES (new.rowid, new.value);
END;
