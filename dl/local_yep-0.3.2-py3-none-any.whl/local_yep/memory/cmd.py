"""``yepgent memory`` maintenance verbs (PLAN.md §2 T2.8).

Three subcommands over the local SQLite store at ``~/.local-yep/memory.db``:

    yepgent memory reindex          FTS5 'rebuild' (+ re-embed NULL rows if a pack
                                is installed) — restores BM25 parity after a
                                forced desync and backfills vectors a later
                                embedder pack can now produce.
    yepgent memory backup [--out P] consistent on-disk copy via ``VACUUM INTO``
                                (atomic, no WAL torn-write) — the copy opens
                                cleanly and passes ``PRAGMA integrity_check``.
    yepgent memory stats            row counts, FTS consistency (base vs shadow
                                row parity), and embedded-vs-NULL vector counts.

All three are pure-local: stdlib ``sqlite3`` only, no network, no Ollama. The
CLI is wired in :mod:`local_yep.cli` — ``yepgent memory <verb> …`` forwards the
remaining argv here via :func:`main`.
"""
from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path
from typing import Optional


# Tables that carry an FTS5 external-content shadow (base -> shadow).
_FTS_TABLES = {
    "episodes": "episodes_fts",
    "reflections": "reflections_fts",
    "facts": "facts_fts",
}

# Tables that carry an optional embedding BLOB column.
_EMBEDDING_TABLES = ("episodes", "reflections", "facts")


def _db_path() -> Path:
    """Resolve the memory DB path through the shared home (never re-derived)."""
    from local_yep.home import MEMORY_DB, bootstrap

    bootstrap()  # idempotent; guarantees the home + db file exist
    return MEMORY_DB


def _connect(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn


def _scalar(conn: sqlite3.Connection, sql: str, params=()) -> int:
    row = conn.execute(sql, params).fetchone()
    return int(row[0]) if row and row[0] is not None else 0


def _fts_indexed_count(conn: sqlite3.Connection, fts: str) -> int:
    """Number of documents the FTS5 shadow actually has indexed.

    Uses the FTS5 ``%_docsize`` shadow table (one row per indexed doc), which
    — unlike ``count(*)`` on an external-content FTS table — reflects the true
    index state and drops to 0 after a ``'delete-all'``. Returns ``-1`` if the
    shadow is missing (an unexpected/non-FTS5 table) so the caller flags it.
    """
    try:
        return _scalar(conn, f"SELECT count(*) FROM {fts}_docsize")
    except sqlite3.OperationalError:
        return -1


# ---------------------------------------------------------------------------
# reindex
# ---------------------------------------------------------------------------
def _reindex(args: argparse.Namespace) -> int:
    """Rebuild every FTS5 shadow, then re-embed NULL rows if a pack is present.

    The ``'rebuild'`` command drops and reconstructs the inverted index from
    the base (content) table — the documented FTS5 fix for a shadow that has
    drifted out of sync with its base table. Re-embedding only runs when an
    embedder pack is installed (``embeddings.has_embedder()``); on the default
    BM25-only path the embedding columns stay NULL and reindex is FTS-only.
    """
    path = _db_path()
    conn = _connect(path)
    try:
        for base, fts in _FTS_TABLES.items():
            conn.execute(
                f"INSERT INTO {fts}({fts}) VALUES('rebuild')"
            )
        conn.commit()
        print(f"reindex: rebuilt {len(_FTS_TABLES)} FTS5 index(es) "
              f"({', '.join(_FTS_TABLES.values())})")

        # Optional embedding backfill — only when a pack is installed.
        re_embedded = _reembed_null_rows(conn)
        if re_embedded is None:
            print("reindex: no embedder pack installed — "
                  "embedding columns left NULL (default BM25-only path)")
        else:
            print(f"reindex: re-embedded {re_embedded} NULL-vector row(s)")
        conn.commit()
        return 0
    finally:
        conn.close()


def _reembed_null_rows(conn: sqlite3.Connection) -> Optional[int]:
    """Backfill embeddings for rows whose vector is NULL.

    Returns the number of rows re-embedded, or ``None`` when no embedder pack
    is installed (the signal that the BM25-only path is in effect). Uses the
    memory subsystem's own ``embed`` + ``_pack_embedding`` so the stored bytes
    match what the writers produce, and honours the pinned embedding dim via
    the backend's enforcement (a wrong-dim pack raises before any write).
    """
    from local_yep.memory.embeddings import embed, has_embedder
    from local_yep.memory.sqlite_backend import _pack_embedding

    # Activate the optional embedder pack (fastembed) if installed — reindex is a
    # warm/explicit context where loading the model is appropriate. No-op when
    # the extra isn't installed (recall stays BM25-only).
    try:
        from local_yep.memory import activate_embeddings
        activate_embeddings()
    except Exception:
        pass

    if not has_embedder():
        return None

    # Read the pinned embedding dim (T2.7). The re-embed path writes vectors
    # via a direct UPDATE rather than the backend's _insert_row, so we enforce
    # the dim-pin here too: a pack emitting a different width must raise a clear
    # ValueError naming both dims rather than silently storing mixed widths.
    dim_row = conn.execute(
        "SELECT value FROM meta WHERE key='embedding_dim'"
    ).fetchone()
    pinned = int(dim_row[0]) if dim_row and dim_row[0] is not None else None

    # The text source per table mirrors the writers: episodes embed
    # (summary or content); reflections embed the note (content column).
    sources = {
        "episodes": "COALESCE(summary, content)",
        "reflections": "content",
        "facts": "key || ': ' || value",
    }
    total = 0
    for table in _EMBEDDING_TABLES:
        text_expr = sources[table]
        rows = conn.execute(
            f"SELECT id, {text_expr} AS txt FROM {table} "
            f"WHERE embedding IS NULL AND {text_expr} IS NOT NULL"
        ).fetchall()
        for row in rows:
            txt = row["txt"]
            if not txt or not str(txt).strip():
                continue
            try:
                vec = embed(str(txt))
            except Exception:
                continue
            if pinned is None:
                # Legacy/unpinned store: adopt the first width seen.
                pinned = len(vec)
                conn.execute(
                    "INSERT OR REPLACE INTO meta(key, value) "
                    "VALUES ('embedding_dim', ?)",
                    (str(pinned),),
                )
            elif len(vec) != pinned:
                raise ValueError(
                    f"embedding dimension mismatch during reindex: this "
                    f"memory.db is pinned to {pinned}-dim vectors but the "
                    f"installed embedder pack emits {len(vec)}-dim vectors. "
                    f"Re-embedding at a different width would corrupt cosine "
                    f"recall. Use an embedder matching the pinned dimension "
                    f"({pinned}), or rebuild the store."
                )
            conn.execute(
                f"UPDATE {table} SET embedding = ? WHERE id = ?",
                (_pack_embedding(vec), row["id"]),
            )
            total += 1
    return total


# ---------------------------------------------------------------------------
# backup
# ---------------------------------------------------------------------------
def _backup(args: argparse.Namespace) -> int:
    """Write a consistent copy of the DB via ``VACUUM INTO``.

    ``VACUUM INTO`` produces a fully-checkpointed, defragmented snapshot in a
    single transaction — no torn WAL pages — so the copy opens cleanly and
    passes ``PRAGMA integrity_check`` even if the live DB is mid-write. The
    destination must not already exist (SQLite refuses to overwrite), so we
    fail clearly rather than clobbering.
    """
    path = _db_path()
    out = Path(args.out) if args.out else path.with_suffix(
        path.suffix + ".backup"
    )
    if out.exists():
        print(f"backup: refusing to overwrite existing file {out}",
              file=sys.stderr)
        return 1
    out.parent.mkdir(parents=True, exist_ok=True)

    conn = _connect(path)
    try:
        # VACUUM INTO takes a string literal path; bind via parameter is not
        # supported, so quote-escape the path defensively.
        dest = str(out).replace("'", "''")
        conn.execute(f"VACUUM INTO '{dest}'")
    finally:
        conn.close()

    # Verify the snapshot opens and is structurally sound.
    check = _connect(out)
    try:
        result = check.execute("PRAGMA integrity_check").fetchone()
        ok = result and result[0] == "ok"
    finally:
        check.close()
    if not ok:
        print(f"backup: WARNING integrity_check did not return 'ok' for {out}",
              file=sys.stderr)
        return 1
    size = out.stat().st_size
    print(f"backup: wrote {out} ({size} bytes) — integrity_check ok")
    return 0


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------
def _stats(args: argparse.Namespace) -> int:
    """Print row counts, FTS consistency, and embedded-vs-NULL vector counts."""
    path = _db_path()
    conn = _connect(path)
    try:
        print(f"memory.db: {path}")

        # Base row counts.
        counts = {
            t: _scalar(conn, f"SELECT count(*) FROM {t}")
            for t in ("facts", "episodes", "reflections")
        }
        print("rows:")
        for t, n in counts.items():
            print(f"  {t:<12} {n}")

        # FTS5 consistency: base row count vs the number of rows actually
        # INDEXED by the FTS5 shadow. For an external-content FTS5 table,
        # `SELECT count(*) FROM <fts>` is derived from the base content table,
        # so it CANNOT detect index drift (e.g. an `'delete-all'` that empties
        # the index leaves count(*) reporting the base count). The truthful
        # signal is the `%_docsize` shadow, which holds exactly one row per
        # INDEXED document and drops to 0 on `'delete-all'`, then is restored by
        # `'rebuild'` — so it actually catches a desync that `reindex` fixes.
        print("fts consistency (base == indexed):")
        all_ok = True
        for base, fts in _FTS_TABLES.items():
            base_n = counts.get(base, _scalar(conn, f"SELECT count(*) FROM {base}"))
            indexed_n = _fts_indexed_count(conn, fts)
            ok = base_n == indexed_n
            all_ok = all_ok and ok
            flag = "ok" if ok else "DESYNC"
            print(f"  {base:<12} base={base_n} indexed={indexed_n} [{flag}]")
        if not all_ok:
            print("  -> run `yepgent memory reindex` to rebuild the FTS shadows")

        # Embedded-vs-NULL vector counts per embedding-bearing table.
        print("embeddings (vector present vs NULL):")
        for t in _EMBEDDING_TABLES:
            embedded = _scalar(
                conn, f"SELECT count(*) FROM {t} WHERE embedding IS NOT NULL"
            )
            null = _scalar(
                conn, f"SELECT count(*) FROM {t} WHERE embedding IS NULL"
            )
            print(f"  {t:<12} embedded={embedded} null={null}")

        # Pinned embedding dimension (T2.7).
        dim_row = conn.execute(
            "SELECT value FROM meta WHERE key='embedding_dim'"
        ).fetchone()
        pinned = dim_row[0] if dim_row else "(unset)"
        print(f"embedding_dim (pinned): {pinned}")
        return 0
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# argparse wiring
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yepgent memory",
        description="Local Yep memory-store maintenance (SQLite, 100% local).",
    )
    sub = parser.add_subparsers(dest="verb", metavar="<verb>")

    p_reindex = sub.add_parser(
        "reindex",
        help="rebuild FTS5 indexes (+ re-embed NULL rows if a pack is installed)",
    )
    p_reindex.set_defaults(func=_reindex)

    p_backup = sub.add_parser(
        "backup",
        help="write a consistent copy via VACUUM INTO",
    )
    p_backup.add_argument(
        "--out",
        default=None,
        help="destination path (default: <memory.db>.backup; must not exist)",
    )
    p_backup.set_defaults(func=_backup)

    p_stats = sub.add_parser(
        "stats",
        help="row counts, FTS consistency, embedded-vs-null vector counts",
    )
    p_stats.set_defaults(func=_stats)

    return parser


def main(argv: Optional[list[str]] = None) -> int:
    """Entry point forwarded from ``local_yep.cli`` for ``yepgent memory …``."""
    parser = build_parser()
    args = parser.parse_args(argv if argv is not None else sys.argv[1:])
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help(sys.stderr)
        return 1
    return int(func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
