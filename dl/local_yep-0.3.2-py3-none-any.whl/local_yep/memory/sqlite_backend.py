"""Local SQLite memory backend (PLAN.md §2 T2.2 / T2.3 / T2.4 seam).

Implements the :class:`~local_yep.memory.backend.MemoryBackend` protocol over a
single local SQLite file (``~/.local-yep/memory.db`` by default). It does two
things:

1. **DDL bootstrap** — applies ``sqlite_schema.sql`` (the 3 base tables, the
   FTS5 shadows + sync triggers, and the ``meta`` table) idempotently on
   first connect, and pins the embedding dimension.

2. **A fluent query builder** — :class:`_QueryBuilder` accumulates the chain
   (``table().select().eq().order().limit().execute()`` etc.) and translates
   it to SQL at ``execute()`` time, returning a ``_Result`` with a ``.data``
   ``list[dict]``, the shape :mod:`local_yep.memory.operations` consumes.

JSON columns (``metadata`` on all tables, ``source_episodes`` on reflections)
are transparently ``json.dumps``'d on write and ``json.loads``'d on read so the
ported writers/readers keep passing and receiving dicts. ``embedding`` is a
nullable BLOB (raw float32 bytes); on the default BM25-only path it is always
NULL — the writers' existing best-effort ``try/except`` around ``embed()``
tolerates the absent embedder pack (T2.7).

The semantic-search RPCs (``match_episodes`` / ``match_episodes_hybrid`` /
``match_reflections``) run FTS5 BM25 over the sanitized query, map BM25 to a
0..1 relevance, then apply the Generative-Agents re-rank
(``score = α_rel·rel + α_rec·recency + α_imp·importance``) in Python — see
:func:`_fts_sanitize` and the ``match_*`` methods below.
"""
from __future__ import annotations

import json
import math
import re
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Sequence

# JSON-document columns, per table. Serialized on write, parsed on read so the
# ported operations.py keeps seeing/storing dicts (the Postgres source used
# jsonb; SQLite has no native JSON type, only TEXT).
_JSON_COLUMNS: dict[str, set[str]] = {
    "facts": {"metadata"},
    "episodes": {"metadata"},
    "reflections": {"metadata", "source_episodes"},
}

# Raw-bytes columns (float32 vector blobs). Pass through untouched.
_BLOB_COLUMNS: dict[str, set[str]] = {
    "episodes": {"embedding"},
    "reflections": {"embedding"},
    "facts": {"embedding"},
}

# Columns the backend auto-fills on insert when the caller didn't provide them
# (the Postgres source relied on column DEFAULTs / gen_random_uuid()).
_ID_COLUMN = "id"

# Default embedding dimension pinned in `meta` at DB create. The embedder pack
# (T2.7) reads/validates this; the core BM25 path ignores it.
_DEFAULT_EMBEDDING_DIM = 768

_SCHEMA_PATH = Path(__file__).with_name("sqlite_schema.sql")

# Current schema version (stored in ``meta.schema_version``).
#   1 — original layout: unicode61 FTS tokenizer, implicit-AND sanitize era.
#   2 — FTS5 shadows rebuilt with the ``porter unicode61`` tokenizer
#       (2026-07-02): a tokenizer is fixed at CREATE VIRTUAL TABLE time, so
#       existing stores are migrated by drop+recreate+rebuild (see
#       :func:`_migrate_v1_to_v2`).
# Bumping this requires appending a migration step to ``_MIGRATIONS``.
_SCHEMA_VERSION = 2


def _new_id() -> str:
    """Generate a row id. uuid4 hex — the Postgres source used uuid PKs."""
    return uuid.uuid4().hex


class _Result:
    """The query response object: only ``.data`` is consumed."""

    __slots__ = ("data",)

    def __init__(self, data: list[dict]):
        self.data = data


class _QueryBuilder:
    """Accumulates a fluent query chain, runs it on ``execute()``.

    One builder is created per ``backend.table(name)`` / ``backend.rpc(...)``
    call. The statement kind (insert/upsert/select/update/delete or rpc) is
    chosen by the first call off the builder; subsequent calls add filters,
    ordering, and a limit. ``execute()`` compiles to SQL and returns a
    :class:`_Result`.
    """

    def __init__(self, backend: "SQLiteBackend", table: str):
        self._backend = backend
        self._table = table
        self._op: Optional[str] = None          # insert|upsert|select|update|delete
        self._payload: Any = None               # dict | list[dict] for write ops
        self._on_conflict: Optional[str] = None
        self._columns: str = "*"
        self._filters: list[tuple] = []          # (kind, column, value), kind in {eq,is,is_not,like,ilike,gte}
        self._order: Optional[tuple[str, bool]] = None  # (column, desc)
        self._limit: Optional[int] = None
        self._negate_next = False                # set by `.not_`

    # --- statement kind ---------------------------------------------------
    def insert(self, payload: dict | Sequence[dict]) -> "_QueryBuilder":
        self._op = "insert"
        self._payload = payload
        return self

    def upsert(self, payload: dict | Sequence[dict],
               on_conflict: Optional[str] = None) -> "_QueryBuilder":
        self._op = "upsert"
        self._payload = payload
        self._on_conflict = on_conflict
        return self

    def select(self, columns: str = "*") -> "_QueryBuilder":
        self._op = "select"
        self._columns = columns
        return self

    def update(self, payload: dict) -> "_QueryBuilder":
        self._op = "update"
        self._payload = payload
        return self

    def delete(self) -> "_QueryBuilder":
        self._op = "delete"
        return self

    # --- filters / modifiers ---------------------------------------------
    def _add_filter(self, kind: str, column: str, value: Any) -> "_QueryBuilder":
        if self._negate_next:
            kind = f"not_{kind}"
            self._negate_next = False
        self._filters.append((kind, column, value))
        return self

    def eq(self, column: str, value: Any) -> "_QueryBuilder":
        return self._add_filter("eq", column, value)

    def is_(self, column: str, value: Any) -> "_QueryBuilder":
        # The query API uses the literal string "null" for IS NULL.
        return self._add_filter("is", column, value)

    def like(self, column: str, pattern: str) -> "_QueryBuilder":
        return self._add_filter("like", column, pattern)

    def ilike(self, column: str, pattern: str) -> "_QueryBuilder":
        return self._add_filter("ilike", column, pattern)

    def gte(self, column: str, value: Any) -> "_QueryBuilder":
        return self._add_filter("gte", column, value)

    def order(self, column: str, desc: bool = False) -> "_QueryBuilder":
        self._order = (column, desc)
        return self

    def limit(self, count: int) -> "_QueryBuilder":
        self._limit = count
        return self

    @property
    def not_(self) -> "_QueryBuilder":
        # `.not_.is_(col, "null")` → negate the *next* filter only.
        self._negate_next = True
        return self

    # --- terminal ---------------------------------------------------------
    def execute(self) -> _Result:
        if self._op == "select":
            return self._exec_select()
        if self._op in ("insert", "upsert"):
            return self._exec_write()
        if self._op == "update":
            return self._exec_update()
        if self._op == "delete":
            return self._exec_delete()
        raise RuntimeError(f"no operation selected on table {self._table!r}")

    # --- SQL compilation --------------------------------------------------
    def _where(self) -> tuple[str, list]:
        clauses: list[str] = []
        params: list = []
        for kind, col, val in self._filters:
            if kind in ("is", "not_is"):
                # .is_(col, "null") / .not_.is_(col, "null").
                is_null = (isinstance(val, str) and val.lower() == "null") or val is None
                if is_null:
                    clauses.append(f"{col} IS {'NOT ' if kind == 'not_is' else ''}NULL")
                else:
                    op = "IS NOT" if kind == "not_is" else "IS"
                    clauses.append(f"{col} {op} ?")
                    params.append(val)
            elif kind == "eq":
                clauses.append(f"{col} = ?")
                params.append(val)
            elif kind == "not_eq":
                clauses.append(f"{col} <> ?")
                params.append(val)
            elif kind == "gte":
                clauses.append(f"{col} >= ?")
                params.append(val)
            elif kind in ("like", "not_like"):
                clauses.append(f"{col} {'NOT ' if kind == 'not_like' else ''}LIKE ? ESCAPE '\\'")
                params.append(val)
            elif kind in ("ilike", "not_ilike"):
                # SQLite LIKE is case-insensitive for ASCII by default — which
                # matches PostgREST ILIKE closely enough for the recall paths
                # (search_facts key/value substring match).
                clauses.append(f"{col} {'NOT ' if kind == 'not_ilike' else ''}LIKE ? ESCAPE '\\'")
                params.append(val)
            else:
                raise ValueError(f"unsupported filter kind: {kind}")
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return where, params

    def _exec_select(self) -> _Result:
        cols_sql, aliases = _parse_select_columns(self._columns)
        sql = f"SELECT {cols_sql} FROM {self._table}"
        where, params = self._where()
        sql += where
        if self._order is not None:
            col, desc = self._order
            sql += f" ORDER BY {col} {'DESC' if desc else 'ASC'}"
        if self._limit is not None:
            sql += " LIMIT ?"
            params.append(self._limit)
        rows = self._backend._query(sql, params)
        data = [self._decode_row(self._table, r, aliases) for r in rows]
        return _Result(data)

    def _exec_write(self) -> _Result:
        payloads = self._payload if isinstance(self._payload, (list, tuple)) else [self._payload]
        out: list[dict] = []
        for payload in payloads:
            row = self._backend._insert_row(
                self._table, dict(payload),
                upsert=(self._op == "upsert"),
                on_conflict=self._on_conflict,
            )
            out.append(self._decode_row(self._table, row, {}))
        return _Result(out)

    def _exec_update(self) -> _Result:
        encoded = _encode_payload(self._table, dict(self._payload))
        set_cols = list(encoded.keys())
        set_sql = ", ".join(f"{c} = ?" for c in set_cols)
        params = [encoded[c] for c in set_cols]
        where, where_params = self._where()
        if self._table in ("facts",):  # facts has updated_at; bump it on update
            set_sql += ", updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')"
        sql = f"UPDATE {self._table} SET {set_sql}{where} RETURNING *"
        rows = self._backend._query(sql, params + where_params)
        return _Result([self._decode_row(self._table, r, {}) for r in rows])

    def _exec_delete(self) -> _Result:
        where, params = self._where()
        sql = f"DELETE FROM {self._table}{where} RETURNING *"
        rows = self._backend._query(sql, params)
        return _Result([self._decode_row(self._table, r, {}) for r in rows])

    def _decode_row(self, table: str, row: dict, aliases: dict[str, str]) -> dict:
        decoded = _decode_row(table, row)
        if aliases:
            # Apply SELECT aliasing (e.g. note:content -> key "note").
            for alias, source in aliases.items():
                if source in decoded:
                    decoded[alias] = decoded.pop(source)
        return decoded


def _parse_select_columns(columns: str) -> tuple[str, dict[str, str]]:
    """Translate a ``.select()`` spec to SQL + an alias map.

    Handles ``"*"``, comma lists like ``"id,role,content"``, and the
    ``alias:source`` form (``note:content,tag:category``).
    Returns ``(sql_column_list, {alias: source_column})``. Aliasing is applied
    in Python after the fetch (rather than ``AS``) so JSON/blob decoding keys
    off the real column name first.
    """
    columns = (columns or "*").strip()
    if columns == "*":
        return "*", {}
    parts = [c.strip() for c in columns.split(",") if c.strip()]
    sql_cols: list[str] = []
    aliases: dict[str, str] = {}
    for part in parts:
        if ":" in part:
            alias, source = (s.strip() for s in part.split(":", 1))
            aliases[alias] = source
            sql_cols.append(source)
        else:
            sql_cols.append(part)
    return ", ".join(sql_cols), aliases


def _encode_payload(table: str, payload: dict) -> dict:
    """Serialize JSON columns to TEXT for storage; pass blobs/scalars through."""
    json_cols = _JSON_COLUMNS.get(table, set())
    out: dict[str, Any] = {}
    for col, val in payload.items():
        if col in json_cols and val is not None and not isinstance(val, (str, bytes)):
            out[col] = json.dumps(val, ensure_ascii=False)
        elif col in _BLOB_COLUMNS.get(table, set()) and isinstance(val, (list, tuple)):
            # An embedding handed in as a float sequence — pack to float32 bytes.
            out[col] = _pack_embedding(val)
        else:
            out[col] = val
    return out


def _decode_row(table: str, row: dict) -> dict:
    """Parse JSON columns back to dicts/lists; unpack embedding blob to floats."""
    json_cols = _JSON_COLUMNS.get(table, set())
    blob_cols = _BLOB_COLUMNS.get(table, set())
    out: dict[str, Any] = {}
    for col, val in row.items():
        if col in json_cols and isinstance(val, str):
            try:
                out[col] = json.loads(val)
            except (TypeError, ValueError):
                out[col] = val
        elif col in blob_cols and isinstance(val, (bytes, bytearray)):
            out[col] = _unpack_embedding(val)
        else:
            out[col] = val
    return out


def _pack_embedding(vec: Sequence[float]) -> bytes:
    import struct
    return struct.pack(f"<{len(vec)}f", *(float(x) for x in vec))


def _unpack_embedding(blob: bytes) -> list[float]:
    import struct
    n = len(blob) // 4
    return list(struct.unpack(f"<{n}f", blob[: n * 4]))


# ---------------------------------------------------------------------------
# Local recall helpers (G3): FTS5 query sanitization, BM25 -> relevance, and
# the Generative-Agents recency/importance tilt. Pure functions so the re-rank
# is trivially testable against a hand-computed score table.
# ---------------------------------------------------------------------------

# A MATCH string that is syntactically valid yet cannot match any indexed
# token, so an empty / all-punctuation query returns zero rows instead of
# raising. The leading underscores + uuid suffix make a real collision
# astronomically unlikely; it is quoted so FTS5 treats it as a bare phrase.
_EMPTY_QUERY_SENTINEL = '"__local_yep_no_match_2f8e1c7a9b__"'

# Token = a run of word characters (letters/digits/underscore). Everything
# else (quotes, *, :, ^, parens, hyphens, #, the AND/OR/NOT/NEAR operators
# once split off, apostrophes) is dropped. ``re.UNICODE`` keeps non-ASCII
# letters so a name like "José" stays searchable.
_TOKEN_RE = re.compile(r"\w+", re.UNICODE)

# Common English function words dropped from MATCH expressions (2026-07-02).
# Conversational queries ("what did we decide about the telegram bot
# deployment") are mostly stopwords; under the OR-join below they would still
# match, but they dilute BM25 and — in small corpora — surface rows sharing
# only a stopword. Dropped ONLY when at least one non-stopword token remains,
# so an all-stopword query still matches literally rather than collapsing to
# the zero-row sentinel.
_FTS_STOPWORDS = frozenset({
    "a", "an", "the", "and", "or", "but", "if", "then", "than", "so",
    "is", "are", "was", "were", "be", "been", "being", "am",
    "do", "does", "did", "done", "doing",
    "have", "has", "had", "having",
    "will", "would", "can", "could", "should", "shall", "may", "might",
    "must",
    "i", "you", "we", "he", "she", "it", "they", "me", "us", "him", "her",
    "them", "my", "your", "our", "his", "its", "their",
    "this", "that", "these", "those",
    "what", "which", "who", "whom", "whose", "when", "where", "why", "how",
    "to", "of", "in", "on", "at", "by", "for", "with", "from", "as",
    "into", "onto", "over", "under", "about", "after", "before", "between",
    "up", "down", "out", "off", "again", "there", "here",
    "not", "no", "nor", "only", "own", "same", "some", "any", "all", "both",
    "each", "few", "more", "most", "other", "such", "just", "very",
    "s", "t", "don", "now", "also", "please",
})


def _fts_sanitize(raw: Any) -> str:
    """Turn an arbitrary user string into a safe FTS5 ``MATCH`` expression.

    Raw user input routinely contains characters FTS5 parses as query syntax
    — double quotes, ``*``, ``:``, ``^``, ``(``/``)``, ``-``, ``#`` — and the
    bare keywords ``AND`` / ``OR`` / ``NOT`` / ``NEAR``. Feeding those through
    unescaped raises ``sqlite3.OperationalError: fts5: syntax error``. We
    tokenize to alphanumerics, wrap each token in double quotes (so even a
    lone ``AND`` becomes the literal phrase ``"and"`` rather than the
    operator), and join with ``OR`` (any-term match).

    The OR-join replaces the original implicit-AND join (2026-07-02,
    owner-approved recall fix): conjunctive matching meant a conversational
    query recalled nothing unless EVERY word appeared in a single row, which
    in practice recalled nothing at all. BM25 still ranks multi-term hits far
    above single-term ones, so precision lives in the ranking while recall
    lives in the OR. Common English stopwords (:data:`_FTS_STOPWORDS`) are
    dropped first, provided at least one non-stopword token remains.

    Empty input, or input with no word characters (e.g. ``""`` or ``"***"``),
    yields :data:`_EMPTY_QUERY_SENTINEL`: a valid expression that matches
    nothing. This function NEVER raises on user input.
    """
    if raw is None:
        return _EMPTY_QUERY_SENTINEL
    text = raw if isinstance(raw, str) else str(raw)
    tokens = _TOKEN_RE.findall(text)
    if not tokens:
        return _EMPTY_QUERY_SENTINEL
    content_tokens = [t for t in tokens if t.lower() not in _FTS_STOPWORDS]
    if content_tokens:
        tokens = content_tokens
    # Word chars never include a double quote, so wrapping is injection-safe.
    return " OR ".join(f'"{tok}"' for tok in tokens)


def _bm25_to_relevance(bm25: Optional[float]) -> float:
    """Map an FTS5 ``bm25()`` score to a relevance in ``(0, 1]``.

    FTS5 returns *negative* scores where the most-negative row is the best
    match (a row with no match never reaches here). We negate to get a
    non-negative quality where larger = better, then squash with
    ``q / (1 + q)`` so the result lands in ``[0, 1)`` and is monotonically
    increasing in match quality — the local stand-in for the cloud path's
    cosine ``relevance = 1 - distance``.
    """
    if bm25 is None:
        return 0.0
    quality = -float(bm25)
    if quality <= 0.0:
        return 0.0
    return quality / (1.0 + quality)


def _cosine_relevance(query_vec: Sequence[float],
                      row_vec: Optional[Sequence[float]]) -> Optional[float]:
    """Cosine similarity mapped to a ``[0, 1]`` relevance (T2.7 dense leg).

    Returns ``None`` when the row has no stored embedding (the default
    BM25-only state) so the caller falls back to the BM25 relevance for that
    row. Cosine lives in ``[-1, 1]``; we clamp the negative half to 0 and
    leave the positive half as-is, matching the cloud path's
    ``relevance = 1 - cosine_distance`` (distance = 1 - cosine, so relevance =
    cosine) clamped non-negative. numpy is a declared core dependency.
    """
    if row_vec is None:
        return None
    import numpy as np

    q = np.asarray(query_vec, dtype=np.float64)
    r = np.asarray(row_vec, dtype=np.float64)
    if q.size == 0 or r.size == 0 or q.size != r.size:
        return None
    qn = float(np.linalg.norm(q))
    rn = float(np.linalg.norm(r))
    if qn == 0.0 or rn == 0.0:
        return None
    cos = float(np.dot(q, r) / (qn * rn))
    if cos < 0.0:
        return 0.0
    if cos > 1.0:
        return 1.0
    return cos


def _query_embedding_from_args(args: dict) -> Optional[list[float]]:
    """Extract the dense query vector when a caller supplied one (T2.7).

    ``operations.search_*`` only put ``query_embedding`` in the args dict when
    an embedder pack produced a vector — absent (default) it is missing and
    recall stays BM25-only. Returns a plain ``list[float]`` or ``None``.
    """
    vec = args.get("query_embedding")
    if vec is None:
        return None
    try:
        out = [float(x) for x in vec]
    except (TypeError, ValueError):
        return None
    return out or None


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(value: Any) -> Optional[datetime]:
    """Parse an ISO-8601 timestamp (the schema's ``...Z`` / ``+00:00`` form)."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value).strip()
    if not text:
        return None
    # SQLite stores e.g. '2026-06-25T10:00:00.000Z'. fromisoformat() in 3.11+
    # accepts the trailing 'Z'; normalise it for older interpreters too.
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _recency(ts: Any, tau_days: float, now: Optional[datetime] = None) -> float:
    """``exp(-age_seconds / (tau_days * 86400))`` — the GA recency decay.

    τ defaults to 14 days at the call site. A missing/unparseable timestamp
    is treated as maximally old (recency 0.0) so it can only be carried by
    relevance + importance, never inflated by a bogus 'now'.
    """
    when = _parse_ts(ts)
    if when is None:
        return 0.0
    now = now or _utcnow()
    age_s = (now - when).total_seconds()
    if age_s < 0.0:
        age_s = 0.0  # clock skew / future-dated row: treat as brand new
    denom = float(tau_days) * 86400.0
    if denom <= 0.0:
        return 1.0
    return math.exp(-age_s / denom)


def _episode_importance(role: Optional[str]) -> float:
    """3-tier episode importance: event=1.0 / user|assistant=0.6 / else=0.4."""
    if role == "event":
        return 1.0
    if role in ("user", "assistant"):
        return 0.6
    return 0.4


def _coalesce_alpha(value: Any, default: float) -> float:
    """Use ``value`` when the caller passed one, else the SQL default.

    Matches the RPC contract where ``None`` means "use the default" — the
    Python wrappers only put ``alpha_*`` / ``tau_days`` in the args dict when
    the caller overrode them, but guard against an explicit ``None`` too.
    """
    if value is None:
        return float(default)
    return float(value)


def _query_text_from_args(args: dict) -> str:
    """Extract the human query string from an RPC args dict.

    The cloud RPCs key off ``query_embedding`` for dense recall and
    ``query_text`` for the lexical leg (hybrid only). Locally there is no
    vector on the default path, so we recover the raw text from
    ``query_text`` when present (hybrid), else fall back to any string the
    caller left in ``query`` / ``q``. Anything non-string yields '' which
    :func:`_fts_sanitize` turns into the zero-row sentinel.
    """
    for key in ("query_text", "query", "q"):
        val = args.get(key)
        if isinstance(val, str):
            return val
    return ""


# ---------------------------------------------------------------------------
# Schema-version migration ladder. Each entry is (target_version, fn); fn
# receives the open connection and must be idempotent (safe to re-run if the
# process dies between the step and the version bump). ``_bootstrap_schema``
# walks the ladder in order and stamps ``meta.schema_version`` after each
# completed step.
# ---------------------------------------------------------------------------

def _migrate_v1_to_v2(conn: sqlite3.Connection) -> None:
    """v1 → v2: rebuild the three FTS5 shadows with the porter tokenizer.

    FTS5 tokenizers are fixed at ``CREATE VIRTUAL TABLE`` time (there is no
    ALTER), so upgrading existing stores to stemmed recall requires dropping
    and recreating ``episodes_fts`` / ``reflections_fts`` / ``facts_fts``
    plus their sync triggers, then repopulating each index from its base
    table via the documented ``'rebuild'`` command for external-content
    tables. Base-table data (episodes/reflections/facts rows) is untouched.
    """
    for base in ("episodes", "reflections", "facts"):
        for suffix in ("ai", "ad", "au"):
            conn.execute(f"DROP TRIGGER IF EXISTS {base}_{suffix}")
        conn.execute(f"DROP TABLE IF EXISTS {base}_fts")
    # Recreate at the current layout: the canonical DDL is all IF NOT EXISTS,
    # so re-running it restores exactly the dropped objects (with porter) and
    # touches nothing else.
    conn.executescript(_SCHEMA_PATH.read_text(encoding="utf-8"))
    for shadow in ("episodes_fts", "reflections_fts", "facts_fts"):
        conn.execute(f"INSERT INTO {shadow}({shadow}) VALUES('rebuild')")


_MIGRATIONS: list = [
    (2, _migrate_v1_to_v2),
]


class SQLiteBackend:
    """A :class:`MemoryBackend` over a local SQLite file with FTS5.

    One instance per process (via ``get_backend``'s ``lru_cache``). The
    connection is created lazily, the schema applied on first use, and access
    is guarded by a lock so concurrent hook/MCP callers in one process are
    serialized (SQLite handles cross-process locking itself).
    """

    def __init__(self, db_path: Optional[Path | str] = None):
        if db_path is None:
            from ..home import MEMORY_DB, bootstrap

            bootstrap()  # idempotent; ensures ~/.local-yep/ + the db file exist
            db_path = MEMORY_DB
        self._db_path = Path(db_path)
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None

    # --- connection / bootstrap ------------------------------------------
    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            self._conn = conn
            try:
                self._bootstrap_schema()
            except Exception:
                # Never hand out a connection whose schema state is unknown:
                # e.g. a DB written by a NEWER local-yep must fail loudly on
                # EVERY access, not just the first — a cached half-bootstrapped
                # connection would silently proceed against the wrong schema.
                self._conn = None
                conn.close()
                raise
        return self._conn

    def _bootstrap_schema(self) -> None:
        assert self._conn is not None
        conn = self._conn
        # Fresh-DB detection MUST precede the DDL: after executescript the
        # `meta` table always exists, and a fresh store is born at the
        # CURRENT schema version (the DDL below already carries porter etc.),
        # so it must not walk the ladder.
        fresh = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='meta'"
        ).fetchone() is None
        conn.executescript(_SCHEMA_PATH.read_text(encoding="utf-8"))
        # Pin the embedding dimension once, at create. Refuse to mix later (T2.7).
        cur = conn.execute(
            "SELECT value FROM meta WHERE key = 'embedding_dim'"
        )
        if cur.fetchone() is None:
            conn.execute(
                "INSERT INTO meta(key, value) VALUES ('embedding_dim', ?)",
                (str(_DEFAULT_EMBEDDING_DIM),),
            )
        # Pre-ladder guard, deliberately kept OUTSIDE the ladder: stores
        # created before 2026-06-27 predate facts.embedding, and the PRAGMA
        # check is the correct idempotent detector whether or not the store
        # ever recorded a schema_version. CREATE TABLE IF NOT EXISTS won't add
        # a column to an existing table, so ALTER once here.
        fact_cols = {r[1] for r in conn.execute("PRAGMA table_info(facts)")}
        if "embedding" not in fact_cols:
            conn.execute("ALTER TABLE facts ADD COLUMN embedding BLOB")

        # --- schema-version ladder (2026-07-02) ---
        row = conn.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'"
        ).fetchone()
        if fresh:
            version = _SCHEMA_VERSION
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) "
                "VALUES ('schema_version', ?)",
                (str(version),),
            )
        elif row is None:
            # Existing store with no version row: predates versioning → v1.
            version = 1
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) "
                "VALUES ('schema_version', '1')"
            )
        else:
            try:
                version = int(str(row[0]).strip())
            except ValueError:
                raise RuntimeError(
                    f"memory.db carries an unreadable schema_version "
                    f"{row[0]!r} (expected an integer). Refusing to guess — "
                    f"restore from a `yepgent memory backup` copy or repair "
                    f"the meta table."
                ) from None
        if version > _SCHEMA_VERSION:
            raise RuntimeError(
                f"memory.db is at schema version {version}, but this "
                f"local-yep only supports up to {_SCHEMA_VERSION}. The DB was "
                f"created by a NEWER local-yep — upgrade the package (e.g. "
                f"`pipx upgrade local-yep`) instead of running the old "
                f"version against it. Refusing to open."
            )
        for target, migrate in _MIGRATIONS:
            if version < target:
                migrate(conn)
                conn.execute(
                    "UPDATE meta SET value = ? WHERE key = 'schema_version'",
                    (str(target),),
                )
                conn.commit()  # each completed step is durable on its own
                version = target
        conn.commit()

    # --- low-level helpers ------------------------------------------------
    def _query(self, sql: str, params: Sequence[Any]) -> list[dict]:
        with self._lock:
            cur = self.conn.execute(sql, tuple(params))
            rows = [dict(r) for r in cur.fetchall()]
            if not sql.lstrip().upper().startswith("SELECT"):
                self.conn.commit()
            return rows

    def _insert_row(self, table: str, payload: dict, *, upsert: bool,
                    on_conflict: Optional[str]) -> dict:
        payload = dict(payload)
        if _ID_COLUMN not in payload or not payload.get(_ID_COLUMN):
            payload[_ID_COLUMN] = _new_id()
        # T2.7 dim-pin: an embedding's width must match the dimension pinned in
        # `meta` at DB create. A later pack with a different dim is refused with
        # a ValueError naming BOTH dims, rather than silently storing mixed
        # widths that would corrupt the cosine re-rank.
        if table in _BLOB_COLUMNS:
            for col in _BLOB_COLUMNS[table]:
                vec = payload.get(col)
                if isinstance(vec, (list, tuple)) and len(vec) > 0:
                    self._assert_embedding_dim(len(vec))
        encoded = _encode_payload(table, payload)
        cols = list(encoded.keys())
        placeholders = ", ".join("?" for _ in cols)
        col_sql = ", ".join(cols)
        params = [encoded[c] for c in cols]

        conflict_sql = ""
        if upsert:
            target = on_conflict or _ID_COLUMN
            # Update every supplied column except the conflict key on a clash.
            update_cols = [c for c in cols if c != target]
            if update_cols:
                set_sql = ", ".join(f"{c} = excluded.{c}" for c in update_cols)
                if table == "facts":
                    set_sql += ", updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now')"
                conflict_sql = f" ON CONFLICT({target}) DO UPDATE SET {set_sql}"
            else:
                conflict_sql = f" ON CONFLICT({target}) DO NOTHING"

        sql = (
            f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders})"
            f"{conflict_sql} RETURNING *"
        )
        with self._lock:
            cur = self.conn.execute(sql, tuple(params))
            row = cur.fetchone()
            self.conn.commit()
            if row is not None:
                return dict(row)
            # DO NOTHING with no RETURNING row: fetch the existing row by key.
            target = on_conflict or _ID_COLUMN
            existing = self.conn.execute(
                f"SELECT * FROM {table} WHERE {target} = ?",
                (payload.get(target),),
            ).fetchone()
            return dict(existing) if existing is not None else {}

    # --- MemoryBackend protocol surface ----------------------------------
    def table(self, name: str) -> _QueryBuilder:
        return _QueryBuilder(self, name)

    def rpc(self, name: str, args: Optional[dict] = None) -> "_RpcCall":
        return _RpcCall(self, name, args or {})

    # --- embedding-dim accessor (used by the T2.7 pack) ------------------
    def embedding_dim(self) -> Optional[int]:
        row = self._query(
            "SELECT value FROM meta WHERE key = 'embedding_dim'", []
        )
        return int(row[0]["value"]) if row else None

    def _assert_embedding_dim(self, dim: int) -> None:
        """Refuse to store a vector whose width != the pinned dim (T2.7).

        The embedding dimension is pinned in ``meta`` at DB create. A later
        embedder pack emitting a different width would silently corrupt the
        cosine re-rank (mixed-dimension vectors can't be compared), so we
        fail closed with a clear error naming BOTH the pinned dim and the
        offending one. A NULL/absent pin (legacy DB) accepts the first width
        seen and pins it, so an existing BM25-only store can gain a pack.
        """
        pinned = self.embedding_dim()
        if pinned is None:
            with self._lock:
                self.conn.execute(
                    "INSERT OR REPLACE INTO meta(key, value) "
                    "VALUES ('embedding_dim', ?)",
                    (str(int(dim)),),
                )
                self.conn.commit()
            return
        if dim != pinned:
            raise ValueError(
                f"embedding dimension mismatch: this memory.db is pinned to "
                f"{pinned}-dim vectors but the installed embedder pack emits "
                f"{dim}-dim vectors. Re-embedding at a different width would "
                f"corrupt cosine recall. Use an embedder that matches the "
                f"pinned dimension ({pinned}), or rebuild the store."
            )

    # --- semantic search — local BM25 + Python re-rank (G3) --------------
    #
    # The Postgres source ranked on cosine ``relevance`` from pgvector and
    # blended it with recency + importance in SQL (see
    # ``sql/migrate_match_recency_importance_weighting.sql``). Locally we have
    # no vectors on the default path, so ``relevance`` comes from FTS5 BM25
    # instead; the recency + importance tilt and the final
    # ``score = α_rel·rel + α_rec·rec + α_imp·imp`` blend are reproduced
    # verbatim in Python so ordering matches the cloud contract.
    #
    # Return shapes are byte-identical to the RPCs operations.py consumes:
    #   match_episodes / match_episodes_hybrid ->
    #       {id, role, content, summary, occurred_at, similarity}
    #   match_reflections ->
    #       {id, note, tag, weight, similarity}
    # so ``search_episodes`` / ``search_reflections`` need no source change.

    def match_episodes(self, args: dict) -> list[dict]:
        """BM25 lexical recall over episodes + the recency/importance blend.

        Mirrors the ``match_episodes`` RPC's scoring: ``score = α_rel·rel +
        α_rec·rec + α_imp·imp`` with the episode 3-tier importance table,
        capped at ``match_count`` (top-N by score).

        **Deliberate divergence from the cloud contract (2026-07-02,
        owner-approved — like the 2026-06-27 search_facts divergence):**
        ``match_threshold`` gates the RELEVANCE component (``rel >=
        threshold``), not the blended score. Gating on the blend made old
        rows mathematically unrecallable: with recency = exp(-age/14d), a
        30-day-old row's blend caps at ~0.635 < the old 0.7 default no matter
        how perfect the match. The blend is now used ONLY for ranking.
        Optional ``alpha_*`` / ``tau_days`` override the blend defaults.
        """
        return self._match_episodes(args, threshold_override=None)

    def match_episodes_hybrid(self, args: dict) -> list[dict]:
        """Hybrid recall.

        The live cloud ``match_episodes_hybrid`` is the vector-only-ANN body
        plus the same weighted formula (the RRF path was abandoned; the
        docstring there is stale — see PLAN.md §2). Its only observable
        difference from ``match_episodes`` at the call site is the forced
        ``match_threshold = 0.0`` (``search_episodes`` already passes 0.0).
        Locally we honour the same contract: force the threshold to 0.0 and
        return the top-N candidates by score, so a low-signal query still
        yields up to ``match_count`` rows. Under the relevance-gate semantics
        (2026-07-02) the forced 0.0 becomes a no-op gate (``rel >= 0.0`` is
        always true for a candidate) — same observable contract.
        """
        return self._match_episodes(args, threshold_override=0.0)

    def match_reflections(self, args: dict) -> list[dict]:
        """BM25 lexical recall over active reflections + the same blend.

        Mirrors the ``match_reflections`` RPC's scoring: only non-superseded
        rows, importance = ``min(weight/2, 1)``, top-``match_count`` by
        blended score. The client-side ``kinds`` post-filter and ``[:limit]``
        slice live in ``operations.search_reflections``; this method just
        returns scored rows in the RPC's shape.

        **Deliberate divergence from the cloud contract (2026-07-02,
        owner-approved — like the 2026-06-27 search_facts divergence):**
        ``match_threshold`` gates the RELEVANCE component (``rel >=
        threshold``), not the blended score. Under blend-gating a weight-1
        reflection older than ~3 weeks could NEVER clear the old 0.7 default
        (30-day blend cap: 0.5·1.0 + 0.3·e^(-30/14) + 0.2·0.5 ≈ 0.635) — old
        lessons were structurally unrecallable. The blend is now used ONLY
        for ranking. This also resolves PLAN.md open question #1
        symmetrically with the episode path's forced-0.0 hybrid contract.
        Default threshold 0.25 — see ``operations.search_reflections`` for
        the calibration rationale.
        """
        query_text = _query_text_from_args(args)
        threshold = float(args.get("match_threshold", 0.25) or 0.0)
        match_count = int(args.get("match_count", 5) or 5)
        a_rel = _coalesce_alpha(args.get("alpha_relevance"), 0.5)
        a_rec = _coalesce_alpha(args.get("alpha_recency"), 0.3)
        a_imp = _coalesce_alpha(args.get("alpha_importance"), 0.2)
        tau_days = _coalesce_alpha(args.get("tau_days"), 14.0)

        candidates: dict[str, dict] = {}
        relevance: dict[str, float] = {}

        match = _fts_sanitize(query_text)
        sql = (
            "SELECT r.id AS id, r.content AS note, r.category AS tag, "
            "       r.weight AS weight, r.created_at AS created_at, "
            "       bm25(reflections_fts) AS bm25 "
            "FROM reflections_fts "
            "JOIN reflections r ON r.rowid = reflections_fts.rowid "
            "WHERE reflections_fts MATCH ? "
            "  AND r.superseded_by IS NULL"
        )
        for row in self._query(sql, [match]):
            candidates[row["id"]] = row
            relevance[row["id"]] = _bm25_to_relevance(row["bm25"])

        # Optional dense leg (T2.7) — folds cosine into the SAME re-rank when a
        # query vector + stored embeddings exist. Default path skips this.
        q_vec = _query_embedding_from_args(args)
        if q_vec is not None:
            dense_sql = (
                "SELECT r.id AS id, r.content AS note, r.category AS tag, "
                "       r.weight AS weight, r.created_at AS created_at, "
                "       r.embedding AS embedding "
                "FROM reflections r "
                "WHERE r.embedding IS NOT NULL AND r.superseded_by IS NULL"
            )
            for row in self._query(dense_sql, []):
                cos = _cosine_relevance(q_vec, _unpack_embedding(row["embedding"]))
                if cos is None:
                    continue
                rid = row["id"]
                if rid not in candidates:
                    candidates[rid] = row
                prev = relevance.get(rid, 0.0)
                if cos > prev:
                    relevance[rid] = cos

        now = _utcnow()
        scored: list[dict] = []
        for rid, row in candidates.items():
            rel = relevance.get(rid, 0.0)
            # Gate on RELEVANCE alone; blend only ranks (2026-07-02 fix —
            # see the docstring). A stale-but-perfect match must survive.
            if rel < threshold:
                continue
            rec = _recency(row.get("created_at"), tau_days, now)
            weight = row.get("weight")
            weight = 1.0 if weight is None else float(weight)
            imp = min(weight / 2.0, 1.0)
            score = a_rel * rel + a_rec * rec + a_imp * imp
            scored.append({
                "id": rid,
                "note": row.get("note"),
                "tag": row.get("tag"),
                "weight": weight,
                "similarity": score,
            })
        scored.sort(key=lambda r: r["similarity"], reverse=True)
        return scored[:match_count]

    # --- shared episode matcher ------------------------------------------
    def _match_episodes(self, args: dict,
                        threshold_override: Optional[float]) -> list[dict]:
        query_text = _query_text_from_args(args)
        if threshold_override is not None:
            threshold = threshold_override
        else:
            threshold = float(args.get("match_threshold", 0.25) or 0.0)
        match_count = int(args.get("match_count", 5) or 5)
        a_rel = _coalesce_alpha(args.get("alpha_relevance"), 0.5)
        a_rec = _coalesce_alpha(args.get("alpha_recency"), 0.3)
        a_imp = _coalesce_alpha(args.get("alpha_importance"), 0.2)
        tau_days = _coalesce_alpha(args.get("tau_days"), 14.0)

        # Thread / project scoping: the cloud RPC blends across a project's
        # threads (p_project_id wins) or filters to a single thread. We honour
        # the same precedence locally, but project-blend needs a threads table
        # the local store may not carry — fall back to no-op scoping if the
        # column is absent rather than raising.
        thread_id = args.get("p_thread_id")
        project_id = args.get("p_project_id")
        scope_sql, scope_params = self._episode_scope(thread_id, project_id)

        # relevance per row: id -> (relevance, row-dict). BM25 fills it first;
        # the optional dense (cosine) leg then merges in, taking the MAX
        # relevance so a paraphrase BM25 missed can still surface (T2.7).
        candidates: dict[str, dict] = {}
        relevance: dict[str, float] = {}

        match = _fts_sanitize(query_text)
        sql = (
            "SELECT e.id AS id, e.role AS role, e.content AS content, "
            "       e.summary AS summary, e.occurred_at AS occurred_at, "
            "       bm25(episodes_fts) AS bm25 "
            "FROM episodes_fts "
            "JOIN episodes e ON e.rowid = episodes_fts.rowid "
            "WHERE episodes_fts MATCH ?" + scope_sql
        )
        for row in self._query(sql, [match, *scope_params]):
            candidates[row["id"]] = row
            relevance[row["id"]] = _bm25_to_relevance(row["bm25"])

        # Dense leg — only when an embedder pack supplied a query vector AND
        # rows carry embeddings. Absent (default), this is skipped entirely and
        # recall stays BM25-only.
        q_vec = _query_embedding_from_args(args)
        if q_vec is not None:
            dense_sql = (
                "SELECT e.id AS id, e.role AS role, e.content AS content, "
                "       e.summary AS summary, e.occurred_at AS occurred_at, "
                "       e.embedding AS embedding "
                "FROM episodes e "
                "WHERE e.embedding IS NOT NULL" + scope_sql
            )
            for row in self._query(dense_sql, list(scope_params)):
                cos = _cosine_relevance(q_vec, _unpack_embedding(row["embedding"]))
                if cos is None:
                    continue
                rid = row["id"]
                if rid not in candidates:
                    candidates[rid] = row
                prev = relevance.get(rid, 0.0)
                if cos > prev:
                    relevance[rid] = cos

        now = _utcnow()
        scored: list[dict] = []
        for rid, row in candidates.items():
            rel = relevance.get(rid, 0.0)
            # Gate on RELEVANCE alone; blend only ranks (2026-07-02 fix —
            # see match_episodes' docstring). Old episodes must stay
            # recallable when the match itself is strong.
            if rel < threshold:
                continue
            rec = _recency(row.get("occurred_at"), tau_days, now)
            imp = _episode_importance(row.get("role"))
            score = a_rel * rel + a_rec * rec + a_imp * imp
            scored.append({
                "id": rid,
                "role": row.get("role"),
                "content": row.get("content"),
                "summary": row.get("summary"),
                "occurred_at": row.get("occurred_at"),
                "similarity": score,
            })
        scored.sort(key=lambda r: r["similarity"], reverse=True)
        return scored[:match_count]

    def _episode_scope(self, thread_id: Any,
                       project_id: Any) -> tuple[str, list[Any]]:
        """Build the optional thread/project WHERE clause for episode recall.

        Mirrors the RPC precedence: ``p_project_id`` (blend across the
        project's threads) wins over ``p_thread_id`` (single thread). The
        local store may not carry a threads table for project-blend; if it
        doesn't, project scoping degrades to a no-op (global match) instead
        of raising — the BM25 + re-rank ordering is unchanged.
        """
        if project_id is not None:
            if self._has_threads_table():
                return (
                    " AND e.thread_id IN ("
                    "SELECT id FROM conversation_threads WHERE project_id = ?)",
                    [str(project_id)],
                )
            return ("", [])
        if thread_id is not None:
            return (" AND e.thread_id = ?", [str(thread_id)])
        return ("", [])

    def _has_threads_table(self) -> bool:
        rows = self._query(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name='conversation_threads'",
            [],
        )
        return bool(rows)


class _RpcCall:
    """``backend.rpc(name, args).execute()`` → routes to the match_* methods.

    The semantic-search functions live on the backend (rather than the query
    builder) because they need full SQL + Python re-rank, not the fluent chain:
    ``match_episodes`` / ``match_episodes_hybrid`` / ``match_reflections``.
    """

    _DISPATCH = {
        "match_episodes": "match_episodes",
        "match_episodes_hybrid": "match_episodes_hybrid",
        "match_reflections": "match_reflections",
    }

    def __init__(self, backend: SQLiteBackend, name: str, args: dict):
        self._backend = backend
        self._name = name
        self._args = args

    def execute(self) -> _Result:
        method_name = self._DISPATCH.get(self._name)
        if method_name is None:
            raise ValueError(f"unknown rpc: {self._name!r}")
        method = getattr(self._backend, method_name)
        return _Result(method(self._args) or [])
