"""Optional local embedder pack — fastembed (ONNX), 768-dim by default.

The free core never imports this. Installing the ``[embeddings]`` extra
(``pip install local-yep[embeddings]``) makes ``fastembed`` importable; calling
:func:`activate` then registers a local model with the embeddings seam
(:func:`local_yep.memory.embeddings.register_embedder`), turning on the dormant
cosine recall path for episodes / reflections / facts.

**Performance — why activation is explicit, not automatic.** The model + its
ONNX session load lazily on the FIRST ``embed()`` call (a few seconds the first
time, including a one-time model download to the fastembed cache), then stay
warm for the life of the process. So activation is only sensible in LONG-LIVED
or explicit contexts — the persistent MCP server and ``yepgent memory reindex``
— NEVER in a fresh per-turn hook process, which would reload the model every
turn and blow the hook's time budget. Contexts that don't activate keep the
fast BM25-only path (``embed()`` raises ``EmbeddingUnavailable``, which every
caller already tolerates).

**Dimension.** Defaults to ``nomic-ai/nomic-embed-text-v1.5`` (768 dims) to
match the store's pinned ``embedding_dim`` (768) and the cloud Yep. Override
with ``YEP_EMBED_MODEL``; the store refuses a width != the pinned dimension.
"""
from __future__ import annotations

import os
from functools import lru_cache

from . import embeddings as _emb

#: Default local model. 768-dim to match the pinned embedding_dim.
MODEL_NAME = os.environ.get("YEP_EMBED_MODEL", "nomic-ai/nomic-embed-text-v1.5")


@lru_cache(maxsize=1)
def _model():
    # Heavy import + model/session init — deferred to the first embed() call.
    from fastembed import TextEmbedding

    return TextEmbedding(model_name=MODEL_NAME)


def _embed_one(text: str) -> list[float]:
    # fastembed yields one vector per input document; take the first.
    vec = next(iter(_model().embed([text])))
    return [float(x) for x in vec]


def available() -> bool:
    """True if the ``[embeddings]`` extra is importable (no model load)."""
    try:
        import fastembed  # noqa: F401
    except Exception:
        return False
    return True


def activate() -> bool:
    """Register the fastembed embedder if the extra is installed. Idempotent.

    Returns True if an embedder is now registered (or already was), False if
    fastembed isn't installed (the free-core default — recall stays BM25). Cheap:
    the model itself loads lazily on the first :func:`embed` call.
    """
    if _emb.has_embedder():
        return True
    if not available():
        return False
    _emb.register_embedder(_embed_one)
    return True
