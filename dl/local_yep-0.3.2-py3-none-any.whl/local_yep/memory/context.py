"""Per-turn memory context assembly (PLAN.md §2, the zero-change target).

This is the localized analogue of the source repo's
``src/core/system_prompt.py``. The single function the product depends on —
:func:`build_memory_context` — is ported **UNCHANGED** (logic-identical) from
the cloud build: the ONLY edit is the import, which now points at
:mod:`local_yep.memory` instead of ``src.memory``. Its return shape (the
``<memory>…</memory>`` envelope, every section header, the per-section
``try/except`` structure) is the §2 non-negotiable and must not change; the
storage backend behind the imported free functions is the local SQLite store.

**Deliberate divergence (2026-06-27, owner-approved).** Local Yep adds ONE
section the cloud build lacks — "Other facts that may be relevant" — surfacing
facts by lexical relevance to the user message (via :func:`search_facts`), not
only pinned ``user.*`` keys. This closes a real recall hole: a fact stored under
an arbitrary key (e.g. ``monkey_math.one_plus_one``) was structurally invisible
to ambient recall. The cloud byte-exact AST-equality guard is retired
accordingly; the section-header / envelope / per-section try-except structural
invariants still hold (and are still tested).

**Deliberate divergence (2026-07-02, owner-approved).** Injection cost caps:
every rendered line is `_smart_preview`-truncated (fact values and episode/
event lines at 200 chars, reflection notes at 350), and the whole block
carries an 8000-character budget — sections are assembled in the canonical
order and assembly stops (appending a single truncation marker) once the
budget would be exceeded. Untruncated fact values / reflection notes were an
unbounded per-turn token tax. Recall thresholds are now RELEVANCE gates, not
blended-score gates — see ``operations.search_reflections``.

The source module also carries ``build_static_system_prompt`` and the async
recall path (``build_memory_recall_async``) plus the thread/agent-session
helpers those use. Those are daemon-era / identity machinery owned by §1/§3 and
are out of Phase-1 memory scope, so they are intentionally NOT ported here.
What IS ported is the synchronous per-turn builder the IDE ambient-memory hook
calls, together with the formatting helpers it transitively uses
(``_user_tz`` / ``_local_date`` / ``_smart_preview``) and the tunable module
constants, all byte-for-byte from the source.
"""
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from local_yep.memory import (
    active_reflections, list_facts, read_fact, recent_event_episodes,
    search_episodes, search_facts, search_reflections,
)

# Tunables for the per-turn memory recall.
# RELEVANCE gates (2026-07-02, owner-approved divergence — see
# operations.search_reflections): each candidate's BM25-squashed q/(1+q) (or
# cosine) relevance must clear this floor; the recency/importance blend only
# ranks. The old 0.55 values gated the BLEND, which recency decay alone put
# out of reach for anything older than ~5 weeks. 0.25 calibrated with
# tests/test_recall_quality.py: good matches sit at rel 0.78-0.92 in a
# populated store but only ~0.33 cold-start (BM25 IDF collapses at tiny N).
# NOTE: search_episodes' default hybrid path force-sets its gate to 0.0 (top-N
# contract), so _EPISODE_THRESHOLD only bites for hybrid=False callers.
_EPISODE_THRESHOLD = 0.25
_REFLECTION_THRESHOLD = 0.25
# How many messages from the previous thread to surface as a session-bridge.
_RECENCY_TAIL_LIMIT = 6
# Recent autonomous-activity (role='event') lookback + cap. These are
# scheduler-dispatched outcomes (post_merge_resume, pre_restart_handoff,
# fill_sync, daily_report, etc.) that must orient the next user turn
# REGARDLESS of semantic match to the user message. Closes the
# "I merged and nothing showed up" gap.
_RECENT_EVENT_HOURS = 24
_RECENT_EVENT_LIMIT = 5
# Whole-block character budget (2026-07-02): the <memory> block is injected on
# EVERY user turn, so it must be bounded no matter how large the store grows.
# Sections are added in the canonical order until the budget would be
# exceeded; then assembly stops and _TRUNCATION_MARKER is appended so the
# model knows to reach for the deliberate recall tools.
_MEMORY_CHAR_BUDGET = 8000
_TRUNCATION_MARKER = "…(memory truncated — use recall tools for more)"


@dataclass
class MemoryRecall:
    """Per-turn memory recall with the assembled <memory> block plus counts.

    Counts let the UI surface "Yep recalled N facts, M episodes…" without
    having to parse the formatted text. duration_ms is the wall-clock cost
    of the concurrent recall queries.
    """
    text: str
    facts: int
    reflections: int
    episodes: int
    duration_ms: int


# Default tz used when fact `user.timezone` is missing or unreadable.
_DEFAULT_USER_TZ = "America/New_York"


def _user_tz() -> ZoneInfo:
    """Return the user's local timezone (fact `user.timezone`).

    Reads the fact on every call so mid-session updates are picked up
    without a daemon restart. Falls back to America/New_York when the
    fact is missing or holds an invalid zone name.
    """
    try:
        f = read_fact("user.timezone")
        if f and f.get("value"):
            return ZoneInfo(f["value"])
    except Exception:
        pass
    return ZoneInfo(_DEFAULT_USER_TZ)


def _local_date(iso_str: str) -> str:
    """Render a UTC ISO timestamp as ``YYYY-MM-DD`` in the user's local tz.

    Defends against the trap of slicing the first 10 chars of a UTC ISO
    string (``occurred_at[:10]``) when the user's local clock is hours
    behind UTC — which would otherwise label evening episodes as
    ``tomorrow`` in the memory block. Falls back to the raw 10-char slice
    only if parsing fails.
    """
    try:
        s = (iso_str or "").replace("Z", "+00:00")
        if not s:
            return ""
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(_user_tz()).strftime("%Y-%m-%d")
    except Exception:
        return (iso_str or "")[:10]


# Words too generic to be useful as fact-search terms.
_FACT_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be",
    "been", "being", "to", "of", "in", "on", "for", "with", "at", "by", "from",
    "as", "that", "this", "these", "those", "it", "its", "what", "whats", "how",
    "why", "when", "where", "who", "which", "do", "does", "did", "can", "could",
    "should", "would", "will", "i", "you", "we", "my", "your", "our", "me",
    "us", "about", "into", "over", "than", "then", "so", "just", "get",
})


def _salient_terms(message: str, max_terms: int = 6) -> list[str]:
    """Distinct, salient lowercase terms from a message for lexical fact lookup."""
    seen: set[str] = set()
    out: list[str] = []
    for w in re.findall(r"[A-Za-z0-9_]+", message.lower()):
        if len(w) < 3 or w in _FACT_STOPWORDS or w in seen:
            continue
        seen.add(w)
        out.append(w)
        if len(out) >= max_terms:
            break
    return out


def _facts_for_message(
    message: str, exclude_keys: set[str], limit: int = 5
) -> list[dict]:
    """Lexically-relevant facts for ``message``, minus already-pinned keys.

    Bridges the gap where the pinned path only surfaces ``user.*`` keys: any fact
    whose key OR value contains a salient term of the message can surface (via the
    existing :func:`search_facts`), so a fact stored under an arbitrary key (e.g.
    ``monkey_math.one_plus_one``) is recallable by content, not just by guessing
    its key namespace.
    """
    seen = set(exclude_keys)
    out: list[dict] = []
    for term in _salient_terms(message):
        for f in search_facts(term, limit=limit):
            k = f.get("key")
            if not k or k in seen:
                continue
            seen.add(k)
            out.append(f)
            if len(out) >= limit:
                return out
    return out


def build_memory_context(user_message: str | None = None) -> str:
    """Per-turn memory snapshot. Empty string if nothing relevant.

    Contents:
      - Active reflections (current self-knowledge)
      - Pinned user.* facts
      - Episodes / reflections semantically near this user message
    """
    parts: list[str] = []

    refs = active_reflections(limit=15)
    if refs:
        lines = [
            f"- ({r.get('tag') or 'note'}) {_smart_preview(r['note'], 350)}"
            for r in refs
        ]
        parts.append("Things you've learned (reflections):\n" + "\n".join(lines))

    facts = list_facts(prefix="user.", limit=50)
    if facts:
        # Cap fact values at 200 chars (2026-07-02): values are user-supplied
        # and unbounded; the [f['value']] hard read stays so a key rename
        # still fails LOUDLY (see test_renamed_fact_key_is_caught).
        lines = [
            f"- {f['key']} = {_smart_preview(str(f['value']), 200)}"
            for f in facts
        ]
        parts.append("What you know about the user:\n" + "\n".join(lines))

    relevant_eps_for_dedup: list[dict] = []
    if user_message:
        # Other (non-pinned) facts lexically relevant to the message — closes the
        # gap where only user.* keys were ever surfaced. Deliberate divergence
        # from the cloud build (owner-approved 2026-06-27).
        try:
            rel_facts = _facts_for_message(user_message, {f["key"] for f in facts})
            if rel_facts:
                lines = [
                    f"- {f['key']} = {_smart_preview(str(f['value']), 200)}"
                    for f in rel_facts
                ]
                parts.append(
                    "Other facts that may be relevant:\n" + "\n".join(lines)
                )
        except Exception:
            pass

        try:
            # Match the daemon's async prelude threshold (_EPISODE_THRESHOLD,
            # 0.55) — NOT search_episodes' stricter 0.7 default. The IDE
            # ambient-memory hook calls this sync builder; leaving the default
            # in place meant diffuse multi-episode arcs (e.g. a topic whose
            # episodes score 0.55-0.69) were silently dropped here but surfaced
            # by the daemon, so IDE-Yep recalled less than the daemon for the
            # same prompt. (Root-caused 2026-06-17.)
            relevant_eps_for_dedup = search_episodes(
                user_message, threshold=_EPISODE_THRESHOLD, limit=4
            )
            if relevant_eps_for_dedup:
                # _smart_preview both branches (2026-07-02): the summary
                # branch was previously injected UNTRUNCATED.
                lines = [
                    f"- [{_local_date(e['occurred_at'])}] "
                    f"{_smart_preview(e.get('summary') or e['content'], 200)}"
                    for e in relevant_eps_for_dedup
                ]
                parts.append("Possibly relevant past moments:\n" + "\n".join(lines))
        except Exception:
            pass

        try:
            relevant_refs = search_reflections(
                user_message, threshold=_REFLECTION_THRESHOLD, limit=3
            )
            extra = [r for r in relevant_refs if r["id"] not in {x["id"] for x in refs}]
            if extra:
                # 350-char cap matches the pinned reflections section above;
                # this section previously injected FULL notes (2026-07-02).
                lines = [
                    f"- ({r.get('tag') or 'note'}) {_smart_preview(r['note'], 350)}"
                    for r in extra
                ]
                parts.append("Additional relevant reflections:\n" + "\n".join(lines))
        except Exception:
            pass

    # Recent autonomous activity (cross-thread role='event' rows). Same
    # rationale as the async path above — surfaces scheduler-dispatched
    # outcomes that completed in PARALLEL sessions.
    try:
        events = recent_event_episodes(_RECENT_EVENT_HOURS, _RECENT_EVENT_LIMIT)
        if events:
            already = {e.get("id") for e in relevant_eps_for_dedup}
            new_events = [e for e in events if e.get("id") not in already]
            if new_events:
                # _smart_preview both branches (2026-07-02): the summary
                # branch was previously injected UNTRUNCATED.
                lines = [
                    f"- [{_local_date(e['occurred_at'])}] "
                    f"{_smart_preview(e.get('summary') or e['content'], 200)}"
                    for e in new_events
                ]
                parts.append(
                    "Recent autonomous activity:\n" + "\n".join(lines)
                )
    except Exception:
        pass

    if not parts:
        return ""
    # Whole-block budget (2026-07-02): keep sections in canonical order and
    # stop adding once _MEMORY_CHAR_BUDGET would be exceeded, appending one
    # truncation marker so the model knows deliberate recall holds the rest.
    kept: list[str] = []
    used = len("<memory>\n") + len("\n</memory>")
    for part in parts:
        cost = len(part) + (2 if kept else 0)  # 2 = the "\n\n" joiner
        if used + cost > _MEMORY_CHAR_BUDGET:
            kept.append(_TRUNCATION_MARKER)
            break
        kept.append(part)
        used += cost
    return "<memory>\n" + "\n\n".join(kept) + "\n</memory>"


def _smart_preview(text: str, max_chars: int = 200) -> str:
    """Render a short single-line preview of `text` with at most `max_chars`.

    Collapses internal whitespace, then if truncation is needed prefers a
    sentence/clause boundary over a hard mid-word cut. Appends an ellipsis
    when the result is shorter than the original input.

    Used to render episode previews in the memory block. Beats naked
    ``content[:200]`` slicing which routinely chops sentences mid-word and
    looks unprofessional in the prompt.
    """
    if not text:
        return ""
    s = " ".join(text.split())
    if len(s) <= max_chars:
        return s
    cut = s[:max_chars]
    # Prefer cuts at strong sentence boundaries, falling back to weaker ones.
    for sep in (". ", "? ", "! ", "; ", ", "):
        idx = cut.rfind(sep)
        # Don't cut so early that we lose half the budget — better a clean
        # word-boundary cut than a 30-char fragment.
        if idx >= max_chars * 0.5:
            return cut[: idx + 1].rstrip() + " …"
    sp = cut.rfind(" ")
    if sp >= max_chars * 0.5:
        return cut[:sp] + " …"
    return cut + "…"
