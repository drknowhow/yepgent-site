"""Local Yep memory subsystem — 100% local SQLite store.

Ported from the source repo's ``src/memory/__init__.py`` (PLAN.md §2). Trimmed
to the surface Local Yep ships in Phase 1: the facts / episodes / reflections
operations + the optional ``embed`` seam + the backend selector. The source's
threads / projects / secrets / agent-sessions modules are out of scope here
(daemon-era machinery, not part of the local recall→reflect loop).

The public function surface matches what ``memory_tools.py`` and
``build_memory_context`` import, so those render unchanged against this backend
(the §2 non-negotiable: only the storage engine swaps).
"""
from .backend import get_backend, MemoryBackend
from .embeddings import embed
from .fastembed_pack import activate as activate_embeddings
from .operations import (
    write_fact, read_fact, list_facts, search_facts, delete_fact,
    recover_fact_prior,
    log_episode, recent_episodes, recent_event_episodes, search_episodes,
    write_reflection, active_reflections, search_reflections,
    supersede_reflection,
)

__all__ = [
    "get_backend", "MemoryBackend", "embed", "activate_embeddings",
    "write_fact", "read_fact", "list_facts", "search_facts", "delete_fact",
    "recover_fact_prior",
    "log_episode", "recent_episodes", "recent_event_episodes", "search_episodes",
    "write_reflection", "active_reflections", "search_reflections",
    "supersede_reflection",
]
