"""PreToolUse guard hook — the enforcement gate, wired (PLAN §1 T1.8).

Reads the Claude Code PreToolUse payload from stdin, asks
:mod:`local_yep.enforcement` for a verdict on the pending tool call, and:

- ``deny``  -> emits a structured ``permissionDecision: deny`` on stdout so
  Claude Code blocks the call and the model sees the reason;
- ``audit`` -> allows the call (no stdout decision) but appends a line to the
  local audit trail (``~/.local-yep/audit.log``) and warns on stderr;
- ``ok``    -> emits nothing; the normal permission flow proceeds.

The installer wires this hook with a tool-name matcher (see
:func:`local_yep.enforcement.hook_matcher`) so it runs only for file-edit and
shell tools — reads never pay the subprocess cost.

Fail-open BY DESIGN, like every Local Yep hook: an internal error must never
brick the user's session (the dispatcher maps any raise to exit 0, and this
module never raises past ``main``). The gate is honor-system
defense-in-depth — tamper-EVIDENT alongside the integrity manifest, not
tamper-proof (PLAN R2).
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

#: Rotate the audit log once it grows past this many bytes (single .1 backup).
_AUDIT_MAX_BYTES = 1_000_000


def _warn(msg: str) -> None:
    """Best-effort stderr diagnostic; never raises."""
    try:
        print(f"[yep pre-tool-use] {msg}", file=sys.stderr)
    except Exception:
        pass


def _audit_path() -> Path:
    """Resolve the audit-log path (env-overridable for tests)."""
    override = os.environ.get("YEP_AUDIT_LOG")
    if override:
        return Path(override)
    return Path(os.path.expanduser("~")) / ".local-yep" / "audit.log"


def _audit_log(line: str) -> None:
    """Append one timestamped line to the local audit trail. Best-effort."""
    try:
        path = _audit_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            if path.is_file() and path.stat().st_size > _AUDIT_MAX_BYTES:
                path.replace(path.with_suffix(".log.1"))
        except OSError:
            pass
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with open(path, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(f"{stamp} {line}\n")
    except Exception:
        pass


def _ledger(
    event: str, title: str, reason: str, severity: str, payload: dict
) -> None:
    """Mirror a guard verdict into the activity ledger (PLAN §8 T8.2).

    ``audit.log`` keeps working unchanged — it is the append-only forensic
    trail. The ledger is the *readable* one: ``yepgent events`` can filter it,
    ``doctor`` can summarise it, and a bug report can carry it.
    """
    try:
        from local_yep.hooks import _activity

        _activity.record(
            event,
            title,
            payload=payload,
            category="guard",
            severity=severity,
            body=reason,
        )
    except Exception:
        pass


def main() -> int:
    try:
        raw = sys.stdin.read()
    except Exception:
        return 0
    try:
        payload = json.loads(raw) if raw and raw.strip() else {}
    except (ValueError, TypeError):
        payload = {}
    if not isinstance(payload, dict):
        payload = {}

    tool_name = payload.get("tool_name")
    if not isinstance(tool_name, str) or not tool_name:
        return 0
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        tool_input = {}

    try:
        from local_yep import enforcement

        verdict = enforcement.evaluate(tool_name, tool_input)
    except Exception as exc:  # fail-open: a gate bug never bricks the session
        _warn(f"enforcement evaluate failed ({type(exc).__name__}) — allowing")
        return 0

    decision = verdict.get("decision")
    reason = str(verdict.get("reason") or "")

    if decision == "deny":
        out = {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }
        try:
            print(json.dumps(out))
        except Exception:
            return 0
        _audit_log(f"DENY {tool_name}: {reason}")
        _ledger("guard.deny", f"blocked {tool_name}", reason, "warn", payload)
        return 0

    if decision == "audit":
        _audit_log(f"AUDIT {tool_name}: {reason}")
        _warn(reason)
        _ledger("guard.audit", f"flagged {tool_name}", reason, "info", payload)
        return 0

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main() or 0)
