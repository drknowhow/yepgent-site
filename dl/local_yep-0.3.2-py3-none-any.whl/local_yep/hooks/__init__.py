"""Local Yep Claude Code hooks.

The three ported hooks (``session_start``, ``ambient_memory``,
``session_stop``) are filled in by §1 T1.5/T1.6 (G5). This package's
:mod:`local_yep.hooks.run` is the single ``yepgent-hook`` entrypoint that
dispatches to them by event name.
"""

from __future__ import annotations

__all__: list[str] = []
