"""``yepgent-hook`` — the single console entrypoint for every Claude Code hook.

Replaces the old Windows-only ``py -3 scripts/_hook_*.py`` wiring (T1.1) with
one cross-platform entrypoint. Claude Code's ``.claude/settings.json`` invokes
``yepgent-hook <event>`` and pipes the hook JSON payload on stdin; this dispatcher
maps the event name to the matching hook module and calls its ``main()``.

    yepgent-hook session_start  < payload.json
    yepgent-hook ambient_memory < payload.json
    yepgent-hook session_stop   < payload.json

Each hook module reads ``sys.stdin`` itself (mirroring the source
``scripts/_hook_*.py`` contract), so this dispatcher just routes by name and
forwards the process's stdin untouched.

Design constraints:
- **Lazy imports.** The hook modules are filled by §1 T1.5/T1.6 (G5). We
  import the target module only when its event is dispatched, so this file
  works (and ``--help`` / unknown-event handling works) before those modules
  exist.
- **Never hard-crash the session.** A hook that errors must not take down the
  Claude Code session. Unknown events, missing modules, and exceptions inside
  a hook are reported on stderr and converted to exit code 0 (the hook
  protocol treats a clean exit + empty stdout as a no-op).
"""

from __future__ import annotations

import sys

#: event name -> dotted module path. Each module exposes a ``main()`` that
#: reads stdin and returns an int exit code (or None / calls sys.exit).
_EVENT_MODULES: dict[str, str] = {
    "session_start": "local_yep.hooks.session_start",
    "ambient_memory": "local_yep.hooks.ambient_memory",
    "session_stop": "local_yep.hooks.session_stop",
    "pre_tool_use": "local_yep.hooks.pre_tool_use",
    "notification": "local_yep.hooks.notification",
    "session_end": "local_yep.hooks.session_end",
    "subagent_stop": "local_yep.hooks.subagent_stop",
}

# Accept a few friendly aliases for the Claude Code hook event names so the
# wiring is forgiving (e.g. UserPromptSubmit -> ambient_memory).
_ALIASES: dict[str, str] = {
    "sessionstart": "session_start",
    "start": "session_start",
    "userpromptsubmit": "ambient_memory",
    "prompt": "ambient_memory",
    "memory": "ambient_memory",
    "stop": "session_stop",
    "sessionstop": "session_stop",
    # SessionEnd is NOT Stop. Stop fires per assistant turn; SessionEnd fires
    # once, with a `reason`. Aliasing them (as this table used to) threw away
    # the only field that carried new information.
    "sessionend": "session_end",
    "pretooluse": "pre_tool_use",
    "guard": "pre_tool_use",
    "subagentstop": "subagent_stop",
    "notify": "notification",
}


def _warn(msg: str) -> None:
    """Best-effort stderr diagnostic; never raises."""
    try:
        print(f"[yepgent-hook] {msg}", file=sys.stderr)
    except Exception:
        pass


def _normalize(event: str) -> str:
    key = event.strip().lower().replace("-", "_")
    if key in _EVENT_MODULES:
        return key
    return _ALIASES.get(key.replace("_", ""), key)


def main(argv: list[str] | None = None) -> int:
    """Dispatch a hook event named by ``argv[0]`` (after the program name).

    Returns the hook module's exit code, or 0 for the always-safe paths
    (no event, ``--help``, unknown event, import failure, or a hook raising).
    """
    args = sys.argv[1:] if argv is None else argv

    if not args or args[0] in ("-h", "--help", "help"):
        _print_usage()
        return 0

    event = _normalize(args[0])
    module_path = _EVENT_MODULES.get(event)
    if module_path is None:
        _warn(
            f"unknown hook event {args[0]!r}; "
            f"expected one of {', '.join(sorted(_EVENT_MODULES))}"
        )
        return 0

    # Lazy import: the hook modules (G5) may not exist yet. A missing module or
    # an error inside it must never crash the Claude Code session.
    try:
        import importlib

        module = importlib.import_module(module_path)
    except Exception as exc:  # noqa: BLE001 - hooks must fail open
        _warn(f"hook module {module_path!r} unavailable: {exc}")
        return 0

    hook_main = getattr(module, "main", None)
    if not callable(hook_main):
        _warn(f"hook module {module_path!r} has no callable main()")
        return 0

    try:
        result = hook_main()
    except SystemExit as exc:  # a hook may call sys.exit() itself
        code = exc.code
        if isinstance(code, int):
            return code
        return 0 if code is None else 1
    except Exception as exc:  # noqa: BLE001 - never break the session
        _warn(f"hook {event} raised: {exc}")
        return 0

    return result if isinstance(result, int) else 0


def _print_usage() -> None:
    events = ", ".join(sorted(_EVENT_MODULES))
    print(
        "usage: yepgent-hook <event>   (reads hook JSON payload on stdin)\n"
        f"events: {events}",
        file=sys.stderr,
    )


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
