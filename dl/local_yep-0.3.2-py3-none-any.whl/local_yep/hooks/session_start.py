"""SessionStart hook: inject Yep's identity + a "where we left off" anchor.

Ported from ``scripts/_hook_session_start.py`` (the Yep source repo) with the
daemon coupling removed for Local Yep:

* **The old daemon opt-out gate is GONE.** There is no daemon in Local Yep —
  identity injection is unconditional. Every interactive Claude Code session in
  a Local-Yep repo gets the identity preamble. (The source gated injection on a
  daemon env var; that env-var check is removed entirely.)
* **Identity is RENDERED** (P2, §3 T3.7) from the frozen ethical spine plus a
  fresh overlay compiled from ``~/.local-yep/agent.toml`` (or a sane default
  when none exists) via :func:`local_yep.identity.render.render_identity`. The
  bundled ``behaviors.md`` / ``tool_recipes.md`` are still appended as operative
  context; the P1 ``core_directives.md`` placeholder is superseded by the
  rendered spine + identity overlay.
* **Continuity anchor is pure file I/O**, unchanged in spirit: read the most
  recent anchor written by the Stop hook and surface the previous session's
  tail so a fresh window knows what it is resuming.

Protocol (Claude Code SessionStart hook):
- stdin: hook JSON with ``cwd`` and ``source`` (startup / resume / clear).
- stdout: ``{"hookSpecificOutput": {"hookEventName": "SessionStart",
  "additionalContext": "..."}}``. The harness injects ``additionalContext``
  into the session preamble.
- Hard time budget; always exits 0. Hook failures must never block a session.

NO NETWORK. NO daemon env-var gate. The only I/O is reading bundled package
files and the local continuity anchor under ``~/.local-yep/continuity``.
"""
from __future__ import annotations

import json
import os
import re
import signal
import subprocess
import sys
from pathlib import Path
from typing import Any

from local_yep.home import HOME

# Local Yep keeps ALL its mutable state under ~/.local-yep/ so it never shares
# files with — or interferes with — any other system on the machine (e.g. the
# cloud-yep setup, which uses ~/.claude/yep_*). Continuity anchors live here.
CONTINUITY_DIR = HOME / "continuity"
TIMEOUT_SECS = 1

#: Bundled operative-context files. P2: identity itself is RENDERED (spine +
#: overlay) — these templates now supply only the still-operative
#: ``behaviors.md`` / ``tool_recipes.md`` appended after the rendered identity.
_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"


def _warn(msg: str) -> None:
    print(f"[hook_session_start] {msg}", file=sys.stderr)


def _project_slug(cwd: str) -> str:
    """Best-effort ``<owner>_<repo>`` slug from the cwd's git origin.

    Same logic as the Stop hook so the two agree on the anchor filename.
    Falls back to the directory name when there is no git remote.
    """
    try:
        out = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=1,
        )
        if out.returncode == 0:
            url = (out.stdout or "").strip()
            m = re.search(r"[:/]([^/:]+)/([^/]+?)(?:\.git)?/?$", url)
            if m:
                return f"{m.group(1)}_{m.group(2)}"
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return Path(cwd).name or "default"


def _read_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError) as exc:
        _warn(f"identity read failed for {path.name}: {exc}")
        return ""


def _render_overlay() -> str:
    """Render the identity overlay from the user's ``agent.toml``.

    P2 (§3 T3.7): this REPLACES the P1 bundled-template placeholder. The body is
    produced by the render pipeline (:func:`local_yep.identity.render.render_identity`),
    which assembles — in order — the forming-bond opener, the frozen
    (hash-verified) ethical spine, the name/owner line, the chosen preset's
    VOICE block, the compiled dials stanza, and the memory-is-the-authenticity
    note.

    Source of config:

    * ``~/.local-yep/agent.toml`` when present and valid;
    * otherwise :func:`~local_yep.identity.schema.make_default_config` (name
      "Yep", preset ``terse-expert``) — a fresh install with no ``agent.toml``,
      or one that fails to parse, STILL injects full identity (and the brand
      word "Yep").

    Returns ``""`` only if the render itself fails (e.g. a tampered spine trips
    the integrity check, or the bundled presets are missing) — a hook must
    never crash a session, so any failure degrades to "no identity injected"
    with a stderr warning rather than an exception.
    """
    # Imported lazily so a hook import never pays the identity-package cost
    # unless a session actually starts (and so an import error here is caught
    # by the broad guard below rather than at module load).
    try:
        from local_yep.home import AGENT_TOML
        from local_yep.identity.render import render_identity
        from local_yep.identity.schema import (
            AgentConfigError,
            load_config,
            make_default_config,
        )
    except Exception as exc:  # pragma: no cover — defensive: never crash a hook
        _warn(f"identity render import failed: {exc}")
        return ""

    config = None
    try:
        if AGENT_TOML.is_file() and AGENT_TOML.stat().st_size > 0:
            config = load_config(AGENT_TOML)
    except AgentConfigError as exc:
        # A malformed/incomplete agent.toml must not block the session — fall
        # back to the sane default so identity still injects.
        _warn(f"agent.toml invalid ({exc}); using default identity")
        config = None
    except OSError as exc:
        _warn(f"agent.toml read failed ({exc}); using default identity")
        config = None

    try:
        if config is None:
            config = make_default_config()
        return render_identity(config)
    except Exception as exc:  # pragma: no cover — defensive: never crash a hook
        _warn(f"identity render failed: {exc}")
        return ""


def _read_identity() -> str:
    """Build the full identity block injected at SessionStart.

    Assembly (mirrors the source ``build_static_system_prompt`` shape, with the
    P1 ``core_directives.md`` placeholder now superseded by the rendered spine +
    overlay):

        header ("[yep identity ...]" / "You are Yep")
        + rendered overlay (forming-bond + spine + name/owner + voice + dials + memory note)
        + "# Current behaviors\\n" + behaviors   (bundled, still operative)
        + "# Tool recipes\\n" + tool_recipes      (bundled, still operative)

    The skills manifest is intentionally skipped (the IDE harness already
    surfaces available skills). Returns "" if the overlay render fails — without
    the spine + identity there is nothing worth injecting (the bundled behaviors
    alone are not an identity).
    """
    overlay = _render_overlay()
    if not overlay:
        return ""

    parts = [overlay]
    behaviors = _read_file(_TEMPLATES_DIR / "behaviors.md")
    if behaviors:
        parts.append("# Current behaviors\n" + behaviors)
    recipes = _read_file(_TEMPLATES_DIR / "tool_recipes.md")
    if recipes:
        parts.append("# Tool recipes\n" + recipes)
    body = "\n\n".join(parts)
    header = (
        "[yep identity — interactive session]\n"
        "You are Yep, not a generic Claude Code assistant. The identity,\n"
        "behaviors, and tool recipes below are who you are. Honor them as your\n"
        "highest-priority context.\n"
    )
    return header + "\n" + body


def _format_context(anchor: dict[str, Any], source: str) -> str:
    lines = [
        "[session continuity]",
        f"Previous chat ({source} into a fresh window):",
    ]
    ts = anchor.get("timestamp") or ""
    if ts:
        lines.append(f"  ended: {ts}")
    sid = anchor.get("session_id") or ""
    if sid:
        lines.append(f"  session: {sid}")
    cwd = anchor.get("cwd") or ""
    if cwd:
        lines.append(f"  cwd: {cwd}")
    user = (anchor.get("last_user") or "").strip()
    if user:
        lines.append(f"  last user: {user}")
    asst = (anchor.get("last_assistant") or "").strip()
    if asst:
        lines.append(f"  last reply: {asst}")
    return "\n".join(lines)


def _emit(additional_context: str) -> None:
    out = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": additional_context,
        }
    }
    sys.stdout.write(json.dumps(out))


def _timeout(_signum, _frame):
    raise TimeoutError("session_start hook exceeded budget")


def main() -> int:
    # Arm the time budget, but ALWAYS disarm before returning. A leaked
    # SIGALRM would otherwise fire ~TIMEOUT_SECS later inside whatever code
    # runs next in the same process — harmless when the hook exits
    # immediately, but it corrupts unrelated tests that import + call main()
    # in a long-lived pytest process.
    if hasattr(signal, "SIGALRM"):  # POSIX only
        signal.signal(signal.SIGALRM, _timeout)
        signal.alarm(TIMEOUT_SECS)
    try:
        return _run()
    finally:
        if hasattr(signal, "SIGALRM"):
            signal.alarm(0)


def _run() -> int:
    try:
        payload_raw = sys.stdin.read()
    except Exception as exc:
        _warn(f"stdin read failed: {exc}")
        return 0
    if not payload_raw:
        return 0

    try:
        payload = json.loads(payload_raw)
    except json.JSONDecodeError as exc:
        _warn(f"bad payload json: {exc}")
        return 0

    cwd = payload.get("cwd") or os.getcwd()
    source = payload.get("source") or "startup"

    # System-integrity gate (fail-closed): if the protected system files have
    # been modified, surface the loud tamper notice and withhold identity —
    # do not run as Yep on a tampered install. A broken import (packaging bug,
    # not an attack) is logged and skipped rather than bricking the session.
    try:
        from local_yep import integrity

        _intg = integrity.check()
        if not _intg.ok:
            _emit(integrity.tamper_message(_intg))
            return 0
    except Exception as exc:  # pragma: no cover - defensive: never crash a hook
        _warn(f"integrity check unavailable: {exc}")

    # Activation gate (gated alpha/beta only; off by default): if this build
    # requires activation and there's no valid entitlement, surface the
    # activation notice and withhold identity. A broken import is logged, not
    # fatal (never brick a hook on a packaging bug).
    try:
        from local_yep import activation

        _act = activation.check()
        if not _act.ok:
            _emit(_act.message)
            return 0
    except Exception as exc:  # pragma: no cover - defensive
        _warn(f"activation check unavailable: {exc}")

    segments: list[str] = []

    # Guardrail G2 (passive surface): if this run looks unattended while signed
    # in with a Claude subscription, surface the boundary FIRST. A SessionStart
    # hook cannot abort Claude Code, so this warns rather than blocks; the active
    # gate (local_yep.guardrails.enforce_interactive_only) is what any future
    # autonomous code path must call. Defensive — a guardrail bug must never
    # break identity injection, so any failure here is swallowed.
    try:
        from local_yep import guardrails

        notice = guardrails.guardrail_notice()
        if notice:
            segments.append(notice)
    except Exception as exc:  # pragma: no cover - defensive
        _warn(f"guardrail check failed: {exc}")

    # Identity first — UNCONDITIONAL. Local Yep has no daemon, so there is no
    # opt-out env var: every interactive session is full Yep. Emitted even on
    # /clear and even when no continuity anchor exists — identity is
    # foundational, not state the user meant to wipe.
    identity = _read_identity()
    if identity:
        segments.append(identity)

    # Continuity anchor: only on startup / resume — not on /clear, which the
    # user explicitly invoked to wipe state. (Claude Code uses source="clear".)
    if source != "clear":
        slug = _project_slug(cwd)
        anchor_path = CONTINUITY_DIR / f"{slug}.json"
        if anchor_path.is_file():
            try:
                anchor = json.loads(anchor_path.read_text(encoding="utf-8"))
                segments.append(_format_context(anchor, source=source))
            except (OSError, json.JSONDecodeError) as exc:
                _warn(f"anchor read failed: {exc}")
            except Exception as exc:  # pragma: no cover — defensive
                _warn(f"format failed: {exc}")

    # Activity ledger (PLAN §8 T8.2). Recorded before the emit so a session
    # that starts is visible even if the emit itself fails.
    try:
        from local_yep import events

        events.emit(
            "session.start",
            f"session started ({source or 'startup'})",
            category="session",
            session_id=str(payload.get("session_id") or ""),
            project=Path(cwd).name if cwd else "",
            meta={"source": source, "identity": bool(identity)},
        )
    except Exception:
        pass

    if not segments:
        return 0

    _emit("\n\n".join(segments))
    return 0


if __name__ == "__main__":
    sys.exit(main())
