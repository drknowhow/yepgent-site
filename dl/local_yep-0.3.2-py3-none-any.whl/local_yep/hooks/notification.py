"""Notification hook — the event worth telling a human about (PLAN §8 T8.3).

Claude Code emits ``Notification`` with
``{hook_event_name, message, title?, notification_type}``. Verified against the
shipped 2.1.229 binary; ``notification_type`` covers at least
``permission_request``, ``idle``, ``task_completed`` and the ``elicitation_*``
family.

``permission_request`` is the single highest-value signal in the whole hook
surface: it means Claude is *blocked*, waiting on a human who may be in another
room. Local Yep never listened for it until now, which is why "the agent is
stuck" was invisible by construction.

This hook writes to the ledger and emits nothing on stdout. Delivery to a
desktop toast or a phone is §8 T8.5/T8.6 and happens out of process — a hook
must never block on a network.
"""

from __future__ import annotations

from local_yep.hooks import _activity

#: notification_type -> (severity, category). Anything unlisted lands as info.
_KINDS: dict[str, tuple[str, str]] = {
    "permission_request": ("warn", "permission"),
    "idle": ("info", "idle"),
    "task_completed": ("info", "task"),
}


def main() -> int:
    payload = _activity.read_payload()
    if not payload:
        return 0

    kind = payload.get("notification_type")
    kind = kind if isinstance(kind, str) and kind else "unknown"
    severity, category = _KINDS.get(kind, ("info", "notification"))

    message = payload.get("message")
    message = message if isinstance(message, str) else ""
    title = payload.get("title")
    title = title if isinstance(title, str) and title else message or kind

    _activity.record(
        f"notify.{kind}",
        title,
        payload=payload,
        category=category,
        severity=severity,
        body=message,
        meta={"notification_type": kind},
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main() or 0)
