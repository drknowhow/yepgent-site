"""Stop hook: continuity anchor + loop circuit-breaker + auto-episode write.

Ported from ``scripts/_hook_session_stop.py`` (continuity anchor +
circuit-breaker, kept verbatim in spirit) and ``scripts/_hook_auto_episode.py``
(the git/PR episode-trigger logic, *relocated* here off its PostToolUse hook).

Three responsibilities, in order:

1. **Continuity anchor (pure file I/O).** Capture the last user prompt + the
   model's final reply to ``~/.local-yep/continuity/<project_slug>.json`` so
   the next session's SessionStart hook can surface "where we left off". No
   dependency on any service — works even if everything else is down.

2. **Loop-discipline circuit-breaker (pure file I/O).** A tiny per-session ring
   buffer of recent ``(assistant_text_hash, tool_error_signature)`` tuples;
   when the same pair would be emitted a third time we return
   ``{"continue": false, "stopReason": ...}`` so the harness stops re-prompting
   an erroring "Done." loop.

3. **Auto-episode write (NEW location).** The old PostToolUse
   ``_hook_auto_episode`` POSTed episodes to a local daemon HTTP endpoint.
   Local Yep has no daemon and no HTTP — so the git/PR episode triggers move
   HERE and write **directly to the local memory backend**
   (``local_yep.memory``). We
   reconstruct the trigger from the transcript tail: scan it for Bash
   ``tool_use`` blocks matching ``gh pr create`` / ``gh pr merge`` /
   ``git commit`` and their paired ``tool_result`` stdout, then write at most
   one episode per Stop for the most significant event found.

The hook always exits 0 — hook failures must never block the agent. NO network
on any path: the only I/O is local files, the local memory DB, and (best
effort) ``git``/``gh`` subprocesses for episode enrichment.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Optional

from local_yep.home import HOME

# All Local Yep mutable state lives under ~/.local-yep/ — never ~/.claude/ — so
# it stays fully isolated from any other system on the machine (e.g. cloud-yep,
# which uses ~/.claude/yep_*).
CONTINUITY_DIR = HOME / "continuity"
STOP_HISTORY_DIR = HOME / "stop_history"
MAX_PREVIEW = 280  # characters
RING_MAX = 3  # keep at most this many recent Stop outcomes per session
# Circuit-breaker triggers when the tail has >=2 prior consecutive entries
# matching the about-to-emit (text_hash, error_sig). The third emit suppressed.
SUPPRESS_THRESHOLD = 2

# Episodes written by this hook carry these base tags (auto-episode lineage).
_BASE_EPISODE_TAGS = ["auto-episode", "git"]


def _warn(msg: str) -> None:
    print(f"[hook_session_stop] {msg}", file=sys.stderr)


def _project_slug(cwd: str) -> str:
    """Best-effort ``<owner>_<repo>`` from the cwd's git origin.

    Same logic as the SessionStart hook so the two agree on the anchor file.
    """
    try:
        out = subprocess.run(
            ["git", "config", "--get", "remote.origin.url"],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=2,
        )
        if out.returncode == 0:
            url = (out.stdout or "").strip()
            m = re.search(r"[:/]([^/:]+)/([^/]+?)(?:\.git)?/?$", url)
            if m:
                return f"{m.group(1)}_{m.group(2)}"
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return Path(cwd).name or "default"


# ---------------------------------------------------------------------------
# Transcript scanning
# ---------------------------------------------------------------------------


def _extract_text(event: dict[str, Any]) -> tuple[str, str]:
    etype = event.get("type")
    if etype not in ("user", "assistant"):
        return "", ""
    msg = event.get("message") or {}
    role = msg.get("role") or etype
    content = msg.get("content")
    if isinstance(content, str):
        return role, content
    if isinstance(content, list):
        parts = [
            (b.get("text") or "") for b in content
            if isinstance(b, dict) and b.get("type") == "text"
        ]
        return role, "\n".join(p for p in parts if p)
    return role, ""


def _scan_transcript_tail(path: Path) -> tuple[Optional[dict], Optional[dict]]:
    """Return (last_user_event, last_assistant_event) from the transcript."""
    last_user: Optional[dict] = None
    last_assistant: Optional[dict] = None
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event.get("type") == "user":
                    last_user = event
                elif event.get("type") == "assistant":
                    last_assistant = event
    except OSError as exc:
        _warn(f"transcript read failed: {exc}")
    return last_user, last_assistant


def _preview(text: str) -> str:
    text = (text or "").replace("\n", " ").strip()
    if len(text) <= MAX_PREVIEW:
        return text
    return text[: MAX_PREVIEW - 1].rstrip() + "…"


# ---------------------------------------------------------------------------
# Auto-episode: derive a git/PR episode from the transcript tail
#
# Relocated from the source PostToolUse ``_hook_auto_episode.py``. There the
# hook saw the exact ``tool_input.command`` + ``tool_response.stdout`` for one
# Bash call. Here we reconstruct the same pairs from the transcript: Bash
# ``tool_use`` blocks (carrying ``input.command``) plus the matching
# ``tool_result`` block (paired by ``tool_use_id``) carrying the stdout.
# ---------------------------------------------------------------------------

# Read at most the final slice of the transcript when hunting for the episode
# trigger — a session's relevant git/gh command is at the tail.
_EPISODE_SCAN_BYTES = 512_000


def _tool_result_text(block: dict) -> str:
    """Flatten a ``tool_result`` content block to plain text (its stdout)."""
    payload = block.get("content")
    if isinstance(payload, list):
        parts = [
            (b.get("text") or "") for b in payload if isinstance(b, dict)
        ]
        return "\n".join(p for p in parts if p)
    if isinstance(payload, str):
        return payload
    if payload is None:
        return ""
    try:
        return json.dumps(payload, sort_keys=True)
    except Exception:  # pragma: no cover - defensive
        return str(payload)


def _collect_bash_calls(path: Path) -> list[tuple[str, str]]:
    """Return ``[(command, stdout), ...]`` for Bash tool calls in the tail.

    Walks the transcript JSONL once: records each Bash ``tool_use`` block's
    ``input.command`` keyed by ``tool_use_id``, and each ``tool_result``'s
    flattened stdout keyed by ``tool_use_id``, then joins them in transcript
    order. Tolerant of partial lines and missing pairs (stdout defaults to "").
    """
    try:
        size = path.stat().st_size
        with path.open("rb") as fh:
            fh.seek(max(0, size - _EPISODE_SCAN_BYTES))
            chunk = fh.read().decode("utf-8", "replace")
    except OSError as exc:
        _warn(f"episode scan read failed: {exc}")
        return []

    lines = chunk.splitlines()
    if size > _EPISODE_SCAN_BYTES:
        # Drop the possibly-truncated leading line only when we actually clipped.
        lines = lines[1:]

    commands: list[tuple[str, str]] = []  # (tool_use_id, command), in order
    results: dict[str, str] = {}          # tool_use_id -> stdout
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        if '"tool_use"' not in ln and '"tool_result"' not in ln:
            continue
        try:
            obj = json.loads(ln)
        except ValueError:
            continue
        content = (obj.get("message") or {}).get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "tool_use" and block.get("name") == "Bash":
                tu_id = block.get("id") or ""
                cmd = ""
                inp = block.get("input")
                if isinstance(inp, dict):
                    cmd = inp.get("command") or inp.get("cmd") or ""
                if cmd:
                    commands.append((tu_id, cmd))
            elif btype == "tool_result":
                tu_id = block.get("tool_use_id") or block.get("id") or ""
                if tu_id:
                    results[tu_id] = _tool_result_text(block)

    return [(cmd, results.get(tu_id, "")) for tu_id, cmd in commands]


def _is_git_commit(command: str) -> bool:
    if "git commit" not in command:
        return False
    # Skip --no-verify commits (mirrors the source guard).
    if "--no-verify" in command.lower().replace("-", ""):
        return False
    return bool(re.search(r"git\s+commit", command))


def _classify_command(command: str) -> Optional[str]:
    """Return the episode kind for a command, or None if it doesn't trigger.

    Priority is decided by the caller; this just labels a single command.
    """
    if "gh pr merge" in command:
        return "pr-merge"
    if "gh pr create" in command:
        return "pr-create"
    if _is_git_commit(command):
        return "git-commit"
    return None


def _gh_pr_view(args: list[str]) -> Optional[dict]:
    """Best-effort ``gh pr view ... --json`` → parsed dict, or None."""
    try:
        proc = subprocess.run(
            ["gh", "pr", "view", *args],
            capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return json.loads(proc.stdout)
    except Exception as exc:  # noqa: BLE001 - enrichment is best-effort
        _warn(f"gh pr view failed: {exc}")
    return None


def _episode_for_pr_create(command: str, stdout: str) -> Optional[tuple[str, str, list[str]]]:
    url_match = re.search(r"https://github\.com/[^\s]+/pull/(\d+)", stdout)
    if not url_match:
        return None
    pr_number = url_match.group(1)
    pr_url = url_match.group(0)
    info = _gh_pr_view([pr_url, "--json", "title,body,number"])
    if info:
        title = info.get("title", "")
        body = info.get("body", "")
        summary = f"Opened PR #{pr_number} — {title}".strip()
        content = f"PR URL: {pr_url}\n\nTitle: {title}\n\n{body}"
        return summary, content, ["pr", "pr-open"]
    summary = f"Opened PR #{pr_number}"
    content = f"PR URL: {pr_url}\n\nCommand: {command}\n\nOutput:\n{stdout}"
    return summary, content, ["pr", "pr-open"]


def _episode_for_pr_merge(command: str, stdout: str) -> Optional[tuple[str, str, list[str]]]:
    pr_url_match = re.search(r"https://github\.com/[^\s]+/pull/(\d+)", stdout)
    pr_number_match = re.search(r"\b(\d+)\b", command)
    pr_number = (
        pr_url_match.group(1) if pr_url_match
        else (pr_number_match.group(1) if pr_number_match else "unknown")
    )
    info = (
        _gh_pr_view([pr_number, "--json", "files,additions,deletions,title"])
        if pr_number != "unknown" else None
    )
    if info:
        additions = info.get("additions", 0)
        deletions = info.get("deletions", 0)
        file_count = len(info.get("files", []) or [])
        title = info.get("title", "")
        summary = f"Merged PR #{pr_number} — {title}".strip()
        content = (
            f"PR #{pr_number}: {title}\n"
            f"Stats: +{additions}/-{deletions} across {file_count} files\n\n"
            f"Command: {command}\nOutput:\n{stdout}"
        )
        return summary, content, ["pr", "pr-merge"]
    summary = f"Merged PR #{pr_number}"
    content = f"Command: {command}\nOutput:\n{stdout}"
    return summary, content, ["pr", "pr-merge"]


def _episode_for_git_commit(command: str, stdout: str) -> Optional[tuple[str, str, list[str]]]:
    commit_msg_match = re.search(r"-m\s+[\"']([^\"']+)[\"']", command)
    commit_msg = commit_msg_match.group(1) if commit_msg_match else "(see output)"
    hash_match = re.search(r"\[[\w/.-]+ ([a-f0-9]{6,})\]", stdout)
    short_hash = hash_match.group(1) if hash_match else ""
    summary = f"git commit: {commit_msg[:80]}"
    content = f"Commit hash: {short_hash}\nMessage: {commit_msg}\n\nOutput:\n{stdout}"
    return summary, content, ["commit"]


# Most-significant-first: a session that merged a PR records the merge, not an
# intermediate commit. One episode per Stop.
_KIND_PRIORITY = ("pr-merge", "pr-create", "git-commit")
_KIND_BUILDERS = {
    "pr-merge": _episode_for_pr_merge,
    "pr-create": _episode_for_pr_create,
    "git-commit": _episode_for_git_commit,
}


def _derive_episode(
    bash_calls: list[tuple[str, str]],
) -> Optional[tuple[str, str, list[str]]]:
    """Pick the most significant git/PR event in the tail and build its episode.

    Returns ``(summary, content, extra_tags)`` or None when nothing triggers.
    Mirrors the source ``_hook_auto_episode`` handlers; takes the LAST matching
    command of the highest-priority kind (the final merge/commit of the turn).
    """
    by_kind: dict[str, tuple[str, str]] = {}
    for command, stdout in bash_calls:
        kind = _classify_command(command)
        if kind:
            by_kind[kind] = (command, stdout)  # last wins
    for kind in _KIND_PRIORITY:
        if kind in by_kind:
            command, stdout = by_kind[kind]
            return _KIND_BUILDERS[kind](command, stdout)
    return None


def _write_episode_local(summary: str, content: str, tags: list[str]) -> bool:
    """Write the episode to the LOCAL memory backend. Returns True on success.

    Imports the §2 memory layer lazily so this hook (and the whole package)
    loads even before that layer exists — a missing backend just means no
    episode is written, never a crash. NO network: the backend is local SQLite.

    Episodes are logged with ``role="event"`` (importance 1.0 in the recall
    scoring formula) and the tags folded into ``metadata`` — matching the shape
    ``log_episode`` / the ``write_episode`` tool persist.
    """
    all_tags = list(_BASE_EPISODE_TAGS) + list(tags or [])
    try:
        from local_yep.memory.operations import log_episode

        log_episode(
            role="event",
            content=content,
            summary=summary,
            metadata={"tags": all_tags},
        )
        return True
    except Exception as exc:  # noqa: BLE001 - episode write is best-effort
        _warn(f"local episode write failed (memory backend unavailable?): {exc}")
        return False


def _maybe_write_episode(transcript_path: Path) -> None:
    """Scan the transcript tail and write at most one git/PR episode."""
    try:
        bash_calls = _collect_bash_calls(transcript_path)
        if not bash_calls:
            return
        episode = _derive_episode(bash_calls)
        if episode is None:
            return
        summary, content, tags = episode
        _write_episode_local(summary, content, tags)
    except Exception as exc:  # pragma: no cover - defensive; hooks never crash
        _warn(f"auto-episode derivation failed: {exc}")


# ---------------------------------------------------------------------------
# Circuit-breaker helpers (ported verbatim — pure file I/O)
# ---------------------------------------------------------------------------


def _stop_history_path(session_id: str) -> Optional[Path]:
    if not session_id:
        return None
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", session_id)[:128]
    if not safe:
        return None
    return STOP_HISTORY_DIR / f"{safe}.json"


def _load_ring(path: Optional[Path]) -> list[dict[str, Any]]:
    if path is None or not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, list):
        return []
    cleaned: list[dict[str, Any]] = []
    for entry in data[-RING_MAX:]:
        if isinstance(entry, dict):
            cleaned.append(entry)
    return cleaned


def _save_ring(path: Optional[Path], ring: list[dict[str, Any]]) -> None:
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(ring[-RING_MAX:], indent=2), encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        _warn(f"stop-history write failed: {exc}")


def _hash_text(text: str) -> str:
    norm = (text or "").strip()
    if not norm:
        return ""
    return hashlib.sha256(norm.encode("utf-8", errors="replace")).hexdigest()[:16]


def _tool_error_signature(transcript_path: Path) -> str:
    """Hash of the LAST ``tool_result`` flagged ``is_error=True`` (or '')."""
    last_err_payload: Optional[str] = None
    try:
        with transcript_path.open("r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = event.get("message") or {}
                content = msg.get("content")
                if not isinstance(content, list):
                    continue
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") != "tool_result":
                        continue
                    if not block.get("is_error"):
                        continue
                    payload = block.get("content")
                    if isinstance(payload, list):
                        parts = [
                            (b.get("text") or "") for b in payload
                            if isinstance(b, dict)
                        ]
                        payload_str = "\n".join(p for p in parts if p)
                    elif isinstance(payload, str):
                        payload_str = payload
                    else:
                        payload_str = json.dumps(payload, sort_keys=True)
                    if payload_str:
                        last_err_payload = payload_str
    except OSError:
        return ""
    if not last_err_payload:
        return ""
    return hashlib.sha256(
        last_err_payload.encode("utf-8", errors="replace")
    ).hexdigest()[:16]


def _should_suppress(
    ring: list[dict[str, Any]],
    text_hash: str,
    error_sig: str,
) -> bool:
    if not error_sig or not text_hash:
        return False
    if len(ring) < SUPPRESS_THRESHOLD:
        return False
    tail = ring[-SUPPRESS_THRESHOLD:]
    return all(
        entry.get("text_hash") == text_hash
        and entry.get("error_sig") == error_sig
        for entry in tail
    )


def _emit_suppress(reason: str) -> None:
    try:
        sys.stdout.write(json.dumps({"continue": False, "stopReason": reason}))
        sys.stdout.flush()
    except OSError as exc:
        _warn(f"suppress emit failed: {exc}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> int:
    try:
        payload_raw = sys.stdin.read()
    except Exception as exc:
        _warn(f"stdin read failed: {exc}")
        return 0
    if not payload_raw:
        return 0

    try:
        payload = json.loads(payload_raw)
    except json.JSONDecodeError as exc:
        _warn(f"bad payload json: {exc}")
        return 0

    session_id = payload.get("session_id") or payload.get("sessionId") or ""
    transcript_path = (
        payload.get("transcript_path")
        or payload.get("transcriptPath")
        or ""
    )
    cwd = payload.get("cwd") or os.getcwd()

    if not transcript_path or not Path(transcript_path).is_file():
        # Nothing useful to record without the transcript file. Bail quietly.
        return 0

    tpath = Path(transcript_path)
    last_user, last_assistant = _scan_transcript_tail(tpath)

    _, user_text = _extract_text(last_user or {})
    _, asst_text = _extract_text(last_assistant or {})
    if not user_text and not asst_text:
        return 0

    # --- Continuity anchor ----------------------------------------------
    anchor = {
        "session_id": session_id,
        "timestamp": (
            (last_assistant or last_user or {}).get("timestamp") or ""
        ),
        "cwd": cwd,
        "last_user": _preview(user_text),
        "last_assistant": _preview(asst_text),
        "transcript_path": transcript_path,
    }
    try:
        CONTINUITY_DIR.mkdir(parents=True, exist_ok=True)
        slug = _project_slug(cwd)
        out_path = CONTINUITY_DIR / f"{slug}.json"
        tmp = out_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(anchor, indent=2), encoding="utf-8")
        tmp.replace(out_path)  # atomic on POSIX; best-effort on Windows
    except OSError as exc:
        _warn(f"anchor write failed: {exc}")

    # --- Auto-episode (relocated from the PostToolUse hook) -------------
    # Derive an episode from the transcript tail (git/PR Bash calls) and write
    # it to the LOCAL memory backend. No HTTP, no daemon endpoint.
    _maybe_write_episode(tpath)

    # --- Activity ledger (PLAN §8 T8.2) ---------------------------------
    try:
        from local_yep import events

        events.emit(
            "turn.end",
            _preview(asst_text) if asst_text else "turn ended",
            category="session",
            session_id=session_id,
            project=Path(cwd).name if cwd else "",
        )
    except Exception:
        pass

    # --- Circuit-breaker ------------------------------------------------
    try:
        text_hash = _hash_text(asst_text)
        error_sig = _tool_error_signature(tpath)
        history_path = _stop_history_path(session_id)
        ring = _load_ring(history_path)
        suppress = _should_suppress(ring, text_hash, error_sig)
        ring.append(
            {
                "ts": anchor.get("timestamp", ""),
                "text_hash": text_hash,
                "error_sig": error_sig,
                "suppressed": suppress,
            }
        )
        _save_ring(history_path, ring)
        if suppress:
            _emit_suppress(
                "circuit-breaker: same Stop-hook error repeated 3x — "
                "surface the loop, name the cause, then stop"
            )
    except Exception as exc:  # pragma: no cover — defensive; hooks never crash
        _warn(f"circuit-breaker check failed: {exc}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
