"""SubagentStop hook — record when delegated work finishes (PLAN §8 T8.3).

A subagent completing is exactly the kind of thing a user walks away from and
wants to be told about. Without this event, delegated work finished silently
and the only evidence was buried in a transcript.

Ledger-only. No stdout, no network.
"""

from __future__ import annotations

from local_yep.hooks import _activity


def main() -> int:
    payload = _activity.read_payload()
    if not payload:
        return 0

    # Claude Code does not guarantee a name field here; take what is offered
    # rather than inventing one, and say "a subagent" when nothing is given.
    name = ""
    for key in ("subagent_type", "agent_type", "name", "label"):
        val = payload.get(key)
        if isinstance(val, str) and val:
            name = val
            break

    _activity.record(
        "subagent.stop",
        f"subagent finished: {name}" if name else "a subagent finished",
        payload=payload,
        category="subagent",
        severity="info",
        meta={"name": name} if name else {},
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main() or 0)
