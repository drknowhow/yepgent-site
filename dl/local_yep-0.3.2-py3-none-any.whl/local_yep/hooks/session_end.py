"""SessionEnd hook — record how a session actually finished (PLAN §8 T8.3).

Distinct from ``Stop``. ``Stop`` fires when the assistant finishes a turn;
``SessionEnd`` fires once when the session itself terminates and carries a
``reason``. Local Yep previously aliased ``sessionend`` onto the Stop hook,
which meant the reason — the only part that is genuinely new information — was
discarded.

Ledger-only. No stdout, no network.
"""

from __future__ import annotations

from local_yep.hooks import _activity

#: Reasons that indicate something went wrong rather than a clean finish.
_UNCLEAN = {"error", "crash", "timeout", "killed"}


def main() -> int:
    payload = _activity.read_payload()
    if not payload:
        return 0

    reason = payload.get("reason")
    reason = reason if isinstance(reason, str) and reason else "unknown"
    severity = "warn" if reason.lower() in _UNCLEAN else "info"

    _activity.record(
        "session.end",
        f"session ended: {reason}",
        payload=payload,
        category="session",
        severity=severity,
        meta={"reason": reason},
    )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main() or 0)
