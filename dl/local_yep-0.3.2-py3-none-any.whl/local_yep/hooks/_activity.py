"""Shared plumbing for the activity-ledger hooks (PLAN §8 T8.2/T8.3).

The three notification-grade Claude Code events — ``Notification``,
``SessionEnd``, ``SubagentStop`` — are thin: read the payload, write one ledger
row, emit nothing on stdout. They share everything except which fields they
pull out, so the parsing and the fail-open contract live here.

Fail-open is not optional. Every function in this module swallows its own
errors; the dispatcher already maps a raise to exit 0, but a hook that reaches
that path has already cost the user a stderr line for nothing.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path


def read_payload() -> dict:
    """Parse the hook JSON on stdin. Returns ``{}`` for anything unusable."""
    try:
        raw = sys.stdin.read()
    except Exception:
        return {}
    if not raw or not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    return data if isinstance(data, dict) else {}


def session_id(payload: dict) -> str:
    for key in ("session_id", "sessionId"):
        val = payload.get(key)
        if isinstance(val, str) and val:
            return val
    return ""


def project(payload: dict) -> str:
    """A human-meaningful project label: the cwd's directory name.

    We store the *name*, not the absolute path — the ledger is meant to be
    pasteable into a bug report, and a full path leaks more than it explains.
    """
    cwd = payload.get("cwd") or payload.get("currentWorkingDirectory") or ""
    if not isinstance(cwd, str) or not cwd:
        try:
            cwd = os.getcwd()
        except Exception:
            return ""
    try:
        return Path(cwd).name or cwd
    except Exception:
        return ""


def record(
    event: str,
    title: str,
    *,
    payload: dict,
    category: str,
    severity: str = "info",
    body: str = "",
    meta: dict | None = None,
) -> None:
    """Write one ledger row for ``payload``. Never raises, never prints."""
    try:
        from local_yep import events

        events.emit(
            event,
            title,
            category=category,
            severity=severity,
            body=body,
            session_id=session_id(payload),
            project=project(payload),
            meta=meta or {},
        )
    except Exception:
        pass
