"""UserPromptSubmit hook: inject Yep's per-turn ``<memory>`` block.

Ported from ``scripts/_hook_ambient_memory.py`` with the cloud coupling
removed. The source already imported the memory builder *in-process* (rather
than POSTing to a daemon); Local Yep keeps that shape but points it at the
**local** builder backed by SQLite:

    local_yep.memory.context.build_memory_context(prompt)

What changed vs the source:
* **No ``.env`` / ``SUPABASE_*`` loading.** The local builder reads
  ``~/.local-yep/memory.db`` directly — there are no cloud creds to source, so
  the whole ``_load_env`` dance is gone. Nothing here touches the network.
* **No ``CLAUDE_PROJECT_DIR`` / ``sys.path`` walk to find ``src``.** The
  builder is an installed package module (``local_yep.memory.context``), so a
  plain import resolves it.

What was kept (deliberately):
* **The cross-platform timeout fallback.** POSIX uses ``SIGALRM``; Windows
  (no ``SIGALRM``) uses a daemon-thread join. On overrun or any failure we emit
  an empty block rather than blocking the user's turn.
* **The no-double-wrap contract.** ``build_memory_context`` already wraps its
  output in ``<memory>...</memory>`` — we emit it as-is.

The hook always exits 0. A memory build that fails, times out, or finds an
empty DB simply injects nothing — it must never block or crash the turn.
"""
from __future__ import annotations

import json
import signal
import sys

# Time budget for building the memory block. Local SQLite recall is fast; a
# cold import + FTS5 query is comfortably under this. On overrun we skip
# injection rather than stall the user's turn.
TIMEOUT_SECS = 8


def _warn(msg: str) -> None:
    print(f"[hook_ambient_memory] WARNING: {msg}", file=sys.stderr)


def _breadcrumb(reason: str) -> None:
    """Record the last ambient-recall failure for ``yepgent doctor``.

    A failed recall is fail-open by design (the turn proceeds without a
    ``<memory>`` block) — but silently: hook stderr is only visible in debug
    mode. This breadcrumb is the durable signal, surfaced by the doctor verb.
    Best-effort; never raises.
    """
    try:
        import os
        from datetime import datetime, timezone
        from pathlib import Path

        path = Path(os.path.expanduser("~")) / ".local-yep" / "last_hook_error.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        doc = {
            "hook": "ambient_memory",
            "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "reason": reason,
        }
        path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    except Exception:
        pass


def _build_memory(prompt: str) -> str:
    """Return the local ``<memory>`` block, or '' if there is nothing.

    The import is deferred to call time so this module loads (and the hook
    dispatcher's lazy-import contract holds) even before the §2 memory backend
    exists. A missing/half-built memory layer raises ImportError here, which
    the budget wrapper catches and turns into an empty block — fail-open, never
    fail-the-turn.
    """
    from local_yep.memory.context import build_memory_context

    return build_memory_context(prompt or None) or ""


def _timeout_handler(signum, frame):
    raise TimeoutError("ambient memory build exceeded budget")


def _recall_with_budget(prompt: str) -> str:
    """Run ``_build_memory`` under ``TIMEOUT_SECS``.

    POSIX uses ``SIGALRM``; Windows (no ``SIGALRM``) uses a daemon-thread join.
    Any failure (including ImportError if §2 isn't built yet) yields ''.
    """
    if hasattr(signal, "SIGALRM"):
        signal.signal(signal.SIGALRM, _timeout_handler)
        signal.alarm(TIMEOUT_SECS)
        try:
            return _build_memory(prompt)
        except TimeoutError:
            _warn("memory build timed out; skipping injection")
            _breadcrumb(f"timed out after {TIMEOUT_SECS}s")
            return ""
        except Exception as exc:  # pragma: no cover - defensive
            _warn(f"memory build failed: {exc}")
            _breadcrumb(f"build failed: {type(exc).__name__}: {exc}")
            return ""
        finally:
            signal.alarm(0)

    import threading

    holder: list[str] = []

    def _run():
        try:
            holder.append(_build_memory(prompt))
        except Exception as exc:
            _warn(f"memory build failed: {exc}")
            _breadcrumb(f"build failed: {type(exc).__name__}: {exc}")

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    t.join(timeout=TIMEOUT_SECS)
    if holder:
        return holder[0]
    _warn("memory build timed out (Windows path); skipping injection")
    _breadcrumb(f"timed out after {TIMEOUT_SECS}s (thread path)")
    return ""


def main() -> int:
    # Keep stdout UTF-8 so non-ASCII in the block can't crash on a cp1252
    # console (belt-and-suspenders; json.dumps already escapes non-ASCII).
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass

    try:
        payload = json.loads(sys.stdin.read())
    except Exception as exc:
        _warn(f"could not parse stdin JSON: {exc}")
        return 0

    prompt = ""
    if isinstance(payload, dict):
        prompt = (
            payload.get("user_prompt")
            or payload.get("prompt")
            or payload.get("message")
            or ""
        )

    # build_memory_context already wraps its output in <memory>...</memory>;
    # emit as-is (do NOT double-wrap).
    memory_block = _recall_with_budget(prompt).strip()

    result = {
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": memory_block,
        }
    }
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
