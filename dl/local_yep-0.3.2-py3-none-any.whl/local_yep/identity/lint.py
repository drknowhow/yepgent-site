"""VOICE-not-BIOGRAPHY lint (PLAN.md §3 T3.8 #1).

The product moat is an *authored* personality, not storage. The single most
corrosive failure mode for that moat is a preset (or a wizard-authored voice)
that asserts a relationship which does not exist on day one — "the owner built
me", "we have worked together for months", "you shaped my values". On a fresh
memory database every one of those is a lie, and a lie in the seed voice is
exactly the "mail-merge hollowness" the §3 review warned about: a generic
template wearing a borrowed history.

So presets carry **VOICE, never BIOGRAPHY**. The bond is *earned* through the
recall → reflect loop, not asserted in the timbre. This module is the enforced
guardrail for that rule. It is intentionally a thin, dependency-light wrapper
around the canonical phrase table in :mod:`local_yep.presets` so there is ONE
list of banned phrases for the whole codebase — the preset validator
(:func:`local_yep.presets.validate_preset`), the personality wizard, and any
future authoring tool all lint against the same vocabulary.

Public surface
--------------
``lint_voice(text) -> list[str]``
    Pure check. Returns the biography-assertion phrases found (empty list ==
    clean). Never raises. This is what callers that want to *report* offending
    lines should use.

``assert_voice_clean(text, *, where=...) -> None``
    Raising guard for callers that want fail-closed behaviour (the wizard, a
    paid-pack installer): raises :class:`BiographyAssertionError` naming the
    offending phrase(s) and the first source line each occurs on.

``BiographyAssertionError``
    The exception ``assert_voice_clean`` raises. Subclasses
    :class:`local_yep.presets.PresetError` so existing ``except PresetError``
    sites (the preset validator) keep catching it unchanged.
"""
from __future__ import annotations

from local_yep.presets import (
    PresetError,
    _BIOGRAPHY_PATTERNS,
    _normalize,
    lint_biography,
)

__all__ = [
    "BiographyAssertionError",
    "BIOGRAPHY_PATTERNS",
    "lint_voice",
    "find_offending_lines",
    "assert_voice_clean",
]

#: Public, read-only view of the canonical banned-phrase table. Re-exported so
#: callers (docs/authoring-presets.md generators, the wizard) can introspect
#: the rule set without reaching into the ``presets`` package internals. The
#: source of truth stays :data:`local_yep.presets._BIOGRAPHY_PATTERNS`.
BIOGRAPHY_PATTERNS: tuple[str, ...] = _BIOGRAPHY_PATTERNS


class BiographyAssertionError(PresetError):
    """A voice block asserts a day-one relationship that cannot be true.

    Subclasses :class:`local_yep.presets.PresetError` so that callers already
    written to ``except PresetError`` (notably the preset validator) keep
    catching biography failures without change, while callers that want to
    distinguish *this* failure can catch the narrower type.
    """


def lint_voice(text: str) -> list[str]:
    """Return the biography-assertion phrases found in ``text``.

    Thin alias over :func:`local_yep.presets.lint_biography` so the lint has a
    single, voice-oriented public name regardless of whether the caller is a
    preset, the wizard, or a paid pack. An empty list means the voice is
    biography-clean. Whitespace/markdown-emphasis robust (``built *me*`` is
    still caught). Never raises.
    """
    return lint_biography(text)


def find_offending_lines(text: str) -> list[tuple[int, str, str]]:
    """Locate each banned phrase back in the *original* source lines.

    Returns a list of ``(line_number, phrase, line_text)`` tuples (1-based line
    numbers), one entry per (phrase, line) hit, sorted by line then phrase. The
    match is performed on the same normalization the lint uses (lower-cased,
    markdown emphasis stripped) so a phrase split only by ``*emphasis*`` or odd
    casing is still attributed to its line — this is what lets the error
    message *cite the offending line*, the T3.8 acceptance criterion.

    Pure; never raises. Empty list when the voice is clean.
    """
    found = lint_biography(text)
    if not found:
        return []
    hits: list[tuple[int, str, str]] = []
    for lineno, raw in enumerate(text.splitlines(), start=1):
        norm = _normalize(raw).replace("*", "").replace("_", "")
        for phrase in found:
            if phrase in norm:
                hits.append((lineno, phrase, raw.strip()))
    # A phrase may be wrapped across two source lines (the normalized full-text
    # match catches it but no single raw line does). Surface those too, with
    # line 0, so the error never claims "clean" when lint_voice did not.
    cited = {phrase for _, phrase, _ in hits}
    for phrase in found:
        if phrase not in cited:
            hits.append((0, phrase, "<phrase spans multiple lines>"))
    return sorted(hits, key=lambda h: (h[0], h[1]))


def assert_voice_clean(text: str, *, where: str = "voice") -> None:
    """Raise :class:`BiographyAssertionError` if ``text`` asserts biography.

    The fail-closed guard for authoring paths (the personality wizard, a paid
    preset-pack installer). The message names every offending phrase and the
    first source line it appears on, so the author can find and fix it.

    No-op when the voice is clean.
    """
    hits = find_offending_lines(text)
    if not hits:
        return
    # One concise citation per distinct phrase (first line it shows up on).
    by_phrase: dict[str, tuple[int, str]] = {}
    for lineno, phrase, line in hits:
        if phrase not in by_phrase:
            by_phrase[phrase] = (lineno, line)
    citations = "; ".join(
        f"{phrase!r} (line {lineno}: {line!r})"
        for phrase, (lineno, line) in sorted(by_phrase.items())
    )
    raise BiographyAssertionError(
        f"{where}: asserts a day-one relationship (biography). "
        f"Offending phrase(s): {citations}. "
        "Presets carry VOICE, never BIOGRAPHY — the bond forms through memory, "
        "not through claims in the seed voice."
    )
