"""Frozen ethical spine for Local Yep (T3.1).

The spine (`spine.md`) is the generic, owner-neutral ethical and cognitive
core shared by every Yep install. It is **immutable at runtime** and shipped
read-only inside the package; only the rendered identity overlay
(`identity.md`, built from `~/.local-yep/agent.toml` + the chosen voice
preset) is configurable. The render pipeline (§3 T3.6) reads the spine via
``read_spine()`` and prepends it to the overlay before injection.

Marked as a package so ``importlib.resources.files("local_yep.identity")``
resolves the bundled ``spine.md`` reliably across installed wheels, editable
installs, and source checkouts.
"""

from __future__ import annotations

import hashlib
from importlib import resources

__all__ = ["SPINE_FILENAME", "read_spine", "spine_sha256"]

SPINE_FILENAME = "spine.md"


def read_spine() -> str:
    """Return the frozen ethical spine as text.

    Reads the bundled, read-only ``spine.md`` from package data. The spine is
    never rendered or templated here — ``{owner}``/``{name}`` placeholders are
    substituted (if at all) downstream by the render pipeline; the bytes on
    disk stay frozen so :func:`spine_sha256` can verify them.
    """
    return (
        resources.files(__package__)
        .joinpath(SPINE_FILENAME)
        .read_text(encoding="utf-8")
        .strip()
    )


def spine_sha256() -> str:
    """SHA-256 of the bundled spine text.

    Lets SessionStart / the render pipeline re-verify that the spine in a
    user-writable home has not drifted from the frozen package copy
    (§3 risk: spine immutability is honor-system locally).
    """
    return hashlib.sha256(read_spine().encode("utf-8")).hexdigest()
