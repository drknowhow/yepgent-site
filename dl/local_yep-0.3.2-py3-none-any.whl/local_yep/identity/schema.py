"""``agent.toml`` schema, loader, and validator (T3.2).

``~/.local-yep/agent.toml`` is the configurable identity layer: the one file a
user edits to choose who their Yep is. It is intentionally small —

.. code-block:: toml

    name = "Yep"               # required — the display nickname (brand stays "Yep")
    pronoun = "they"           # optional

    [owner]
    name = "Sam"               # required
    callsign = "boss"          # optional

    preset = "terse-expert"    # required — one installed preset id

    [voice]                    # optional — any subset; omitted dials fall back
    verbosity = "terse"        # to the chosen preset's dials.toml defaults
    formality = "neutral"
    warmth = "measured"
    humor = "dry"
    emoji = "never"
    directness = "direct"

This module turns that TOML into a typed :class:`AgentConfig` with **every**
dial resolved (preset defaults merged with overrides), so the render pipeline
(T3.6) and :func:`local_yep.identity.dials.compile_dials` always receive a
complete vector.

Validation contract (the T3.2 acceptance criteria):

* ``name`` and ``owner.name`` are **required** — a missing/blank one is a hard
  error. (For the non-interactive ``yepgent init`` path that must never block, use
  :func:`make_default_config` instead of writing+loading a TOML.)
* ``preset`` must be an **installed** preset id, validated against
  :func:`local_yep.presets.list_presets`; an unknown preset names the available
  set in the error.
* every ``[voice]`` dial value is validated against
  :data:`local_yep.presets.DIAL_VALUES`; an illegal value names the dial and its
  allowed set.
* an **omitted** dial resolves to the chosen preset's ``dials.toml`` default
  (via :func:`local_yep.presets.load_preset`), so the resolved config always has
  all six dials.

Errors are :class:`AgentConfigError` with descriptive, actionable messages.
"""

from __future__ import annotations

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from local_yep.presets import (
    DIAL_NAMES,
    DIAL_VALUES,
    PresetError,
    list_presets,
    load_preset,
)

__all__ = [
    "DEFAULT_NAME",
    "DEFAULT_PRESET",
    "AgentConfig",
    "AgentConfigError",
    "load_config",
    "load_config_text",
    "make_default_config",
]

#: The fallback display nickname. The brand is always "Yep"; this keeps a fresh
#: install injecting full identity even with no ``agent.toml`` present.
DEFAULT_NAME: str = "Yep"

#: The default preset for the non-interactive path. Must be a bundled, free
#: preset id. ``terse-expert`` is the shipped default (PLAN §3 T3.4).
DEFAULT_PRESET: str = "terse-expert"


class AgentConfigError(ValueError):
    """``agent.toml`` is missing a required field, malformed, or has a bad value.

    Carries a descriptive, user-actionable message (names the offending field,
    the bad value, and the allowed set where relevant).
    """


@dataclass(frozen=True)
class AgentConfig:
    """A fully-resolved, typed identity configuration.

    All six dials are always present: any dial omitted from ``[voice]`` has been
    filled from the chosen preset's defaults, so downstream consumers
    (:func:`local_yep.identity.dials.compile_dials`, the render pipeline) never
    have to know whether a value came from the user or the preset.

    Attributes
    ----------
    name:
        The agent's display nickname (required). The product brand stays "Yep";
        this is what the overlay renders as the agent's name.
    owner_name:
        The owner's name (required) — ``[owner].name`` in the TOML.
    owner_callsign:
        Optional short form / nickname the agent may use for the owner
        (``[owner].callsign``). ``None`` when unset.
    pronoun:
        Optional pronoun for the agent (top-level ``pronoun``). ``None`` when
        unset.
    preset:
        The chosen preset id — guaranteed to be an installed preset.
    dials:
        The fully-resolved six-dial vector (preset defaults + user overrides),
        every value legal per :data:`local_yep.presets.DIAL_VALUES`.
    """

    name: str
    owner_name: str
    preset: str
    dials: dict[str, str]
    owner_callsign: str | None = None
    pronoun: str | None = None

    def dial_vector(self) -> tuple[str, ...]:
        """The resolved dials as a tuple in canonical :data:`DIAL_NAMES` order."""
        return tuple(self.dials[name] for name in DIAL_NAMES)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _require_str(doc: Mapping[str, Any], key: str, *, where: str) -> str:
    """Return ``doc[key]`` as a non-empty string or raise a hard error."""
    value = doc.get(key)
    if value is None:
        raise AgentConfigError(
            f"agent.toml: required field {where!r} is missing. "
            "Both 'name' and 'owner.name' are required "
            "(or use `yepgent init` / make_default_config for a default identity)."
        )
    if not isinstance(value, str) or not value.strip():
        raise AgentConfigError(
            f"agent.toml: field {where!r} must be a non-empty string, "
            f"got {value!r}."
        )
    return value.strip()


def _optional_str(doc: Mapping[str, Any], key: str, *, where: str) -> str | None:
    """Return ``doc[key]`` as a stripped string, or ``None`` if absent/blank."""
    value = doc.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise AgentConfigError(
            f"agent.toml: optional field {where!r} must be a string if set, "
            f"got {value!r}."
        )
    value = value.strip()
    return value or None


def _resolve_preset(preset: Any) -> str:
    """Validate ``preset`` against the installed set and return it."""
    installed = list_presets()
    if not isinstance(preset, str) or not preset.strip():
        raise AgentConfigError(
            "agent.toml: required field 'preset' must be a non-empty string. "
            f"Installed presets: {{{', '.join(installed)}}}."
        )
    preset = preset.strip()
    if preset not in installed:
        raise AgentConfigError(
            f"agent.toml: unknown preset {preset!r}. "
            f"Installed presets: {{{', '.join(installed)}}}."
        )
    return preset


def _resolve_dials(preset: str, voice: Any) -> dict[str, str]:
    """Merge the chosen preset's dial defaults with the ``[voice]`` overrides.

    Validates that any supplied override is a known dial with a legal value
    (descriptive error naming the dial + allowed set). Omitted dials fall back
    to the preset default, so the returned dict always covers all six dials.
    """
    # Start from the preset defaults. load_preset raises PresetError on a
    # malformed/missing preset dir; surface it as an AgentConfigError so callers
    # only have to catch one exception type.
    try:
        base = dict(load_preset(preset).dials)
    except PresetError as exc:  # pragma: no cover - defensive; preset already validated
        raise AgentConfigError(
            f"agent.toml: preset {preset!r} could not be loaded: {exc}"
        ) from exc

    if voice is None:
        overrides: dict[str, Any] = {}
    elif isinstance(voice, Mapping):
        overrides = dict(voice)
    else:
        raise AgentConfigError(
            f"agent.toml: [voice] must be a table of dials, got {voice!r}."
        )

    unknown = [d for d in overrides if d not in DIAL_VALUES]
    if unknown:
        raise AgentConfigError(
            "agent.toml: [voice] has unknown dial(s): "
            f"{', '.join(sorted(unknown))}. "
            f"Known dials: {{{', '.join(DIAL_NAMES)}}}."
        )

    resolved: dict[str, str] = {}
    for dial in DIAL_NAMES:
        allowed = DIAL_VALUES[dial]
        if dial in overrides:
            value = overrides[dial]
            if value not in allowed:
                raise AgentConfigError(
                    f"agent.toml: dial '[voice].{dial}'={value!r} is not legal; "
                    f"allowed: {{{', '.join(allowed)}}}."
                )
            resolved[dial] = value
        else:
            # Fall back to the preset default. A bundled preset is validated to
            # carry all six legal dials, but guard anyway so a hand-edited pack
            # gives a clear error rather than a KeyError.
            if dial not in base:
                raise AgentConfigError(
                    f"agent.toml: preset {preset!r} is missing a default for "
                    f"dial {dial!r}, and it was not set in [voice]."
                )
            default = base[dial]
            if default not in allowed:
                raise AgentConfigError(
                    f"agent.toml: preset {preset!r} default "
                    f"{dial!r}={default!r} is not legal; "
                    f"allowed: {{{', '.join(allowed)}}}."
                )
            resolved[dial] = default
    return resolved


def _build(doc: Mapping[str, Any]) -> AgentConfig:
    """Validate a parsed TOML document into an :class:`AgentConfig`."""
    if not isinstance(doc, Mapping):
        raise AgentConfigError("agent.toml: top level must be a table.")

    name = _require_str(doc, "name", where="name")
    pronoun = _optional_str(doc, "pronoun", where="pronoun")

    owner = doc.get("owner")
    if owner is None:
        raise AgentConfigError(
            "agent.toml: required table [owner] is missing "
            "(needs at least owner.name)."
        )
    if not isinstance(owner, Mapping):
        raise AgentConfigError(
            f"agent.toml: [owner] must be a table, got {owner!r}."
        )
    owner_name = _require_str(owner, "name", where="owner.name")
    owner_callsign = _optional_str(owner, "callsign", where="owner.callsign")

    preset = _resolve_preset(doc.get("preset"))
    dials = _resolve_dials(preset, doc.get("voice"))

    return AgentConfig(
        name=name,
        owner_name=owner_name,
        preset=preset,
        dials=dials,
        owner_callsign=owner_callsign,
        pronoun=pronoun,
    )


# --------------------------------------------------------------------------- #
# Public loaders
# --------------------------------------------------------------------------- #
def load_config_text(text: str) -> AgentConfig:
    """Parse + validate ``agent.toml`` text into a typed :class:`AgentConfig`.

    Raises :class:`AgentConfigError` on malformed TOML or any validation
    failure (missing required field, unknown preset, illegal dial value).
    """
    try:
        doc = tomllib.loads(text)
    except tomllib.TOMLDecodeError as exc:
        raise AgentConfigError(f"agent.toml: not valid TOML: {exc}") from exc
    return _build(doc)


def load_config(path: str | Path) -> AgentConfig:
    """Load + validate the ``agent.toml`` at ``path`` into an :class:`AgentConfig`.

    Raises :class:`AgentConfigError` if the file is missing, unreadable,
    malformed, or fails validation. The SessionStart render path resolves
    ``path`` from :data:`local_yep.home.AGENT_TOML`; on any failure there the
    caller should fall back to :func:`make_default_config` so a fresh or broken
    install still injects a sane identity.
    """
    p = Path(path)
    try:
        raw = p.read_bytes()
    except FileNotFoundError as exc:
        raise AgentConfigError(f"agent.toml not found at {p}.") from exc
    except OSError as exc:
        raise AgentConfigError(f"agent.toml: could not read {p}: {exc}") from exc
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AgentConfigError(f"agent.toml: {p} is not valid UTF-8: {exc}") from exc
    return load_config_text(text)


def make_default_config(
    name: str = DEFAULT_NAME, preset: str = DEFAULT_PRESET
) -> AgentConfig:
    """Build a sane default :class:`AgentConfig` with no file or input.

    This is the **non-interactive escape hatch**: ``yepgent init`` (and CI, which
    runs ``yepgent init </dev/null``) must never block on a wizard, and a fresh
    install with no ``agent.toml`` must still inject full identity. The defaults
    are name ``"Yep"`` (so the rendered identity always contains the brand word
    "Yep") and preset ``terse-expert``.

    The owner is unknown on day one — exactly the forming-bond premise — so
    ``owner_name`` is the literal placeholder ``"the owner"`` and
    ``owner_callsign`` is ``None``. The render pipeline's forming-bond frame
    ("I do not know {owner} yet …") is true of this default.

    Dials are the chosen preset's defaults (all six, fully resolved).

    Raises :class:`AgentConfigError` if ``preset`` is not an installed preset id
    or if ``name`` is blank — even the default path validates its inputs.
    """
    if not isinstance(name, str) or not name.strip():
        raise AgentConfigError("make_default_config: name must be non-empty.")
    resolved_preset = _resolve_preset(preset)
    dials = _resolve_dials(resolved_preset, None)
    return AgentConfig(
        name=name.strip(),
        owner_name="the owner",
        preset=resolved_preset,
        dials=dials,
        owner_callsign=None,
        pronoun=None,
    )
