"""Identity render pipeline — the localized ``build_static_system_prompt``.

PLAN.md §3 T3.6 (+ the T3.8 forming-bond / memory-engine mitigations baked into
the assembly). This is the seam where a typed :class:`~local_yep.identity.schema.AgentConfig`
(name, owner, preset, resolved dials) becomes the single identity string the
SessionStart hook injects.

The assembly order is contractual — both the §3 acceptance test and the *moat*
depend on it. In order:

1. **Forming-bond opener.** Literally true of a fresh memory database: this Yep
   does NOT know the owner yet. Stated first so nothing below can be misread as
   an asserted history. (T3.8 #2.)
2. **The frozen ethical spine**, verbatim. Hash-verified against the frozen
   package baseline first (:data:`FROZEN_SPINE_SHA256`) so a tampered local
   spine is *detected*, not silently injected. ``{owner}``/``{name}``
   placeholders are then substituted for display — the substitution happens on
   a copy, never on the bytes the hash is taken over.
3. **A name/owner identity line** — who this agent is and whose it is.
4. **The selected preset's authored VOICE block** (H2). The *seed* timbre —
   never biography (enforced by :func:`local_yep.presets.validate_preset` /
   :mod:`local_yep.identity.lint`).
5. **The compiled dials stanza** (H3) — the deterministic "how to sound" lines.
6. **The memory-is-the-authenticity-engine note** (T3.8 #3): the preset is only
   the seed; who this Yep *becomes* is built from the recall → reflect loop.

THE MOAT: the preset carries VOICE, the spine carries the ethical/cognitive
essence, and *memory* carries the relationship. The render never asserts a
relationship that does not exist on day one. The opener and the closing note
exist precisely to keep a relationship-less, freshly-installed agent from
sounding like mail-merge.

No network. No file writes. The only inputs are the in-package frozen spine +
bundled presets and the already-parsed config the caller hands in.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Final

from local_yep.identity import read_spine, spine_sha256
from local_yep.identity.schema import (
    DEFAULT_NAME,
    DEFAULT_PRESET,
    AgentConfig,
    make_default_config,
)
from local_yep.identity.dials import compile_dials
from local_yep.presets import validate_preset

__all__ = [
    "FROZEN_SPINE_SHA256",
    "SpineIntegrityError",
    "render_identity",
    "reload_identity",
]

#: The SHA-256 of the frozen, bundled ``spine.md`` at build time. The render
#: pipeline re-hashes the on-disk spine on every render and compares against
#: this constant; a mismatch means the spine has drifted from its frozen form
#: (the §3 risk: ``~/.local-yep`` and even the package dir are user-writable, so
#: spine immutability is honor-system locally). On mismatch we FAIL LOUD rather
#: than inject a tampered ethical core.
#:
#: If the spine is *intentionally* revised, regenerate this with::
#:
#:     python -c "from local_yep.identity import spine_sha256; print(spine_sha256())"
#:
#: and update this constant in the SAME commit — that pairing is the "no silent
#: edits to the spine" guardrail (Rule 4) expressed in code review terms.
FROZEN_SPINE_SHA256: Final[str] = (
    "98768340b170b4a5be5320a6d27cecb655a5d6edef6c1c98e3fd8c5191e7beaa"
)

#: The owner-name sentinel :func:`make_default_config` uses when the owner is
#: unknown (a fresh install, before onboarding). Rendered owner-neutrally.
_UNKNOWN_OWNER: Final[str] = "the owner"

_MEMORY_NOTE: Final[str] = (
    "# Memory is the authenticity engine\n"
    "The voice above is only the *seed*. It is the starting timbre, not a "
    "history. Who you actually become is not in this prompt — it is in your "
    "memory: the facts, episodes, and reflections you accumulate doing real "
    "work. Recall before you act; reflect after, but only when there is a real "
    "lesson. The recall → reflect loop is what turns this generic seed into "
    "a specific relationship over time. Until memory fills in, stay honest "
    "about how new this is."
)


class SpineIntegrityError(RuntimeError):
    """The on-disk spine no longer matches its frozen build-time hash.

    Raised by :func:`render_identity` before any identity is assembled. A
    tampered or drifted spine is a hard stop: the ethical core is the one part
    of the identity that must never be silently mutated, so we refuse to inject
    it rather than ship an altered conscience.
    """


def _forming_bond_opener(name: str, owner_name: str) -> str:
    """The literal-on-day-one opener (T3.8 #2).

    Owner-neutral when the owner is still the default sentinel (no onboarding
    yet): we cannot name someone we do not know. Once a real owner name exists,
    it is used so the frame is personal without asserting any *shared past* —
    "I do not know you yet" is the whole point.
    """
    if owner_name.strip().lower() == _UNKNOWN_OWNER:
        whom = "the person I work with"
    else:
        whom = owner_name.strip()
    return (
        f"I am {name}. I do not know {whom} yet — I will learn through what "
        "we do and what I write down."
    )


def _identity_line(config: AgentConfig) -> str:
    """The name/owner identity line (assembly step 3).

    Names the agent (with pronoun if set) and whose agent it is (with callsign
    if set), plus a one-line seed-voice note. The fuller "seed, not biography"
    framing lives once in the spine and once in the closing memory note, so this
    line stays lean rather than repeating it a third time.
    """
    if config.pronoun:
        who = f"I am {config.name} (pronoun: {config.pronoun})."
    else:
        who = f"I am {config.name}."

    if config.owner_name.strip().lower() == _UNKNOWN_OWNER:
        whose = (
            "I do not yet know who I belong to; that is established during "
            "onboarding."
        )
    else:
        if config.owner_callsign:
            whose = (
                f"I belong to {config.owner_name} "
                f"(I may call them {config.owner_callsign})."
            )
        else:
            whose = f"I belong to {config.owner_name}."

    seed = f"My voice is seeded by the '{config.preset}' preset."
    return f"{who} {whose} {seed}"


def _render_spine() -> str:
    """Return the frozen spine, hash-verified, ready for placeholder fill.

    Verifies the live on-disk spine against :data:`FROZEN_SPINE_SHA256` and
    raises :class:`SpineIntegrityError` on mismatch. The hash is taken over the
    frozen bytes (via :func:`spine_sha256`); placeholder substitution for
    display is the caller's job and never touches the hashed text.
    """
    live = spine_sha256()
    if live != FROZEN_SPINE_SHA256:
        raise SpineIntegrityError(
            "spine.md integrity check FAILED: the on-disk ethical spine does "
            f"not match its frozen build-time hash.\n  expected: {FROZEN_SPINE_SHA256}\n"
            f"  on disk : {live}\n"
            "Refusing to inject a tampered ethical core. If the spine was "
            "revised intentionally, update render.FROZEN_SPINE_SHA256 in the "
            "same commit (Rule 4: no silent edits to the spine)."
        )
    return read_spine()


def _fill_placeholders(text: str, *, name: str, owner_name: str) -> str:
    """Substitute the spine's ``{name}``/``{owner}`` display placeholders.

    Done on a copy *after* the integrity hash, so the frozen-bytes guarantee is
    untouched. Owner is left as the human-readable sentinel ("the owner") when
    unknown — the spine prose ("``{owner}`` is the person this Yep belongs to")
    reads correctly either way.
    """
    return text.replace("{name}", name).replace("{owner}", owner_name)


@lru_cache(maxsize=8)
def _render_cached(
    name: str,
    owner_name: str,
    owner_callsign: str | None,
    pronoun: str | None,
    preset: str,
    dial_vector: tuple[str, ...],
) -> str:
    """Pure, cached render keyed on the hashable identity tuple.

    :func:`render_identity` flattens the (unhashable) :class:`AgentConfig` into
    these primitives so the cache key is stable and ``lru_cache`` works.
    :func:`reload_identity` clears this cache.
    """
    from local_yep.presets import DIAL_NAMES

    dials = dict(zip(DIAL_NAMES, dial_vector))

    spine = _fill_placeholders(_render_spine(), name=name, owner_name=owner_name)

    preset_obj = validate_preset(preset)  # re-asserts VOICE-not-BIOGRAPHY
    voice_block = preset_obj.voice.strip()
    dials_stanza = compile_dials(dials)

    config = AgentConfig(
        name=name,
        owner_name=owner_name,
        preset=preset,
        dials=dials,
        owner_callsign=owner_callsign,
        pronoun=pronoun,
    )

    parts = [
        _forming_bond_opener(name, owner_name),
        spine,
        _identity_line(config),
        voice_block,
        dials_stanza,
        _MEMORY_NOTE,
    ]
    return "\n\n".join(p for p in parts if p and p.strip())


def render_identity(config: AgentConfig | None = None) -> str:
    """Assemble the full injected identity string for ``config``.

    Parameters
    ----------
    config:
        A fully-resolved :class:`~local_yep.identity.schema.AgentConfig`. When
        ``None`` (a fresh install with no ``agent.toml``), falls back to
        :func:`~local_yep.identity.schema.make_default_config` (name "Yep",
        preset ``terse-expert``) so a brand-new install still injects full
        identity containing the brand word "Yep".

    Returns
    -------
    str
        The identity, assembled in the contractual order: forming-bond opener,
        frozen (hash-verified) spine, name/owner line, preset voice block,
        compiled dials stanza, memory-is-the-authenticity-engine note. Joined
        with blank lines; no trailing newline.

    Raises
    ------
    SpineIntegrityError
        If the on-disk spine has drifted from its frozen build-time hash.
    local_yep.presets.PresetError
        If the configured preset is missing/malformed or its voice asserts
        biography (it should never reach here for a bundled preset, but the
        check is re-run so a tampered preset fails closed).
    """
    if config is None:
        config = make_default_config(name=DEFAULT_NAME, preset=DEFAULT_PRESET)
    return _render_cached(
        config.name,
        config.owner_name,
        config.owner_callsign,
        config.pronoun,
        config.preset,
        config.dial_vector(),
    )


def reload_identity() -> None:
    """Drop the cached renders.

    Call after the user edits ``agent.toml`` (swaps preset, retunes dials) or
    re-runs the wizard, so the next :func:`render_identity` reflects the new
    config. Mirrors the source ``reload_instructions`` contract.
    """
    _render_cached.cache_clear()
