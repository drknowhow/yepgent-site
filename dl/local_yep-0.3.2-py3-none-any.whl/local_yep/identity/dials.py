"""Compile a six-dial voice vector into a deterministic prose stanza (T3.5).

The voice *dials* are a compact, machine-checkable summary of how the agent
should sound: six axes (verbosity, formality, warmth, humor, emoji,
directness), each with three legal values. A preset ships default dials; the
user may override any subset in ``agent.toml`` (§3 T3.2). This module turns the
resolved dial vector into a short, injectable **"Voice dials"** stanza written
in second-person imperative — the form the agent reads as instruction.

Design contract (the acceptance criteria for T3.5):

* **Deterministic.** Each legal dial value maps to ONE fixed sentence fragment.
  The fragments are assembled in a fixed order (:data:`~local_yep.presets.DIAL_NAMES`).
  The same input dict therefore yields **byte-identical** output every call —
  no dict-ordering, locale, or timestamp dependence.
* **Total over the legal domain.** Every value in
  :data:`~local_yep.presets.DIAL_VALUES` has a non-empty fragment; there are no
  gaps. A value outside that domain is a programmer error (the schema layer
  validates user input first) and raises :class:`ValueError` rather than
  silently dropping a dial.
* **Authored, not generated.** The fragments are hand-written for quality — this
  is part of the personality moat, not a mechanical value->string mapping. They
  are second-person imperatives a model can act on ("Default to <=5 lines…"),
  not descriptions of a persona.

The fragments deliberately avoid emoji and owner-specific phrasing; they are
owner-neutral and brand-neutral. The render pipeline (T3.6) prepends the
preset's authored VOICE block and the forming-bond frame; this stanza is the
crisp, deterministic *spec* that sits beneath that prose.
"""

from __future__ import annotations

from typing import Final

from local_yep.presets import DIAL_NAMES, DIAL_VALUES

__all__ = ["DIAL_FRAGMENTS", "STANZA_HEADER", "compile_dials"]

#: Header that opens the compiled stanza. Kept as a constant so the render
#: pipeline and tests can reference the exact string.
STANZA_HEADER: Final[str] = "Voice dials (how to sound):"

# --------------------------------------------------------------------------- #
# The fragment table — the heart of T3.5 and part of the moat.
#
# One fixed, hand-authored second-person-imperative fragment per legal dial
# value. Keys mirror local_yep.presets.DIAL_VALUES EXACTLY (validated at import
# time below). Each fragment is a single self-contained sentence so the stanza
# reads as a clean bulleted spec regardless of which subset of dials is active.
# --------------------------------------------------------------------------- #
DIAL_FRAGMENTS: Final[dict[str, dict[str, str]]] = {
    "verbosity": {
        "terse": "Default to <=5 lines; expand only on request.",
        "balanced": "Answer in a few tight paragraphs; depth on demand.",
        "expansive": "Explain the why behind the what; give the fuller picture.",
    },
    "formality": {
        "casual": "Keep it conversational; contractions and plain words are fine.",
        "neutral": "Use clear, professional language without stiffness.",
        "formal": "Write in polished, composed prose; no slang.",
    },
    "warmth": {
        "cool": "Stay matter-of-fact; skip pleasantries and warmth.",
        "measured": "Be cordial but economical; warmth only when it is real.",
        "warm": "Acknowledge the human; notice when something is hard.",
    },
    "humor": {
        "none": "No jokes; keep the register straight.",
        "dry": "Dry, deadpan wit is welcome - never a performed joke.",
        "playful": "Light humor and wordplay are fine when they land.",
    },
    "emoji": {
        "never": "Never use emoji.",
        "sparing": "Emoji rarely, at most one, only when it adds signal.",
        "free": "Emoji are fine where they fit naturally.",
    },
    "directness": {
        "diplomatic": "Soften hard truths with tact, but still say them.",
        "direct": "Say what you think plainly; lead with the point.",
        "blunt": "Be blunt; do not cushion the message.",
    },
}


def _verify_fragment_table() -> None:
    """Fail loudly at import if the fragment table drifts from the vocabulary.

    Guarantees totality: every dial in :data:`DIAL_NAMES` is covered and every
    legal value has a non-empty fragment, with no stray dials or values. This
    turns the "every legal value yields a non-empty fragment" acceptance
    criterion into an import-time invariant rather than a hope.
    """
    if tuple(DIAL_FRAGMENTS) != DIAL_NAMES:
        raise RuntimeError(
            "dials.py: DIAL_FRAGMENTS keys/order "
            f"{tuple(DIAL_FRAGMENTS)!r} must equal presets.DIAL_NAMES "
            f"{DIAL_NAMES!r}"
        )
    for dial, allowed in DIAL_VALUES.items():
        frags = DIAL_FRAGMENTS[dial]
        if tuple(frags) != tuple(allowed):
            raise RuntimeError(
                f"dials.py: dial {dial!r} fragment values {tuple(frags)!r} "
                f"must equal the legal values {tuple(allowed)!r}"
            )
        for value, fragment in frags.items():
            if not fragment or not fragment.strip():
                raise RuntimeError(
                    f"dials.py: empty fragment for {dial!r}={value!r}"
                )


_verify_fragment_table()


def compile_dials(dials: dict[str, str]) -> str:
    """Compile a resolved dial vector into the deterministic "Voice dials" stanza.

    Parameters
    ----------
    dials:
        A mapping of dial name -> value covering exactly the six dials in
        :data:`~local_yep.presets.DIAL_NAMES`, each value legal per
        :data:`~local_yep.presets.DIAL_VALUES`. In normal use this is the
        fully-resolved vector the schema loader produces (preset defaults with
        any ``agent.toml`` overrides already merged), so every dial is present.

    Returns
    -------
    str
        A stanza of the form::

            Voice dials (how to sound):
            - Default to <=5 lines; expand only on request.
            - Use clear, professional language without stiffness.
            - ...

        Fragments appear in the fixed :data:`~local_yep.presets.DIAL_NAMES`
        order, one per line, regardless of the input dict's key order. The
        output is byte-identical for byte-identical input (no trailing
        newline).

    Raises
    ------
    ValueError
        If a dial is missing, unknown, or carries a value outside its legal
        set. The schema layer (T3.2) validates user-supplied dials before this
        point; a failure here therefore signals an internal contract breach,
        not a user-config error, so it is surfaced loudly rather than dropped.
    """
    missing = [name for name in DIAL_NAMES if name not in dials]
    if missing:
        raise ValueError(
            "compile_dials: missing dial(s): " + ", ".join(missing)
        )
    unknown = [name for name in dials if name not in DIAL_FRAGMENTS]
    if unknown:
        raise ValueError(
            "compile_dials: unknown dial(s): " + ", ".join(sorted(unknown))
        )

    lines = [STANZA_HEADER]
    for name in DIAL_NAMES:  # fixed canonical order — the determinism guarantee
        value = dials[name]
        fragments = DIAL_FRAGMENTS[name]
        if value not in fragments:
            allowed = ", ".join(fragments)
            raise ValueError(
                f"compile_dials: dial {name!r}={value!r} is not legal; "
                f"allowed: {{{allowed}}}"
            )
        lines.append(f"- {fragments[value]}")
    return "\n".join(lines)
