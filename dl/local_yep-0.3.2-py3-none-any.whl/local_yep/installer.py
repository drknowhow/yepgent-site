"""``yepgent init`` / ``yepgent init --force`` / ``yepgent upgrade`` (T1.4).

Wires Local Yep into a repository the way C3 does, writing four artifacts and
bootstrapping the shared home:

    (a) ``~/.local-yep/``            via :func:`local_yep.home.bootstrap`  (G1/T1.2)
    (b) ``.mcp.json``               registers the slim local memory MCP server
    (c) ``.claude/settings.json``   SessionStart / UserPromptSubmit / Stop hooks
                                    wired through the ``yepgent-hook`` entrypoint
    (d) ``CLAUDE.md`` + ``AGENTS.md`` managed fenced block        (G6/T1.3)

Design rules:

- **Merge, never clobber.** ``.mcp.json`` and ``.claude/settings.json`` may
  already contain other servers / hooks (e.g. C3). We add or replace only the
  Local Yep keys (the ``yep`` MCP server; the three ``yepgent-hook`` hook entries),
  preserving everything else. Hook merging is idempotent — re-running does not
  append duplicate ``yepgent-hook`` entries.
- **Out-of-fence prose is preserved** in the managed Markdown (T1.3 contract).
- **``--force``** regenerates the managed block + the MCP / hook wiring even when
  already present (the managed block is always regenerated; ``--force`` also
  rewrites the JSON wiring rather than leaving an existing entry untouched).
- **``upgrade``** re-runs generation against the installed version (re-stamping
  the managed block's version) and re-stamps ``~/.local-yep/version``. It does
  not need ``--force`` to re-render the managed block, since the block is always
  regenerated from the current template.
- **No network. No commit.** Files only.

The CLI (:mod:`local_yep.cli`) calls :func:`init` / :func:`upgrade`; both return
an ``int`` exit code (0 = success).
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from local_yep import __version__, home
from local_yep import managed_block

# ---------------------------------------------------------------------------
# Constants for the wiring we own
# ---------------------------------------------------------------------------

#: MCP server key we register in ``.mcp.json``. The slim memory-only server
#: (§1 T1.7) is launched as a module so it works regardless of whether the
#: console scripts are on PATH in the Claude Code environment.
MCP_SERVER_KEY = "yepgent"

#: Hook events we wire, mapped to the ``yepgent-hook`` sub-event the dispatcher
#: (:mod:`local_yep.hooks.run`) understands. Claude Code event name -> arg.
HOOK_EVENTS: dict[str, str] = {
    "SessionStart": "session_start",
    "UserPromptSubmit": "ambient_memory",
    "Stop": "session_stop",
    # The enforcement gate (protected governance files + dangerous shell).
    # Wired with a tool-name matcher so reads never pay the hook cost.
    "PreToolUse": "pre_tool_use",
    # Activity-ledger events (PLAN §8 T8.3). These are the moments worth
    # telling a human about — Claude blocked on a permission prompt, a session
    # ending, delegated work finishing — and none of them were listened for
    # before. Each writes one row to ~/.local-yep/events.db and emits nothing.
    "Notification": "notification",
    "SessionEnd": "session_end",
    "SubagentStop": "subagent_stop",
}

#: Tag embedded in each hook command so we can recognise and replace OUR hook
#: entries on re-run without disturbing the user's (or C3's) hooks.
_HOOK_TAG = "yepgent-hook"

# Target files (relative to the repo root passed to init/upgrade).
MANAGED_MARKDOWN = ("CLAUDE.md", "AGENTS.md")


# ---------------------------------------------------------------------------
# Small JSON helpers
# ---------------------------------------------------------------------------

def _load_json(path: Path) -> dict:
    """Load a JSON object from ``path``; ``{}`` if absent or unparseable."""
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _dump_json(path: Path, data: dict) -> None:
    """Write ``data`` as pretty JSON with a trailing newline (LF newlines)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


# ---------------------------------------------------------------------------
# (b) .mcp.json — register the slim local memory MCP server
# ---------------------------------------------------------------------------

def _mcp_server_entry() -> dict:
    """The ``.mcp.json`` entry launching the slim memory MCP server.

    Launched as ``<python> -m local_yep.mcp.server`` so it resolves through the
    same interpreter that installed the package — robust whether or not the
    ``yep`` console scripts are on the Claude Code process PATH.
    """
    return {
        "command": sys.executable or "python",
        "args": ["-m", "local_yep.mcp.server"],
    }


def write_mcp_json(repo: Path, *, force: bool) -> bool:
    """Register the ``yep`` MCP server in ``<repo>/.mcp.json`` (merging).

    Preserves any other servers (e.g. ``c3``). Returns True if the file changed.
    With ``force`` the entry is rewritten even if present; without force an
    existing identical entry is left as-is (idempotent).
    """
    path = repo / ".mcp.json"
    data = _load_json(path)
    servers = data.get("mcpServers")
    if not isinstance(servers, dict):
        servers = {}
        data["mcpServers"] = servers

    desired = _mcp_server_entry()
    current = servers.get(MCP_SERVER_KEY)
    if current == desired and not force:
        return False
    servers[MCP_SERVER_KEY] = desired
    _dump_json(path, data)
    return True


# ---------------------------------------------------------------------------
# (c) .claude/settings.json — hook wiring via yepgent-hook
# ---------------------------------------------------------------------------

def _hook_command() -> str:
    """The shell command Claude Code runs for a Yep hook.

    We invoke the ``yepgent-hook`` console script and pass the sub-event as argv.
    The dispatcher reads the JSON payload from stdin itself, so no shell
    redirection is needed. ``yepgent-hook`` is created by the package's
    ``[project.scripts]`` and is cross-platform (no Windows-only ``py -3``).
    """
    return "yepgent-hook"


def _event_matcher(event: str) -> str:
    """Per-event hook matcher.

    PreToolUse fires only for the tools the enforcement gate inspects
    (file-edit + shell — :func:`local_yep.enforcement.hook_matcher`); every
    other event uses the match-all empty matcher.
    """
    if event == "PreToolUse":
        from local_yep import enforcement

        return enforcement.hook_matcher()
    return ""


def _is_yep_hook(entry: dict) -> bool:
    """True if a single hook entry is one Local Yep installed."""
    cmd = entry.get("command", "")
    return isinstance(cmd, str) and _HOOK_TAG in cmd


def _strip_yep_hooks(hook_list: list) -> list:
    """Remove Local Yep hook entries from a hook-group list, keeping others."""
    cleaned = []
    for group in hook_list:
        if not isinstance(group, dict):
            cleaned.append(group)
            continue
        inner = group.get("hooks")
        if isinstance(inner, list):
            kept = [h for h in inner if not (isinstance(h, dict) and _is_yep_hook(h))]
            if kept:
                new_group = dict(group)
                new_group["hooks"] = kept
                cleaned.append(new_group)
            # else: the whole group was ours and now empty -> drop it
        else:
            cleaned.append(group)
    return cleaned


def write_settings_json(repo: Path, *, force: bool) -> bool:
    """Wire SessionStart / UserPromptSubmit / Stop / PreToolUse hooks in settings.json.

    Merges into ``<repo>/.claude/settings.json`` without disturbing other hooks
    (e.g. C3's, which live in ``settings.local.json`` but could also appear
    here). Idempotent: existing Yep hook entries are stripped and re-added rather
    than duplicated. ``force`` does not change behaviour here (the merge is
    always a clean replace of our own entries) but is accepted for symmetry.
    Returns True if the file changed.
    """
    path = repo / ".claude" / "settings.json"
    data = _load_json(path)
    before = json.dumps(data, sort_keys=True)

    hooks = data.get("hooks")
    if not isinstance(hooks, dict):
        hooks = {}
        data["hooks"] = hooks

    command = _hook_command()
    for event, sub in HOOK_EVENTS.items():
        existing_list = hooks.get(event)
        if not isinstance(existing_list, list):
            existing_list = []
        # Remove any prior Yep entries for this event, then add the canonical one.
        cleaned = _strip_yep_hooks(existing_list)
        cleaned.append(
            {
                "matcher": _event_matcher(event),
                "hooks": [
                    {
                        "type": "command",
                        "command": f"{command} {sub}",
                    }
                ],
            }
        )
        hooks[event] = cleaned

    after = json.dumps(data, sort_keys=True)
    if after == before and not force:
        return False
    _dump_json(path, data)
    return after != before


# ---------------------------------------------------------------------------
# (d) managed CLAUDE.md / AGENTS.md block
# ---------------------------------------------------------------------------

def write_managed_markdown(repo: Path, version: str) -> bool:
    """Render the managed block into CLAUDE.md and AGENTS.md.

    Returns True if any target file changed. Out-of-fence prose is preserved
    (T1.3 contract); a file with no fence gets one appended; running twice is
    idempotent.
    """
    changed = False
    for name in MANAGED_MARKDOWN:
        if managed_block.apply_managed_block(repo / name, version):
            changed = True
    return changed


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def _resolve_repo(repo: Path | str | None) -> Path:
    return Path(repo).resolve() if repo is not None else Path.cwd().resolve()


def _stamp_home_version(version: str) -> None:
    """(Re)write ``~/.local-yep/version`` to the current package version."""
    try:
        home.VERSION.parent.mkdir(parents=True, exist_ok=True)
        home.VERSION.write_text(version + "\n", encoding="utf-8")
    except OSError:
        pass


def init(force: bool = False, repo: Path | str | None = None) -> int:
    """Install Local Yep into ``repo`` (default: the current directory).

    Steps: bootstrap the home, register the MCP server, wire the hooks, write the
    managed Markdown block. With ``force``, regenerate the managed block + wiring
    even when present. Returns 0 on success.
    """
    target = _resolve_repo(repo)
    version = __version__

    # (a) shared home — idempotent, never clobbering.
    home.bootstrap()

    # (b)-(d) repo wiring.
    mcp_changed = write_mcp_json(target, force=force)
    hooks_changed = write_settings_json(target, force=force)
    md_changed = write_managed_markdown(target, version)

    _report(target, mcp_changed, hooks_changed, md_changed, force=force, verb="init")
    return 0


def upgrade(repo: Path | str | None = None) -> int:
    """Re-run generation against the installed version (re-stamp the block).

    Regenerates the managed Markdown block (which carries the version stamp),
    refreshes the MCP + hook wiring, re-stamps ``~/.local-yep/version``, and
    clears any cached identity (``reload_instructions`` semantics) best-effort.
    Returns 0 on success.
    """
    target = _resolve_repo(repo)
    version = __version__

    home.bootstrap()
    _stamp_home_version(version)

    mcp_changed = write_mcp_json(target, force=True)
    hooks_changed = write_settings_json(target, force=True)
    md_changed = write_managed_markdown(target, version)

    # Best-effort: clear the cached rendered identity so the next SessionStart
    # re-renders against the upgraded package (reload_instructions semantics).
    _clear_identity_cache()

    _report(target, mcp_changed, hooks_changed, md_changed, force=True, verb="upgrade")
    return 0


def _clear_identity_cache() -> None:
    """Invoke the identity-render cache clear if §3 has landed; else no-op."""
    for mod_name, fn_name in (
        ("local_yep.identity.render", "reload_identity"),
        ("local_yep.core.system_prompt", "reload_instructions"),
    ):
        try:
            import importlib

            mod = importlib.import_module(mod_name)
            fn = getattr(mod, fn_name, None)
            if callable(fn):
                fn()
        except Exception:  # noqa: BLE001 - optional, never fail the upgrade
            continue


def _report(
    target: Path,
    mcp_changed: bool,
    hooks_changed: bool,
    md_changed: bool,
    *,
    force: bool,
    verb: str,
) -> None:
    """Print a short human summary of what ``init`` / ``upgrade`` did."""
    def mark(changed: bool) -> str:
        return "wrote" if changed else "unchanged"

    print(f"yep {verb}: {target}")
    print(f"  ~/.local-yep/      bootstrapped ({home.HOME})")
    print(f"  .mcp.json          {mark(mcp_changed)}")
    print(f"  .claude/settings.json  {mark(hooks_changed)}")
    print(f"  CLAUDE.md/AGENTS.md  {mark(md_changed)}")
    if force and verb == "init":
        print("  (--force: managed regions regenerated)")


# ---------------------------------------------------------------------------
# Uninstall — the clean inverse of init's repo wiring
# ---------------------------------------------------------------------------

def remove_mcp_json(repo: Path) -> str:
    """Remove the ``yepgent`` MCP server entry from ``<repo>/.mcp.json`` (merging).

    Preserves every other server (e.g. ``c3``); if ours was the only one, the
    now-empty ``mcpServers`` key is dropped. Returns ``"removed"`` /
    ``"absent"`` (no file) / ``"unchanged"`` (our key wasn't present).
    """
    path = repo / ".mcp.json"
    if not path.exists():
        return "absent"
    data = _load_json(path)
    servers = data.get("mcpServers")
    if not isinstance(servers, dict) or MCP_SERVER_KEY not in servers:
        return "unchanged"
    del servers[MCP_SERVER_KEY]
    if not servers:
        data.pop("mcpServers", None)
    _dump_json(path, data)
    return "removed"


def remove_settings_hooks(repo: Path) -> str:
    """Strip Local Yep's hook entries from ``<repo>/.claude/settings.json``.

    Reuses :func:`_strip_yep_hooks`, so only entries tagged ``yepgent-hook`` are
    removed; other hooks (e.g. C3's) survive. Empty hook-event lists and an
    empty ``hooks`` map are pruned. Returns ``"removed"`` / ``"absent"`` /
    ``"unchanged"``.
    """
    path = repo / ".claude" / "settings.json"
    if not path.exists():
        return "absent"
    data = _load_json(path)
    hooks = data.get("hooks")
    if not isinstance(hooks, dict):
        return "unchanged"
    before = json.dumps(data, sort_keys=True)
    for event in HOOK_EVENTS:
        existing_list = hooks.get(event)
        if not isinstance(existing_list, list):
            continue
        cleaned = _strip_yep_hooks(existing_list)
        if cleaned:
            hooks[event] = cleaned
        else:
            hooks.pop(event, None)
    if not hooks:
        data.pop("hooks", None)
    if json.dumps(data, sort_keys=True) == before:
        return "unchanged"
    _dump_json(path, data)
    return "removed"


def remove_managed_markdown(repo: Path) -> dict[str, str]:
    """Strip the managed block from CLAUDE.md / AGENTS.md, preserving prose.

    Per file returns one of: ``"cleared"`` (block removed, other prose kept),
    ``"deleted"`` (the file held nothing but our block, so it was removed),
    ``"unchanged"`` (no managed block present), ``"absent"`` (no such file).
    """
    result: dict[str, str] = {}
    for name in MANAGED_MARKDOWN:
        path = repo / name
        if not path.exists():
            result[name] = "absent"
            continue
        existing = path.read_text(encoding="utf-8")
        if not managed_block.has_block(existing):
            result[name] = "unchanged"
            continue
        updated = managed_block.strip_from_text(existing)
        if updated.strip() == "":
            path.unlink()
            result[name] = "deleted"
        else:
            with open(path, "w", encoding="utf-8", newline="") as fh:
                fh.write(updated)
            result[name] = "cleared"
    return result


def _purge_home() -> str:
    """Delete the entire ``~/.local-yep/`` home (memory, identity, keys, config).

    Irreversible; only ever called once the caller has explicitly confirmed.
    Returns ``"purged"`` / ``"absent"`` / ``"failed: <reason>"``.
    """
    import shutil

    if not home.HOME.exists():
        return "absent"
    try:
        shutil.rmtree(home.HOME)
        return "purged"
    except OSError as exc:
        return f"failed: {exc}"


def uninstall(
    repo: Path | str | None = None,
    *,
    purge_memory: bool = False,
) -> int:
    """Reverse :func:`init`'s repo wiring — the clean inverse of install.

    Removes the ``yepgent`` MCP server entry, the three ``yepgent-hook`` hook
    entries, and the managed CLAUDE.md / AGENTS.md block, preserving every other
    server, hook, and out-of-fence byte. By default ``~/.local-yep/`` (memory,
    identity, keys, config) is left **completely intact** so a later
    ``yepgent init`` resumes seamlessly.

    With ``purge_memory=True`` the whole ``~/.local-yep/`` home is deleted too —
    irreversible; the CLI only sets it after an explicit confirmation. Does not
    (and cannot) pip-uninstall the package; the CLI prints that final step.
    Returns 0 on success.
    """
    target = _resolve_repo(repo)

    mcp = remove_mcp_json(target)
    hooks = remove_settings_hooks(target)
    md = remove_managed_markdown(target)
    purge = _purge_home() if purge_memory else "kept"

    _report_uninstall(target, mcp, hooks, md, purge)
    return 0


def _report_uninstall(
    target: Path,
    mcp: str,
    hooks: str,
    md: dict[str, str],
    purge: str,
) -> None:
    """Print a short human summary of what ``uninstall`` removed."""
    md_summary = ", ".join(f"{name}: {state}" for name, state in md.items())
    print(f"yep uninstall: {target}")
    print(f"  .mcp.json          {mcp}")
    print(f"  .claude/settings.json  {hooks}")
    print(f"  CLAUDE.md/AGENTS.md  {md_summary}")
    if purge == "kept":
        print(f"  ~/.local-yep/      kept ({home.HOME}) — memory & identity preserved")
    elif purge == "purged":
        print(f"  ~/.local-yep/      PURGED ({home.HOME})")
    elif purge == "absent":
        print("  ~/.local-yep/      absent (nothing to purge)")
    else:
        print(f"  ~/.local-yep/      {purge}")
    print("  package            still installed — run `pipx uninstall local-yep`")
    print("                     (or `pip uninstall local-yep`) to finish")
