"""Tool-level hard-enforcement of governance rules (Local Yep port).

Ported from the Yep source ``src/core/enforcement.py``. Consumed by a Claude
Code **PreToolUse** hook that runs before every Edit/Write/Bash tool call, this
module mechanizes "you cannot silently edit the rules — or the machinery that
enforces them — without going through a confirmation gate".

Two enforcement responsibilities (kept verbatim in spirit from the source):

1. **Protected-path gate (hard deny, fail closed).** Edits to the governance
   files — the frozen ethical spine, the rendered identity, the hook wiring,
   and this guard's own module — are denied unless a confirmation token is
   present. Fails CLOSED: if the gate can't positively verify authorization, a
   protected-file edit is denied.

2. **Dangerous-command audit (deny / audit).** Force-push to main/master is
   hard-denied; catastrophic recursive deletes are hard-denied; shell writes to
   a protected path are hard-denied. Other risky flags (--no-verify,
   reset --hard, clean -f, checkout --) are surfaced as an audit note, not
   blocked.

WHAT CHANGED vs the source (T1.8):
* **The cloud ``rule_change_lock_held()`` network call is GONE.** The source
  did a remote REST GET to check a rule-change lock singleton, failing *closed*
  on any network/auth error — which meant that **offline** it denied ALL
  protected-path edits forever. Local Yep is 100% local: there is no network in
  this path. The lock is replaced by a **local typed-confirmation token** (a
  short-lived file written by a ``yep`` CLI verb). Still fail-closed, still no
  network module imported — just a local-filesystem check.

INVARIANTS for this file (asserted by the task acceptance): it imports no
network module and makes no network call, anywhere.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Optional


# Governance files that may not be edited without a confirmation token. Stored
# as POSIX suffixes, matched against the tail of any absolute path so the gate
# fires in every worktree/checkout, not just one root.
#
# Local Yep equivalents of the source's frozen governance set:
#   - the frozen ethical spine + rendered identity (§3 — the "rules")
#   - the hook wiring (.claude/settings.json — prevents self-disabling)
#   - this enforcement module itself (the gate logic)
PROTECTED_SUFFIXES: tuple[str, ...] = (
    "spine.md",                         # frozen ethical spine (§3) — the rules
    "identity.md",                      # rendered identity overlay (§3)
    ".claude/settings.json",            # hook wiring — prevents self-disabling
    "local_yep/enforcement.py",         # this module — the gate logic itself
    "local_yep/integrity.py",           # the system-integrity verifier
    "local_yep/_ed25519.py",            # the signature primitive it relies on
    "_integrity/manifest.json",         # the signed integrity manifest
    "_integrity/manifest.sig",          # its signature
    "templates/behaviors.md",           # operative behaviors — part of the system
    "templates/tool_recipes.md",        # operative tool recipes — part of the system
)

# Tool names whose target file we must check against PROTECTED_SUFFIXES.
_FILE_EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit", "Update",
                    "mcp__c3__c3_edit"}


def _normalize(path: str) -> str:
    """Lowercase, forward-slashed, stripped path for suffix comparison."""
    return path.replace("\\", "/").strip().lower()


def protected_match(path: Optional[str]) -> Optional[str]:
    """Return the protected suffix this path resolves to, or None.

    Matches when the normalized path equals a protected suffix or ends with
    ``/<suffix>`` — so an absolute path in any worktree is caught, while an
    unrelated file that merely contains the substring (e.g.
    ``my_spine.md_backup``) is not.
    """
    if not path:
        return None
    norm = _normalize(path)
    for suffix in PROTECTED_SUFFIXES:
        s = suffix.lower()
        if norm == s or norm.endswith("/" + s):
            return suffix
    return None


def _extract_target_path(tool_name: str, tool_input: dict) -> Optional[str]:
    """Pull the file path a file-edit tool is about to write."""
    if not isinstance(tool_input, dict):
        return None
    # NotebookEdit uses notebook_path; the rest use file_path.
    return (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or tool_input.get("path")
    )


# --- Dangerous Bash detection (ported verbatim) -------------------------

# Force-push to a protected branch. Hard deny.
_FORCE_PUSH_MAIN = re.compile(
    r"git\s+push\b[^\n|&;]*"
    r"(?:--force\b|--force-with-lease\b|(?<![\w-])-f\b)"
    r"[^\n|&;]*\b(?:main|master)\b"
    r"|git\s+push\b[^\n|&;]*\b(?:main|master)\b[^\n|&;]*"
    r"(?:--force\b|--force-with-lease\b|(?<![\w-])-f\b)",
    re.IGNORECASE,
)

# Catastrophic recursive delete of a root-ish path. Hard deny.
_CATASTROPHIC_RM = re.compile(
    r"\brm\s+(?:-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r|-r\s+-f|-f\s+-r)\b\s*"
    r"(?:/|~|\$HOME|\*|\.\s*$|/\*)",
    re.IGNORECASE,
)

# Any force-push (to a non-protected branch). Surfaced as an audit note.
_FORCE_PUSH_ANY = re.compile(
    r"git\s+push\b[^\n|&;]*"
    r"(?:--force\b|--force-with-lease\b|(?<![\w-])-f\b)",
    re.IGNORECASE,
)

# Risky-but-allowed substring patterns — surfaced as an audit note, not blocked.
_AUDIT_PATTERNS = (
    ("--no-verify", "skips git hooks (never skip hooks unless explicitly asked)"),
    ("--no-gpg-sign", "bypasses commit signing"),
    ("reset --hard", "discards uncommitted work"),
    ("git clean -f", "deletes untracked files irreversibly"),
    ("checkout --", "discards local changes to tracked files"),
)

# Shell write to a protected governance file (redirect / tee / in-place sed /
# dd) — bypasses the file-edit gate otherwise. Built from PROTECTED_SUFFIXES so
# it tracks the same list. Hard deny, fail closed. Source reads of these paths
# (cat/grep/git add) are intentionally NOT matched — only write operators.
_PROTECTED_RE = "(?:" + "|".join(re.escape(s) for s in PROTECTED_SUFFIXES) + ")"
_SHELL_WRITE_PROTECTED = re.compile(
    r"(?:>>?|(?<![\w-])tee\b|(?<![\w-])sed\s+-i\b|(?<![\w-])dd\b)"
    r"[^\n|&;]*?" + _PROTECTED_RE,
    re.IGNORECASE,
)


def bash_verdict(command: str) -> tuple[str, str]:
    """Classify a Bash command: ("deny" | "audit" | "ok", reason).

    "deny"  -> block the call (catastrophic / approval-reserved).
    "audit" -> allow, but the hook emits a warning for the audit trail.
    "ok"    -> nothing notable.
    """
    if not command or not isinstance(command, str):
        return ("ok", "")

    if _FORCE_PUSH_MAIN.search(command):
        return (
            "deny",
            "Force-push to main/master is blocked — push to a feature branch "
            "and open a PR, or get explicit owner approval.",
        )
    if _CATASTROPHIC_RM.search(command):
        return (
            "deny",
            "Refusing a recursive force-delete of a root/home/glob target — "
            "catastrophic and irreversible.",
        )
    if _SHELL_WRITE_PROTECTED.search(command):
        return (
            "deny",
            "Blocked shell write to a protected governance file — spine / "
            "identity / enforcement / hook-wiring edits must go through the "
            "confirmation gate, not a shell redirect/sed/tee.",
        )

    if _FORCE_PUSH_ANY.search(command):
        return ("audit", "dangerous flag detected: force-push — "
                "verify the target branch is not protected")

    lowered = command.lower()
    for needle, why in _AUDIT_PATTERNS:
        if needle in lowered:
            return ("audit", f"dangerous flag detected: {needle} — {why}")
    return ("ok", "")


# --- Local typed-confirmation token (replaces the old cloud lock) -------
#
# A hook subprocess can't prompt the user interactively, so authorization for a
# protected-path edit is carried by a short-lived LOCAL token file that a `yep`
# CLI verb writes after the user types the confirmation phrase. This is the
# offline, no-network analogue of the source's rule_change lock.
#
# Contract (so the CLI and this gate agree):
#   - Location: ``~/.local-yep/rule_change.lock`` (override with
#     ``YEP_RULE_CHANGE_TOKEN`` to point at an alternate file — used in tests).
#   - Content: JSON ``{"confirm": "<phrase>", "reason": "...",
#     "acquired_at": <unix-seconds>}``.
#   - The ``confirm`` phrase MUST equal :data:`CONFIRM_PHRASE` (the typed
#     confirmation). A mismatched / missing phrase is treated as no token.
#   - TTL: a token older than :data:`TOKEN_TTL_SECONDS` is stale → not held.
#
# Fail-closed everywhere: a missing file, malformed JSON, wrong phrase, missing
# timestamp, or an expired token all return (False, ...) so the protected-path
# gate denies. No network module imported — pure local-filesystem read.

#: The exact phrase the token must carry. The `yep` CLI verb writes this only
#: after the user types it verbatim, so its presence in a fresh local file is
#: proof of a deliberate, typed confirmation.
CONFIRM_PHRASE = "Authorize protected edit"

#: A confirmation token older than this (seconds) is stale and does not
#: authorize an edit — keeps the window short so a forgotten token can't
#: silently re-authorize a later, unrelated edit. 5 minutes.
TOKEN_TTL_SECONDS = 300


def _token_path() -> Path:
    """Resolve the confirmation-token file path (env-overridable for tests)."""
    override = os.environ.get("YEP_RULE_CHANGE_TOKEN")
    if override:
        return Path(override)
    return Path(os.path.expanduser("~")) / ".local-yep" / "rule_change.lock"


def rule_change_lock_held() -> tuple[bool, str]:
    """Return (held, detail) from the LOCAL typed-confirmation token.

    Replaces the source's remote REST check. Reads a short-lived local token
    file written by a ``yep`` CLI verb after the user types the confirmation
    phrase. Fails CLOSED on any problem — a missing, malformed, wrong-phrase,
    or expired token denies the edit. No network module imported.
    """
    path = _token_path()
    try:
        if not path.is_file():
            return (False, "no confirmation token present — failing closed")
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        return (False, f"token read failed ({type(exc).__name__}) — failing closed")

    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return (False, "confirmation token malformed — failing closed")
    if not isinstance(data, dict):
        return (False, "confirmation token malformed — failing closed")

    if data.get("confirm") != CONFIRM_PHRASE:
        return (False, "confirmation phrase missing/mismatched — failing closed")

    acquired_at = data.get("acquired_at")
    if not isinstance(acquired_at, (int, float)):
        return (False, "confirmation token has no valid timestamp — failing closed")

    age = time.time() - float(acquired_at)
    if age < 0 or age > TOKEN_TTL_SECONDS:
        return (
            False,
            f"confirmation token expired ({int(age)}s old, "
            f"TTL {TOKEN_TTL_SECONDS}s) — failing closed",
        )

    reason = data.get("reason") or "(no reason given)"
    return (True, f"typed confirmation present: {reason}")


# --- Top-level decision (ported verbatim, lock_check now local) ---------

def evaluate(tool_name: str, tool_input: dict,
             lock_check=rule_change_lock_held) -> dict:
    """Decide whether a tool call is permitted.

    Returns a dict with:
      - decision: "deny" (block), "audit" (allow + log a warning), or
        "ok" (no action — proceed to the normal permission flow).
      - reason: human-readable explanation (empty for "ok").
      - protected: the matched protected suffix, when relevant.

    ``lock_check`` is injectable for testing (defaults to the local
    typed-confirmation token check).
    """
    if tool_name in _FILE_EDIT_TOOLS:
        target = _extract_target_path(tool_name, tool_input)
        matched = protected_match(target)
        if matched:
            held, detail = lock_check()
            if held:
                return {
                    "decision": "audit",
                    "reason": (
                        f"Editing protected governance file '{matched}' — "
                        f"{detail}. A confirmation token authorizes this edit; "
                        f"keep the change minimal and record why."
                    ),
                    "protected": matched,
                }
            return {
                "decision": "deny",
                "reason": (
                    f"Blocked edit to protected governance file '{matched}'. "
                    f"{detail}. Changes to the rules — or to the machinery that "
                    f"enforces them — require a typed confirmation token "
                    f"(run `yepgent confirm` and type "
                    f"'{CONFIRM_PHRASE}'), which only the owner can authorize."
                ),
                "protected": matched,
            }
        return {"decision": "ok", "reason": ""}

    if tool_name in ("Bash", "mcp__c3__c3_shell"):
        command = ""
        if isinstance(tool_input, dict):
            command = tool_input.get("command") or tool_input.get("cmd") or ""
        verdict, reason = bash_verdict(command)
        return {"decision": verdict, "reason": reason}

    return {"decision": "ok", "reason": ""}


# --- Wiring + token helpers (used by the installer and the CLI verb) -----

def hook_matcher() -> str:
    """The PreToolUse tool-name matcher for the hook wiring.

    The union of every tool name :func:`evaluate` actually inspects, joined
    as a Claude Code hook matcher regex — so the guard hook is invoked only
    for file-edit and shell tools and adds zero latency to reads.
    """
    names = sorted(_FILE_EDIT_TOOLS | {"Bash", "mcp__c3__c3_shell"})
    return "|".join(names)


def write_confirmation_token(reason: str = "") -> Path:
    """Write the short-lived typed-confirmation token (the CLI verb's body).

    The caller (``yepgent confirm``) is responsible for having collected the
    typed :data:`CONFIRM_PHRASE` from a real TTY — this function just records
    it. Returns the token path.
    """
    path = _token_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = {
        "confirm": CONFIRM_PHRASE,
        "reason": reason or "(no reason given)",
        "acquired_at": time.time(),
    }
    path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    return path


def revoke_confirmation_token() -> bool:
    """Delete the confirmation token if present. Returns True if one existed."""
    path = _token_path()
    try:
        path.unlink()
    except FileNotFoundError:
        return False
    except OSError:
        return False
    return True
