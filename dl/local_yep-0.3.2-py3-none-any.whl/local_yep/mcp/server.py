"""Slim MCP server for Local Yep (PLAN.md §1 T1.7 + §4 P3-WIRE).

A standalone **stdio** MCP server exposing Yep's seven canonical memory tools:

    recall_fact · recall_facts · recall_reflections · recall_episodes
    remember_fact · reflect · write_episode

backed entirely by the 100%-local SQLite store at ``~/.local-yep/memory.db``
(:mod:`local_yep.memory`) — plus, since P3 (§4), the install-manifest **toolspace**
surface (``list_installed`` · ``tool_search`` · ``install_tool`` · ``call_tool`` ·
``uninstall_tool``) over :mod:`local_yep.toolspace`. The memory path is still
100% local (no network, no Ollama, no Supabase, no daemon); a toolspace tool only
touches the network on an explicit registry search / manifest fetch.

Why this exists
---------------
This is the Local-Yep analogue of the source repo's
``src/interfaces/ide_mcp.py``: an interactive ``claude`` session already loads
Yep's identity (managed CLAUDE.md block) + memory block (UserPromptSubmit hook)
+ continuity (SessionStart hook); it only lacks the *tool surface*. The source
``ide_mcp`` serves the FULL ~150-tool ``build_yep_server`` registry; this slim
build deliberately does NOT — it stands up a NEW minimal registry of just the
memory tools (the hot path Yep uses constantly) plus the P3 toolspace tools for
discovering + installing pre-built tools/packs. The ~150-tool cloud registry is
still NOT pulled in.

Built on the official ``mcp`` SDK only
--------------------------------------
Unlike the source ``ide_mcp`` (which unwraps the Agent-SDK's
``build_yep_server``), this slim server is hand-registered directly on a raw
``mcp.server.lowlevel.Server`` — the same library ``ide_mcp`` ultimately serves
over stdio (``from mcp import types``; ``from mcp.server.stdio import
stdio_server``) and the only server dependency the package declares. No
``claude_agent_sdk`` dependency, keeping the core install lean.

alwaysLoad pin (Claude Code "tool search" / deferral)
-----------------------------------------------------
Claude Code (>=2.1.121) defers MCP tool schemas by default: only tool NAMES
load at session start, and first use of each tool costs a ToolSearch round-trip
to fetch its schema. The memory tools are Yep's canonical, constantly-used
surface — paying a schema fetch before every recall/remember is pure latency on
the hottest path. Claude Code honors a per-tool ``_meta`` hint,
``anthropic/alwaysLoad``, that keeps a specific tool eagerly loaded. We set it
on all seven memory tools (the ``_pin_always_load`` / ``_mark_always_load``
pattern ported from ``ide_mcp``). Older clients ignore the hint gracefully (the
tools simply defer like everything else).

Run:
    python -m local_yep.mcp.server
(this is exactly the ``yep_tools`` entry the slim ``.mcp.json`` points at.)
"""
from __future__ import annotations

import json
from typing import Any, Awaitable, Callable, Optional

import anyio
from mcp import types
from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server

from local_yep import memory as _mem


# ---------------------------------------------------------------------------
# Result envelope
# ---------------------------------------------------------------------------
# The underlying memory functions return plain JSON-serializable dicts whose
# RETURN SHAPES are preserved verbatim from the cloud build (the §2 / T1.7
# non-negotiable). We ship each as a single MCP text-content block — the same
# ``json.dumps(..., default=str)`` envelope the source's ``_ok`` used, so the
# wire payload is byte-compatible. ``default=str`` keeps datetimes/UUIDs from
# exploding serialization.
def _ok(payload: Any) -> types.CallToolResult:
    """Wrap a Python result in the MCP tool-result envelope (success)."""
    return types.CallToolResult(
        content=[types.TextContent(type="text",
                                   text=json.dumps(payload, default=str))],
        isError=False,
    )


def _err(exc: Exception) -> types.CallToolResult:
    """Surface a handler exception as an MCP tool error — never crash the
    server. A failing tool is a tool_result with ``isError=True``, not a dead
    transport."""
    return types.CallToolResult(
        content=[types.TextContent(type="text", text=f"{type(exc).__name__}: {exc}")],
        isError=True,
    )


# ---------------------------------------------------------------------------
# The seven memory tools — thin model-facing wrappers over local_yep.memory.
# ---------------------------------------------------------------------------
# These mirror the source repo's ``src/tools/memory_tools.py`` wrappers: each
# returns the SAME JSON-serializable dict shape the cloud build returns. They
# call the ported ``local_yep.memory`` operations directly. ``recall_episodes``
# / ``write_episode`` run UNSCOPED here: this slim server holds no live
# thread/project binding (no daemon, no agent-session), so episodes are global
# and ``write_episode`` logs with ``thread_id=None`` — exactly the
# headless-caller degradation the source documents for a server with no thread
# closure.


def _remember_fact(key: str, value: str, confidence: float = 1.0,
                   source: Optional[str] = None) -> dict:
    """Upsert a fact, surfacing overwrite drift when an existing value changes.

    When this write overwrites a *different* existing value, ``write_fact``
    snapshots the prior value into the row's metadata history ring and returns
    a ``drift`` payload; we surface it so the model can confirm the overwrite
    (Rule 2). Absent drift, the response is the plain success shape.
    """
    row = _mem.write_fact(key, value, confidence=confidence, source=source)
    out = {"ok": True, "stored": {"key": key, "value": value}, "id": row.get("id")}
    drift = row.get("drift")
    if drift:
        out["drift"] = drift
        out["warning"] = (
            f"Overwrote an existing different value for '{key}'. The prior "
            f"value was snapshotted to metadata.fact_history and is "
            f"recoverable. Confirm this overwrite was intended."
        )
    return out


def _recall_fact(key: str) -> dict:
    f = _mem.read_fact(key)
    return {"found": bool(f), "fact": f}


def _recall_facts(prefix: Optional[str] = None, limit: int = 25) -> dict:
    rows = _mem.list_facts(prefix=prefix, limit=limit)
    return {"count": len(rows), "facts": rows}


def _recall_episodes(query: str, limit: int = 5,
                    scope: Optional[str] = None) -> dict:
    """Semantic episode recall. Unscoped (global) on the slim server.

    The slim server has no live thread/project binding, so the default scope
    degrades to global — the same behavior the source documents for a headless
    caller (``current_thread_id`` / ``current_project_id`` both None). The
    ``scope`` parameter is accepted for surface-compatibility with the full
    tool; an explicit ``thread:<uuid>`` / ``project:<uuid>`` still narrows.
    """
    requested = (scope or "").strip().lower()
    effective_thread_id: Optional[str] = None
    effective_project_id: Optional[str] = None
    if requested.startswith("project:"):
        effective_project_id = scope.split(":", 1)[1].strip() or None
    elif requested.startswith("thread:"):
        effective_thread_id = scope.split(":", 1)[1].strip() or None
    # "thread" / "project" / "global" / "" / unknown → global (nothing to
    # anchor to without a daemon-bound thread).

    rows = _mem.search_episodes(
        query, limit=limit,
        thread_id=effective_thread_id,
        project_id=effective_project_id,
    )
    if effective_project_id:
        scope_label = f"project:{effective_project_id}"
    elif effective_thread_id:
        scope_label = f"thread:{effective_thread_id}"
    else:
        scope_label = "global"
    return {"count": len(rows), "episodes": rows, "scope": scope_label}


def _reflect(note: str, tag: Optional[str] = None, weight: float = 1.0,
            failure_class: Optional[str] = None) -> dict:
    row = _mem.write_reflection(note, tag=tag, weight=weight,
                                failure_class=failure_class)
    return {"ok": True, "id": row.get("id"), "note": note,
            "failure_class": failure_class}


def _recall_reflections(query: str, limit: int = 5,
                        kinds: Optional[list[str]] = None) -> dict:
    rows = _mem.search_reflections(query, limit=limit, kinds=kinds or None)
    return {"count": len(rows), "reflections": rows, "kinds_filter": kinds or None}


def _write_episode(summary: str, content: str,
                  metadata: Optional[dict] = None) -> dict:
    """Log a deliberate role='event' episode. Thread-unbound on the slim
    server (``thread_id=None``) — there is no live conversation thread to
    attribute it to without a daemon."""
    row = _mem.log_episode(
        role="event",
        content=content,
        summary=summary,
        metadata=metadata or {},
        thread_id=None,
    )
    return {"id": row.get("id"), "summary": summary, "thread_id": None}


# ---------------------------------------------------------------------------
# Tool registry — exactly the seven memory tools. Each entry pairs an
# ``mcp.types.Tool`` (name + description + inputSchema, copied verbatim from the
# source repo's sdk_server.py so the model-facing contract matches the cloud
# build byte-for-byte) with the wrapper that runs it. The registry is a single
# source of truth: ``tools/list`` returns the Tool objects and ``tools/call``
# dispatches through ``_DISPATCH``.
# ---------------------------------------------------------------------------
_TOOLS: list[types.Tool] = [
    types.Tool(
        name="recall_fact",
        description="Read one fact by exact key.",
        inputSchema={
            "type": "object",
            "properties": {"key": {"type": "string"}},
            "required": ["key"],
        },
    ),
    types.Tool(
        name="recall_facts",
        description="List facts, optionally filtered by key prefix.",
        inputSchema={
            "type": "object",
            "properties": {
                "prefix": {"type": "string"},
                "limit": {"type": "integer", "default": 25},
            },
        },
    ),
    types.Tool(
        name="recall_reflections",
        description="Semantic search over your past reflections.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
                "kinds": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["behavior", "pattern", "mistake", "insight",
                                 "preference", "note", "decision_graph"],
                    },
                    "description": (
                        "Optional tag filter. Procedural questions: use "
                        "['behavior','pattern']. Mistake review: ['mistake']. "
                        "When omitted, all tags are searched."
                    ),
                },
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="recall_episodes",
        description="Semantic search over past conversation episodes.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "limit": {"type": "integer", "default": 5},
                "scope": {
                    "type": "string",
                    "description": (
                        "Which subset of episodes to search. Default (omit) "
                        "searches globally on the slim local server (no daemon "
                        "thread to anchor to). 'thread:<uuid>' = a specific "
                        "thread; 'project:<uuid>' = a specific project; "
                        "'global' = all episodes."
                    ),
                },
            },
            "required": ["query"],
        },
    ),
    types.Tool(
        name="remember_fact",
        description="Store or update a key-value fact (dotted keys like 'user.name'). Upserts on key.",
        inputSchema={
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Dotted key, e.g. 'user.name'"},
                "value": {"type": "string"},
                "confidence": {"type": "number", "minimum": 0, "maximum": 1, "default": 1.0},
                "source": {"type": "string"},
            },
            "required": ["key", "value"],
        },
    ),
    types.Tool(
        name="reflect",
        description="Write a self-note: a lesson, pattern, or preference. Use sparingly.",
        inputSchema={
            "type": "object",
            "properties": {
                "note": {"type": "string"},
                "tag": {"type": "string",
                        "enum": ["behavior", "preference", "mistake", "insight", "decision_graph"]},
                "weight": {"type": "number", "minimum": 0, "maximum": 2, "default": 1.0},
                "failure_class": {
                    "type": "string",
                    "description": (
                        "Optional free-text label for the reasoning failure mode "
                        "(e.g. 'shallow_evidence_assertion', "
                        "'unverified_third_party_handoff', "
                        "'surface_pattern_match_skipped_body'). Distinct from "
                        "`tag` (surface category) — `failure_class` names the "
                        "cognitive step that broke so memory_audit can cluster "
                        "cross-domain bridges. Set on mistake-class reflections; "
                        "leave NULL for routine notes."
                    ),
                },
            },
            "required": ["note"],
        },
    ),
    types.Tool(
        name="write_episode",
        description=(
            "Log a deliberate event episode (role='event'). Use for significant "
            "milestones: PR merged, bug found, decision made, task completed. "
            "summary= is what semantic search will match on; content= is the full "
            "detail. Tied to the current thread automatically."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": "Short headline (1-2 sentences). This is what semantic search matches on. Be specific: include PR numbers, symbol names, timestamps, etc.",
                },
                "content": {
                    "type": "string",
                    "description": "Full detail of the event. What happened, why it matters, key values.",
                },
                "metadata": {
                    "type": "object",
                    "description": "Optional structured tags, e.g. {\"pr\": 210, \"kind\": \"merge\"}.",
                },
            },
            "required": ["summary", "content"],
        },
    ),
]

#: name → wrapper. Dispatch table for ``tools/call``.
_DISPATCH: dict[str, Callable[..., dict]] = {
    "recall_fact": _recall_fact,
    "recall_facts": _recall_facts,
    "recall_reflections": _recall_reflections,
    "recall_episodes": _recall_episodes,
    "remember_fact": _remember_fact,
    "reflect": _reflect,
    "write_episode": _write_episode,
}

#: Tools pinned to eager-load via ``anthropic/alwaysLoad`` — the seven memory
#: tools ONLY. The toolspace tools added below are normal (deferred-load) tools:
#: they cost a one-time ToolSearch schema fetch on first use, which is fine for a
#: cold, occasional surface (install/search) — unlike the constantly-hot memory
#: path. Computed from the memory ``_DISPATCH`` BEFORE the toolspace tools are
#: registered, so extending the dispatch never accidentally pins them.
ALWAYS_LOAD_TOOLS: frozenset[str] = frozenset(_DISPATCH)


# ---------------------------------------------------------------------------
# Toolspace tools (PLAN.md §4 / P3-WIRE) — the install-manifest loader surface.
# ---------------------------------------------------------------------------
# Thin model-facing wrappers over the localized install-manifest loader
# (:mod:`local_yep.toolspace.loader`) + the discovery/UX layer
# (:mod:`local_yep.toolspace.discovery`). These let an interactive session
# DISCOVER, INSTALL, CALL and UNINSTALL pre-built tools/packs — WITHOUT pulling
# the cloud build's ~150-tool registry. Both modules are imported LAZILY inside
# each wrapper so the hot memory path (and `tools/list`) never imports them, and
# so the durable-index rehydrate on `loader` import is paid only when a toolspace
# tool is actually used.


def _list_installed_tool() -> dict:
    """List locally installed tools (from the durable install index)."""
    from local_yep.toolspace import loader as _loader

    return {"ok": True, "tools": _loader.list_installed()}


def _tool_search(query: str = "", include_registry: bool = True,
                 limit: int = 20) -> dict:
    """Search the local installed index + the toolspace registry, ranked."""
    from local_yep.toolspace import discovery as _disc

    return _disc.tool_search(query, include_registry=include_registry, limit=limit)


def _install_tool(url: Optional[str] = None, doc: Optional[dict] = None) -> dict:
    """Install a tool from a manifest URL or inline manifest doc.

    Free/public manifests install with no entitlement check and no auth header. A
    premium manifest with no usable entitlement returns a ``purchase_required``
    RESULT (price + estimate) rather than an error (T4.12). A code-fetching
    install needs an interactive local TTY confirm; a headless call fails closed.
    """
    from local_yep.toolspace import discovery as _disc

    if (url is None) == (doc is None):
        raise ValueError("provide exactly one of `url` or `doc`")
    # No `confirm` is threaded from the wire: a code-fetching install proves
    # approval only via the loader's LOCAL TTY confirm (headless fails closed).
    return _disc.install_tool(url if url is not None else doc)


def _call_tool_action(tool_id: str, action: str, params: Optional[dict] = None,
                      timeout: Optional[int] = None,
                      env: Optional[dict] = None) -> dict:
    """Invoke an action on an installed tool (local subprocess)."""
    from local_yep.toolspace import loader as _loader

    return _loader.call(tool_id, action, params=params or {},
                        timeout=timeout, env=env)


def _uninstall_tool(tool_id: str) -> dict:
    """Uninstall a tool: drop it from the index + remove its on-disk artifacts."""
    from local_yep.toolspace import loader as _loader

    return {"ok": True, **_loader.uninstall(tool_id)}


def _list_presets() -> dict:
    """List the selectable voice presets (bundled + toolspace-installed)."""
    from local_yep import presets as _presets

    out = []
    for pid in _presets.list_presets():
        try:
            p = _presets.load_preset(pid)
            out.append({"id": p.id, "display_name": p.display_name,
                        "description": p.description, "paid": p.paid})
        except Exception:  # noqa: BLE001 — a broken preset must not break the list
            out.append({"id": pid})
    return {"ok": True, "presets": out}


def _install_preset_pack(url: Optional[str] = None, doc: Optional[dict] = None) -> dict:
    """Install a personality preset pack from a manifest URL or inline doc.

    A FREE (bundled) preset pack installs into ``~/.local-yep/presets/<id>/`` and
    becomes immediately selectable in ``agent.toml`` + the identity wizard. A
    premium pack with no usable entitlement returns a ``purchase_required`` RESULT
    (price + estimate), installing nothing. The frozen spine is never touched.
    """
    from local_yep.toolspace import packs as _packs

    if (url is None) == (doc is None):
        raise ValueError("provide exactly one of `url` or `doc`")
    return _packs.install_preset_pack(url if url is not None else doc)


_TOOLSPACE_TOOLS: list[types.Tool] = [
    types.Tool(
        name="list_installed",
        description="List locally installed toolspace tools (from the durable install index).",
        inputSchema={"type": "object", "properties": {}},
    ),
    types.Tool(
        name="tool_search",
        description=(
            "Search for installable tools/packs across the local installed index "
            "and the toolspace registry, ranked by lexical match (name/description/"
            "tags). Returns installed + installable results."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search terms; empty returns all."},
                "include_registry": {
                    "type": "boolean", "default": True,
                    "description": "Also search the remote toolspace registry (discovery-only, no auth).",
                },
                "limit": {"type": "integer", "default": 20},
            },
        },
    ),
    types.Tool(
        name="install_tool",
        description=(
            "Install a tool from a manifest URL or inline manifest doc. Free tools "
            "install directly; a premium tool with no entitlement returns a "
            "purchase-required result (with price), not an error. Code-fetching "
            "installs require an interactive local confirmation."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Manifest URL to fetch + install."},
                "doc": {"type": "object", "description": "Inline manifest document."},
            },
        },
    ),
    types.Tool(
        name="call_tool",
        description="Invoke an action on an installed tool (runs as a local subprocess).",
        inputSchema={
            "type": "object",
            "properties": {
                "tool_id": {"type": "string"},
                "action": {"type": "string"},
                "params": {"type": "object", "description": "Action inputs."},
                "timeout": {"type": "integer", "description": "Per-call timeout (seconds)."},
                "env": {"type": "object", "description": "Extra env vars for the child."},
            },
            "required": ["tool_id", "action"],
        },
    ),
    types.Tool(
        name="uninstall_tool",
        description="Uninstall a tool: drop it from the index and remove its on-disk artifacts.",
        inputSchema={
            "type": "object",
            "properties": {"tool_id": {"type": "string"}},
            "required": ["tool_id"],
        },
    ),
    types.Tool(
        name="list_presets",
        description=(
            "List the selectable voice presets (bundled + toolspace-installed). "
            "Each is a legal `agent.toml` preset value and a wizard choice."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    types.Tool(
        name="install_preset_pack",
        description=(
            "Install a personality preset pack from a manifest URL or inline doc. "
            "Free (bundled) packs install into ~/.local-yep/presets/<id>/ and "
            "become immediately selectable; a premium pack with no entitlement "
            "returns a purchase-required result (price), installing nothing. Never "
            "touches the frozen spine."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Preset-pack manifest URL."},
                "doc": {"type": "object", "description": "Inline preset-pack manifest."},
            },
        },
    ),
]

#: name → wrapper for the toolspace tools.
_TOOLSPACE_DISPATCH: dict[str, Callable[..., dict]] = {
    "list_installed": _list_installed_tool,
    "tool_search": _tool_search,
    "install_tool": _install_tool,
    "call_tool": _call_tool_action,
    "uninstall_tool": _uninstall_tool,
    "list_presets": _list_presets,
    "install_preset_pack": _install_preset_pack,
}

#: The full model-facing surface: the seven memory tools + the toolspace tools.
_ALL_DISPATCH: dict[str, Callable[..., dict]] = {**_DISPATCH, **_TOOLSPACE_DISPATCH}


def all_tools() -> list[types.Tool]:
    """The full tool list served by ``tools/list``: the seven memory tools
    (pinned ``alwaysLoad``) + the toolspace tools (normal deferred-load).

    Pure + side-effect-free apart from the in-place alwaysLoad tag, so a test can
    assert the surface without standing up a server. Tagging only marks tools in
    :data:`ALWAYS_LOAD_TOOLS` (the memory seven), leaving the toolspace tools
    un-pinned."""
    tools = _TOOLS + _TOOLSPACE_TOOLS
    try:
        _mark_always_load(tools)
    except Exception:  # noqa: BLE001 — never break the surface over a pin
        pass
    return tools


# ---------------------------------------------------------------------------
# alwaysLoad pin — ported from the source ide_mcp.py.
# ---------------------------------------------------------------------------
def _mark_always_load(tools, names=ALWAYS_LOAD_TOOLS) -> int:
    """Set ``anthropic/alwaysLoad`` on every Tool whose name is in ``names``.

    Mutates each matching ``mcp.types.Tool`` in place (sets ``.meta``, which
    serializes as ``_meta``) and returns how many were marked. Pure aside from
    the in-place tag, so it's unit-testable without standing up a server.
    """
    marked = 0
    for t in tools:
        if t.name in names:
            meta = dict(t.meta or {})
            meta["anthropic/alwaysLoad"] = True
            t.meta = meta
            marked += 1
    return marked


def build_memory_server() -> Server:
    """Return the slim ``mcp.server.Server``.

    Registers the seven memory tools (pinned ``alwaysLoad``) PLUS the toolspace
    install-manifest tools (``list_installed`` / ``tool_search`` / ``install_tool``
    / ``call_tool`` / ``uninstall_tool``, normal deferred-load) on a raw low-level
    MCP server — NOT the full cloud ``build_yep_server`` registry. A ``tools/list``
    handler returns the combined Tool objects (memory tools carrying the
    ``anthropic/alwaysLoad`` hint), and a ``tools/call`` handler dispatches through
    :data:`_ALL_DISPATCH`. The build itself is pure + side-effect-free (no DB, no
    network, no stdio) so it's unit-testable and the ``initialize`` handshake never
    blocks.
    """
    from local_yep import __version__ as _ver

    server: Server = Server("yep_tools", version=_ver)

    @server.list_tools()
    async def _list_tools() -> list[types.Tool]:
        # The combined surface; alwaysLoad is pinned on the memory seven only.
        # Tagging must never break tools/list (which would hide the whole
        # surface), so `all_tools` swallows any pin error internally.
        return all_tools()

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict) -> types.CallToolResult:
        fn = _ALL_DISPATCH.get(name)
        if fn is None:
            return _err(ValueError(f"unknown tool: {name!r}"))
        try:
            return _ok(fn(**(arguments or {})))
        except Exception as e:  # noqa: BLE001 — a failing tool is a tool error
            return _err(e)

    return server


async def serve() -> None:
    """Serve the slim memory tools over stdio until the client disconnects.

    The server is built BEFORE any DB I/O (the build is pure), so the
    ``initialize`` handshake never blocks — Claude Code kills an MCP server
    that doesn't answer ``initialize`` within 30s. The local SQLite store is
    touched lazily, only inside a tool handler, so a cold DB can't gate the
    handshake. No daemon, no agent-session registration, no network.
    """
    server = build_memory_server()

    # Activate the optional local embedder (fastembed) if installed. This is a
    # long-lived process, so the model warms once and stays warm — turning on
    # semantic (cosine) recall for the recall_* tools. Cheap + non-blocking:
    # registration only; the model loads lazily on the first embed() (after the
    # initialize handshake). A missing extra is a silent no-op (BM25-only).
    try:
        from local_yep.memory import activate_embeddings

        activate_embeddings()
    except Exception:
        pass

    init_options = server.create_initialization_options()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)


def main() -> None:
    anyio.run(serve)


if __name__ == "__main__":
    main()
