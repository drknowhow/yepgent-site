"""Local Yep MCP surface.

Phase-1 ships a single slim, memory-only stdio server
(:mod:`local_yep.mcp.server`) exposing the seven canonical memory tools.

Note: this package is named ``mcp`` but does NOT shadow the installed
``mcp`` SDK — Python 3 uses absolute imports by default, so ``from mcp import
types`` inside :mod:`local_yep.mcp.server` resolves to the top-level installed
``mcp`` library, not this sibling package.
"""
