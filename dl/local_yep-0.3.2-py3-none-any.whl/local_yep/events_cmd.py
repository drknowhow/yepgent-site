"""``yepgent events`` — read the activity ledger (PLAN §8 T8.4).

The reader that five write-only sinks never had. Offline, paste-safe, and
scriptable:

    yepgent events                       # last 24h, newest first
    yepgent events --since 7d --json     # machine-readable, for a bug report
    yepgent events --category guard      # just the enforcement gate
    yepgent events --severity warn       # warnings and errors only
    yepgent events prune --keep-days 30
    yepgent events mute --for 2h
    yepgent events unmute
    yepgent events status

``--json`` output is the intended attachment for a bug report. At alpha scale
that is strictly better information than anonymous aggregates would be, and it
costs no server, no privacy policy, and no trust.

**Muting silences delivery, never the record.** ``mute`` changes what a channel
is allowed to send; every event keeps landing here, tagged with why it was not
delivered, and ``status`` reports the backlog.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone

from local_yep import events

_SEV_MARK = {"debug": "·", "info": " ", "warn": "!", "error": "✗"}


def _fmt_row(row: dict, *, width: int = 100) -> str:
    ts = str(row.get("ts_utc") or "")[:19].replace("T", " ")
    sev = str(row.get("severity") or "info")
    mark = _SEV_MARK.get(sev, " ")
    project = str(row.get("project") or "")
    event = str(row.get("event") or "")
    title = str(row.get("title") or "")
    head = f"{mark} {ts}  {event:<22}"
    if project:
        head += f" [{project}]"
    line = f"{head}  {title}"
    if len(line) > width:
        line = line[: width - 1] + "…"
    if row.get("suppressed_reason"):
        line += f"   ({row['suppressed_reason']})"
    return line


def _cmd_list(args: argparse.Namespace) -> int:
    rows = events.query(
        since=args.since,
        project=args.project,
        category=args.category,
        severity=args.severity,
        event=args.event,
        limit=args.tail,
    )
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
        return 0
    if not rows:
        window = args.since or "all time"
        print(f"No events in {window}.")
        print(f"Ledger: {events.events_db_path()}")
        return 0
    for row in reversed(rows):  # oldest first reads better in a terminal
        print(_fmt_row(row))
    reason = events.mute_reason()
    if reason:
        print(f"\nNote: notifications are {reason}. "
              "The record above was kept regardless.")
    return 0


def _cmd_prune(args: argparse.Namespace) -> int:
    removed = events.prune(args.keep_days)
    print(f"Pruned {removed} event(s) older than {args.keep_days} day(s).")
    return 0


def _cmd_status(args: argparse.Namespace) -> int:
    st = events.stats()
    print(f"Ledger:     {st['path']}")
    print(f"Events:     {st['total']}")
    if st["oldest"]:
        print(f"Range:      {st['oldest']} .. {st['newest']}")
    reason = events.mute_reason()
    print(f"Delivery:   {reason if reason else 'not muted'}")
    if st["suppressed"]:
        print(f"Suppressed: {st['suppressed']} event(s) recorded while muted")
    counts = events.counts_by_category(since="7d")
    if counts:
        print("\nLast 7 days by category:")
        for cat, n in counts:
            print(f"  {cat:<16} {n}")
    return 0


def _cmd_mute(args: argparse.Namespace) -> int:
    if args.forever:
        events.mute(None)
        print("Notification delivery muted indefinitely.")
    else:
        spec = args.for_ or "2h"
        delta = _parse_duration(spec)
        if delta is None:
            print(f"Could not read a duration from {spec!r} "
                  "(try 30m, 2h, 1d).", file=sys.stderr)
            return 2
        until = datetime.now(timezone.utc) + delta
        events.mute(until.isoformat(timespec="seconds"))
        print(f"Notification delivery muted until "
              f"{until.isoformat(timespec='seconds')}.")
    print("The activity ledger keeps recording. "
          "Run `yepgent events` any time to see what you missed.")
    return 0


def _cmd_unmute(args: argparse.Namespace) -> int:
    was = events.mute_reason()
    if not was:
        print("Delivery was not muted.")
        return 0
    # Digest first, then lift: the user should learn what they missed in the
    # same breath as being told the mute is gone.
    missed = events.suppressed_since(None)
    events.unmute()
    print("Notification delivery resumed.")
    if missed:
        by_cat: dict[str, int] = {}
        for row in missed:
            by_cat[row["category"]] = by_cat.get(row["category"], 0) + 1
        summary = ", ".join(f"{n} {c}" for c, n in sorted(
            by_cat.items(), key=lambda kv: -kv[1]))
        print(f"While muted: {summary}. See `yepgent events`.")
    return 0


def _parse_duration(spec: str) -> timedelta | None:
    s = (spec or "").strip().lower()
    units = {"m": "minutes", "h": "hours", "d": "days", "w": "weeks"}
    if len(s) >= 2 and s[-1] in units and s[:-1].replace(".", "", 1).isdigit():
        try:
            return timedelta(**{units[s[-1]]: float(s[:-1])})
        except ValueError:
            return None
    return None


def build_parser(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Attach the ``events`` verbs to an existing parser."""
    parser.add_argument("--since", default="24h",
                        help="window, e.g. 30m / 24h / 7d (default: 24h)")
    parser.add_argument("--project", default=None, help="filter by project name")
    parser.add_argument("--category", default=None,
                        help="session | guard | permission | task | subagent | …")
    parser.add_argument("--severity", default=None,
                        choices=list(events.SEVERITIES),
                        help="minimum severity")
    parser.add_argument("--event", default=None, help="exact event name")
    parser.add_argument("--tail", type=int, default=100,
                        help="max rows (default: 100)")
    parser.add_argument("--json", action="store_true",
                        help="machine-readable output (attach this to bug reports)")
    parser.set_defaults(_events_func=_cmd_list)

    sub = parser.add_subparsers(dest="events_action", metavar="<action>")

    p_prune = sub.add_parser("prune", help="delete old events")
    p_prune.add_argument("--keep-days", type=int, default=events.DEFAULT_KEEP_DAYS)
    p_prune.set_defaults(_events_func=_cmd_prune)

    p_status = sub.add_parser("status", help="ledger + mute summary")
    p_status.set_defaults(_events_func=_cmd_status)

    p_mute = sub.add_parser("mute", help="silence DELIVERY (never the record)")
    p_mute.add_argument("--for", dest="for_", default="2h",
                        help="duration, e.g. 30m / 2h / 1d (default: 2h)")
    p_mute.add_argument("--forever", action="store_true")
    p_mute.set_defaults(_events_func=_cmd_mute)

    p_unmute = sub.add_parser("unmute", help="resume delivery + show what was missed")
    p_unmute.set_defaults(_events_func=_cmd_unmute)

    return parser


def main(args: argparse.Namespace) -> int:
    func = getattr(args, "_events_func", None)
    if func is None:
        func = _cmd_list
    try:
        return int(func(args) or 0)
    except Exception as exc:  # noqa: BLE001 - a reader must not traceback at a user
        print(f"events: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
