"""``yepgent doctor`` — one-shot local health report (and the alpha feedback
channel).

Prints a plain-text (or ``--json``) diagnosis of the install: package/home
versions, this repo's hook + MCP wiring, PATH resolution for the console
scripts, memory-DB stats, the last recorded hook failure, integrity, and
activation. Read-only and offline: it never mutates state, never phones home,
and never prints memory *content* or secret values — counts and metadata only,
so the output is safe to paste into a bug report.

Every check is individually defensive: a broken subsystem downgrades to a
FAIL/WARN line, never a traceback.
"""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

from local_yep import __version__


@dataclass
class Check:
    status: str  # "ok" | "warn" | "fail" | "info"
    label: str
    detail: str


def _home() -> Path:
    return Path(os.path.expanduser("~")) / ".local-yep"


# --------------------------------------------------------------------------- #
# Individual checks
# --------------------------------------------------------------------------- #

def _check_package() -> list[Check]:
    py = f"python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    return [Check("info", "package", f"local-yep {__version__} on {py} ({sys.platform})")]


def _check_home() -> list[Check]:
    out: list[Check] = []
    home = _home()
    if not home.is_dir():
        return [Check("fail", "home", f"{home} missing — run `yepgent init` (or `gent`) once")]
    out.append(Check("ok", "home", str(home)))

    marker = home / "version"
    try:
        stamped = marker.read_text(encoding="utf-8").strip() if marker.is_file() else ""
    except OSError:
        stamped = ""
    if stamped and stamped != __version__:
        out.append(Check(
            "warn", "home.version",
            f"home stamped {stamped}, package is {__version__} — run `yepgent upgrade` "
            "in your repos to refresh wiring",
        ))
    else:
        out.append(Check("ok", "home.version", stamped or "(unstamped)"))

    agent = home / "agent.toml"
    configured = False
    try:
        configured = agent.is_file() and agent.stat().st_size > 0
    except OSError:
        pass
    out.append(
        Check("ok", "identity", "agent.toml configured")
        if configured
        else Check("warn", "identity", "agent.toml empty — run `yepgent onboard` to personalize")
    )
    return out


def _check_repo_wiring(repo: Path) -> list[Check]:
    """Hook/MCP/managed-block wiring of the CURRENT directory's repo."""
    from local_yep import installer

    out: list[Check] = []
    settings = repo / ".claude" / "settings.json"
    if not settings.is_file():
        return [Check(
            "info", "repo",
            f"no Local Yep wiring in {repo} (no .claude/settings.json) — "
            "this is fine for `gent`-launched sessions, which carry their own profile",
        )]

    try:
        data = json.loads(settings.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return [Check("fail", "repo.hooks", f"{settings} unreadable/unparseable")]

    hooks = data.get("hooks") if isinstance(data, dict) else None
    hooks = hooks if isinstance(hooks, dict) else {}

    def _has_ours(event: str) -> bool:
        for group in hooks.get(event, []) or []:
            if not isinstance(group, dict):
                continue
            for h in group.get("hooks", []) or []:
                if isinstance(h, dict) and installer._HOOK_TAG in str(h.get("command", "")):
                    return True
        return False

    missing = [e for e in installer.HOOK_EVENTS if not _has_ours(e)]
    if not missing:
        out.append(Check("ok", "repo.hooks", f"all {len(installer.HOOK_EVENTS)} events wired"))
    elif len(missing) == len(installer.HOOK_EVENTS):
        out.append(Check("info", "repo.hooks", "no yepgent hooks in this repo"))
    else:
        out.append(Check(
            "warn", "repo.hooks",
            f"missing events: {', '.join(missing)} — re-run `yepgent init` here "
            "(new package versions add hook events; wiring does not auto-upgrade)",
        ))

    mcp = repo / ".mcp.json"
    try:
        mdata = json.loads(mcp.read_text(encoding="utf-8")) if mcp.is_file() else {}
    except (OSError, ValueError):
        mdata = {}
    entry = (mdata.get("mcpServers") or {}).get(installer.MCP_SERVER_KEY) if isinstance(mdata, dict) else None
    if not isinstance(entry, dict):
        out.append(Check("info", "repo.mcp", "no yepgent MCP entry in this repo"))
    else:
        cmd = str(entry.get("command", ""))
        if cmd and cmd not in ("python", "python3") and not Path(cmd).exists():
            out.append(Check(
                "fail", "repo.mcp",
                f"MCP interpreter no longer exists: {cmd} — re-run `yepgent init` "
                "(interpreter moved, e.g. pipx reinstall/python upgrade)",
            ))
        else:
            out.append(Check("ok", "repo.mcp", "yepgent MCP entry present"))

    fenced = False
    claude_md = repo / "CLAUDE.md"
    try:
        fenced = claude_md.is_file() and "YEP:BEGIN" in claude_md.read_text(encoding="utf-8")
    except OSError:
        pass
    out.append(Check("ok" if fenced else "info", "repo.managed-block",
                     "present" if fenced else "absent"))
    return out


def _check_path() -> list[Check]:
    out: list[Check] = []
    for script in ("yepgent-hook", "gent", "yepgent"):
        where = shutil.which(script)
        if where:
            out.append(Check("ok", f"path.{script}", where))
        else:
            sev = "fail" if script == "yepgent-hook" else "warn"
            out.append(Check(
                sev, f"path.{script}",
                "not on PATH — hooks wired as bare commands will not fire "
                "(GUI-launched Claude Code often has a minimal PATH); "
                "`pipx ensurepath` then restart, or re-run `yepgent init`",
            ))
    return out


def _check_memory_db() -> list[Check]:
    out: list[Check] = []
    db = _home() / "memory.db"
    if not db.is_file():
        return [Check("warn", "memory.db", "missing — created on first use")]

    size_kb = 0
    try:
        size_kb = db.stat().st_size // 1024
    except OSError:
        pass

    try:
        con = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=2)
    except sqlite3.Error as exc:
        return [Check("fail", "memory.db", f"cannot open ({exc})")]

    try:
        counts = {}
        unembedded = {}
        for tbl in ("facts", "episodes", "reflections"):
            try:
                counts[tbl] = con.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
                unembedded[tbl] = con.execute(
                    f"SELECT COUNT(*) FROM {tbl} WHERE embedding IS NULL"
                ).fetchone()[0]
            except sqlite3.Error:
                counts[tbl] = "?"
        try:
            journal = con.execute("PRAGMA journal_mode").fetchone()[0]
        except sqlite3.Error:
            journal = "?"
        try:
            row = con.execute(
                "SELECT value FROM meta WHERE key = 'schema_version'"
            ).fetchone()
            schema_v = row[0] if row else "?"
        except sqlite3.Error:
            schema_v = "?"
    finally:
        con.close()

    out.append(Check(
        "ok", "memory.db",
        f"{size_kb} KB · schema v{schema_v} · journal={journal} · "
        + " ".join(f"{t}={counts.get(t)}" for t in ("facts", "episodes", "reflections")),
    ))

    pending = {t: n for t, n in unembedded.items() if isinstance(n, int) and n > 0}
    total_rows = sum(n for n in counts.values() if isinstance(n, int))
    if pending and total_rows:
        out.append(Check(
            "info", "memory.embeddings",
            " ".join(f"{t}:{n}" for t, n in pending.items())
            + " rows without vectors — semantic recall skips them; "
              "run `yepgent memory reindex` after installing local-yep[embeddings]",
        ))
    return out


def _check_last_hook_error() -> list[Check]:
    crumb = _home() / "last_hook_error.json"
    if not crumb.is_file():
        return [Check("ok", "hooks.last-error", "none recorded")]
    try:
        doc = json.loads(crumb.read_text(encoding="utf-8"))
        return [Check(
            "warn", "hooks.last-error",
            f"{doc.get('hook', '?')} failed at {doc.get('at', '?')}: {doc.get('reason', '?')} "
            "— that turn ran without its <memory> block",
        )]
    except (OSError, ValueError):
        return [Check("warn", "hooks.last-error", f"{crumb} present but unreadable")]


def _check_integrity() -> list[Check]:
    try:
        from local_yep import integrity

        res = integrity.check()
    except Exception as exc:  # defensive: doctor must never crash
        return [Check("fail", "integrity", f"verifier error: {type(exc).__name__}: {exc}")]
    if res.ok:
        return [Check("ok", "integrity", "signed manifest verified")]
    return [Check(
        "fail", "integrity",
        "; ".join(res.failures[:3])
        + " — if you did not modify these files, an antivirus or sync tool may "
          "have; `pipx reinstall local-yep` restores them",
    )]


def _check_activation() -> list[Check]:
    try:
        from local_yep import activation

        res = activation.check()
    except Exception as exc:
        return [Check("warn", "activation", f"check error: {type(exc).__name__}: {exc}")]
    required = getattr(res, "required", False)
    ok = getattr(res, "ok", True)
    state = getattr(res, "state", "") or ""
    message = getattr(res, "message", "") or ""
    if not required:
        return [Check("ok", "activation", "not required (free core)")]
    if ok:
        return [Check("ok", "activation", state or "active")]
    return [Check("fail", "activation", message or state or "required and not satisfied")]


def _check_audit_log() -> list[Check]:
    log = _home() / "audit.log"
    if not log.is_file():
        return [Check("info", "audit.log", "empty (no denied/audited tool calls yet)")]
    try:
        size = log.stat().st_size
        last = ""
        with open(log, "rb") as fh:
            tail = fh.read()[-4096:]
        lines = tail.decode("utf-8", "replace").strip().splitlines()
        if lines:
            last = lines[-1]
        return [Check("info", "audit.log", f"{size} bytes · last: {last[:160]}")]
    except OSError:
        return [Check("info", "audit.log", "present")]


def _check_events() -> list[Check]:
    """Activity ledger summary (PLAN §8) — history, not just a moment.

    This is what makes a bug report actionable: ``yepgent events --since 7d
    --json`` carries what actually happened, from the user's own machine, with
    nothing collected by anyone.
    """
    try:
        from local_yep import events
    except Exception as exc:  # pragma: no cover - defensive
        return [Check("warn", "events", f"ledger unavailable ({exc})")]

    st = events.stats()
    out: list[Check] = []
    if not st["total"]:
        out.append(Check("info", "events", "ledger empty (populated as you work)"))
    else:
        out.append(Check(
            "ok", "events",
            f"{st['total']} event(s) · {st['oldest'][:10]}..{st['newest'][:10]}",
        ))
        recent = events.counts_by_category(since="7d")
        if recent:
            summary = ", ".join(f"{cat} {n}" for cat, n in recent[:5])
            out.append(Check("info", "events.7d", summary))

    reason = events.mute_reason()
    if reason:
        note = reason
        if st["suppressed"]:
            note += f" · {st['suppressed']} event(s) recorded while muted"
        out.append(Check("info", "events.delivery", note))
    return out


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #

def run(*, as_json: bool = False, repo: Path | None = None) -> int:
    """Run every check and print the report. Returns 1 if any check FAILed."""
    repo = repo or Path.cwd()
    checks: list[Check] = []
    for fn in (
        _check_package,
        _check_home,
        lambda: _check_repo_wiring(repo),
        _check_path,
        _check_memory_db,
        _check_last_hook_error,
        _check_integrity,
        _check_activation,
        _check_audit_log,
        _check_events,
    ):
        try:
            checks.extend(fn())
        except Exception as exc:  # a check must never take doctor down
            checks.append(Check("fail", "doctor", f"internal check error: {type(exc).__name__}: {exc}"))

    if as_json:
        print(json.dumps([asdict(c) for c in checks], indent=2))
    else:
        icons = {"ok": "OK  ", "warn": "WARN", "fail": "FAIL", "info": "--  "}
        for c in checks:
            print(f"[{icons.get(c.status, '??  ')}] {c.label}: {c.detail}")
        fails = [c for c in checks if c.status == "fail"]
        warns = [c for c in checks if c.status == "warn"]
        print(f"\n{len(fails)} failure(s), {len(warns)} warning(s). "
              "Paste this output into a bug report — it contains no memory content or secrets.")
    return 1 if any(c.status == "fail" for c in checks) else 0
