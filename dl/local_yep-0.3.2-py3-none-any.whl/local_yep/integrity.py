"""System-integrity verification — tamper-evident, fail-closed (product guard).

Local Yep is a product: the frozen ethical spine, the operative behaviors, the
tool recipes, and the authored preset voices define *what the agent is*. This
module verifies, at every launch and every session start, that those bundled
"system" files have not been modified, and refuses to operate if they have.

Trust model (stated honestly — see also PLAN R2 / Rule 1):

* The check is **tamper-evident and fail-closed**, NOT tamper-proof. It runs on
  the user's own machine, so a determined user with code access can ultimately
  patch the verifier out — the universal client-side limit.
* What it stops cleanly: casual/accidental edits, and "just edit a system file
  to change the rules / re-hash the manifest." The manifest is **signed**
  (Ed25519); forging it requires the private key, which never ships. The trust
  root — the public key — is embedded in *code* here (:data:`PUBKEY_HEX`), so
  swapping it is itself a code patch, not a data edit.

How it works: a signed ``_integrity/manifest.json`` maps each protected file to
its SHA-256. At runtime we (1) verify the manifest's signature against the
embedded public key (dependency-free :mod:`local_yep._ed25519`), then (2) hash
each listed file and compare. Any failure ⇒ not intact. The launcher refuses to
start and the SessionStart hook withholds identity and shows a restart notice.
"""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import NamedTuple, Optional

from local_yep import _ed25519

#: Trust root: the hex Ed25519 PUBLIC key the release manifest is signed under.
#: Embedded in code on purpose — replacing it is a code patch (the accepted
#: client-side limit), not a mere data edit. Set by ``integrity_tool.py keygen``.
PUBKEY_HEX: str = "bda40c0f990f177514cc063bfba74c9eb4915d1f5067c5c5cf94cc8e9a1623d5"

INTEGRITY_DIRNAME = "_integrity"
MANIFEST_NAME = "manifest.json"
SIG_NAME = "manifest.sig"
MANIFEST_VERSION = "1"

#: Fixed protected files (package-relative, POSIX). Presets are discovered
#: dynamically below so adding a preset only requires a re-sign.
_FIXED_PROTECTED = (
    "identity/spine.md",
    "templates/behaviors.md",
    "templates/tool_recipes.md",
)


class IntegrityResult(NamedTuple):
    ok: bool
    failures: tuple[str, ...]


class IntegrityError(RuntimeError):
    """Raised by :func:`assert_intact` when the system files are not intact."""


def package_root() -> Path:
    """Absolute path to the installed ``local_yep`` package directory."""
    return Path(__file__).resolve().parent


def protected_files(root: Optional[Path] = None) -> list[str]:
    """The package-relative POSIX paths the manifest covers (sorted, unique).

    Used by the signing tool to BUILD the manifest. Runtime verification trusts
    the (signed) manifest's own file list, not this enumeration.
    """
    root = root or package_root()
    rels: set[str] = set()
    for rel in _FIXED_PROTECTED:
        if (root / rel).is_file():
            rels.add(rel)
    presets = root / "presets"
    if presets.is_dir():
        # Cover the full authored surface of every bundled preset: the .toml
        # configs AND the voice/sample prose that is injected into identity
        # verbatim (an unsigned voice.md would be the easy identity swap).
        for pattern in ("*.toml", "voice.md", "sample.txt"):
            for f in presets.rglob(pattern):
                if f.is_file():
                    rels.add(f.relative_to(root).as_posix())
    return sorted(rels)


def _sha256_file(path: Path) -> str:
    # Hash newline-normalized bytes so the check is stable across line-ending
    # conversion (git autocrlf, cross-OS checkouts, wheel builds). Every
    # protected file is text; a pure CRLF/LF change is not meaningful tampering.
    data = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return hashlib.sha256(data).hexdigest()


def build_manifest(root: Optional[Path] = None) -> bytes:
    """Serialize the canonical manifest bytes (what gets signed and verified)."""
    root = root or package_root()
    files = {rel: _sha256_file(root / rel) for rel in protected_files(root)}
    doc = {"version": MANIFEST_VERSION, "algo": "sha256", "files": files}
    return (json.dumps(doc, indent=2, sort_keys=True) + "\n").encode("utf-8")


def verify(
    root: Optional[Path] = None,
    *,
    manifest_bytes: Optional[bytes] = None,
    sig_hex: Optional[str] = None,
    pubkey_hex: Optional[str] = None,
) -> IntegrityResult:
    """Verify the signed manifest and every file it covers. Never raises.

    Returns ``IntegrityResult(ok, failures)``. ``ok`` is True only when the
    manifest signature verifies AND every listed file is present and unchanged.
    The keyword args are seams for tests; production reads the bundled files.
    """
    root = root or package_root()
    idir = root / INTEGRITY_DIRNAME

    if manifest_bytes is None:
        mp = idir / MANIFEST_NAME
        if not mp.is_file():
            return IntegrityResult(False, ("integrity manifest missing",))
        try:
            manifest_bytes = mp.read_bytes()
        except OSError as exc:
            return IntegrityResult(False, (f"manifest unreadable: {exc}",))

    if sig_hex is None:
        sp = idir / SIG_NAME
        if not sp.is_file():
            return IntegrityResult(False, ("integrity signature missing",))
        try:
            sig_hex = sp.read_text(encoding="utf-8").strip()
        except OSError as exc:
            return IntegrityResult(False, (f"signature unreadable: {exc}",))

    pk_hex = pubkey_hex if pubkey_hex is not None else PUBKEY_HEX
    try:
        pubkey = bytes.fromhex(pk_hex)
        sig = bytes.fromhex(sig_hex)
    except ValueError:
        return IntegrityResult(False, ("integrity key/signature malformed",))

    if not _ed25519.verify(pubkey, manifest_bytes, sig):
        return IntegrityResult(
            False, ("manifest signature invalid (forged, corrupted, or unsigned build)",)
        )

    try:
        files = json.loads(manifest_bytes)["files"]
        assert isinstance(files, dict)
    except Exception as exc:  # noqa: BLE001
        return IntegrityResult(False, (f"manifest unreadable: {exc}",))

    failures: list[str] = []
    for rel, expected in sorted(files.items()):
        fp = root / rel
        if not fp.is_file():
            failures.append(f"missing: {rel}")
            continue
        try:
            if _sha256_file(fp) != expected:
                failures.append(f"modified: {rel}")
        except OSError as exc:
            failures.append(f"unreadable: {rel} ({exc})")

    return IntegrityResult(not failures, tuple(failures))


@lru_cache(maxsize=1)
def check() -> IntegrityResult:
    """Process-cached verification of the installed package (fail-closed).

    Any internal error is converted to a not-intact result rather than raised,
    so callers (hook, launcher) get a clean verdict. Cached per process; each
    hook/launcher invocation is a fresh process.
    """
    try:
        return verify()
    except Exception as exc:  # noqa: BLE001 - never let the guard itself throw
        return IntegrityResult(False, (f"integrity check error: {exc}",))


def assert_intact() -> None:
    """Raise :class:`IntegrityError` (with the tamper message) if not intact."""
    result = check()
    if not result.ok:
        raise IntegrityError(tamper_message(result))


def tamper_message(result: IntegrityResult) -> str:
    """The loud, user-facing 'disabled — restore & restart' notice."""
    shown = list(result.failures[:8])
    detail = "\n".join(f"    - {f}" for f in shown) or "    - (unspecified)"
    more = (
        "" if len(result.failures) <= 8
        else f"\n    …and {len(result.failures) - 8} more"
    )
    return (
        "============ LOCAL YEP — INTEGRITY CHECK FAILED ============\n"
        "Protected system files have been modified or are missing, so\n"
        "Local Yep is DISABLED to protect product integrity.\n\n"
        f"Detected:\n{detail}{more}\n\n"
        "To restore and re-enable, then restart your session:\n"
        "    pipx reinstall local-yep\n"
        "    (or: pip install --force-reinstall --no-deps local-yep)\n\n"
        "If you changed these files intentionally, re-sign the manifest with\n"
        "your release key (scripts/integrity_tool.py sign) — silent edits to\n"
        "the system are not permitted.\n"
        "==========================================================="
    )
