"""Guardrail G2 — keep subscription auth interactive; route autonomy to API keys.

Guardrail **G2** (see ``docs/auth-guardrails.md``): a user's Claude *subscription*
(Pro/Max, flat-rate) only ever augments a **live, interactive** session. Any
autonomous / unattended / scheduled / daemon / headless / fan-out / at-scale
path must run on the user's own **API key** (metered) and must **refuse to
start** on subscription-only auth.

This module is the single importable enforcement point for that rule. Two
surfaces:

* :func:`enforce_interactive_only` — the *active* gate. Any code path that
  initiates autonomous work MUST call it (declaring ``unattended=True``); it
  raises :class:`SubscriptionAutonomyError` when that work would run on
  subscription-only auth. Local Yep ships **no** autonomous path today (the
  cloud daemon was deliberately dropped in the local port), so nothing in the
  shipped product can violate G2 — this gate exists to keep it that way as
  scheduler / fan-out features land.
* :func:`guardrail_notice` — the *passive* surface. The SessionStart hook calls
  it to surface a visible warning when it detects an unattended run on a
  subscription. A hook cannot abort Claude Code, so it warns rather than blocks,
  and it fires only on explicit unattended markers — never on a bare missing
  TTY, because hook stdin is always a pipe (TTY-absence there is meaningless and
  would nag every interactive user).

Guardrail **G1** is honored throughout: auth mode is inferred from the mere
*presence* of an API-key env var; the credential value is never read, copied,
or logged.
"""

from __future__ import annotations

import os
from typing import Mapping, Optional


# --- Auth mode (G1-safe: presence only, value never read) ------------------

#: Env vars whose presence means "API-key (metered) auth is configured".
AUTH_ENV_VARS = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN")

#: Truthy spellings for the boolean env markers below.
_TRUTHY = {"1", "true", "yes", "on"}

#: Env markers that DECLARE an unattended/autonomous context. Local Yep's own
#: launchers (and any scheduler/daemon we ship) must set ``YEPGENT_UNATTENDED``;
#: common CI markers are recognized opportunistically.
UNATTENDED_MARKERS = (
    "YEPGENT_UNATTENDED",
    "CI",
    "GITHUB_ACTIONS",
    "BUILDKITE",
    "JENKINS_URL",
)

#: Explicit "a human is present" override — forces interactive, silences G2.
INTERACTIVE_OVERRIDE = "YEPGENT_INTERACTIVE"


class SubscriptionAutonomyError(RuntimeError):
    """Raised when autonomous work would run on subscription-only auth (G2)."""


def _env(environ: Optional[Mapping[str, str]]) -> Mapping[str, str]:
    return environ if environ is not None else os.environ


def _truthy(value: Optional[str]) -> bool:
    return bool(value) and value.strip().lower() in _TRUTHY


def is_api_key_auth(environ: Optional[Mapping[str, str]] = None) -> bool:
    """True iff a Claude API key is configured (presence only — guardrail G1).

    Only whether one of :data:`AUTH_ENV_VARS` is set to a non-empty value is
    checked; the credential value itself is never read or logged.
    """
    env = _env(environ)
    return any((env.get(name) or "").strip() for name in AUTH_ENV_VARS)


def auth_mode(environ: Optional[Mapping[str, str]] = None) -> str:
    """``"api_key"`` (metered) or ``"subscription"`` (interactive, flat-rate)."""
    return "api_key" if is_api_key_auth(environ) else "subscription"


def is_unattended(environ: Optional[Mapping[str, str]] = None) -> bool:
    """Best-effort: does an explicit marker declare this an unattended run?

    Resolution order: :data:`INTERACTIVE_OVERRIDE` wins (→ ``False``); else any
    truthy :data:`UNATTENDED_MARKERS` (→ ``True``); else ``False``. A bare
    missing TTY is deliberately NOT treated as unattended — hook subprocesses
    always have a piped (non-TTY) stdin, so TTY-absence is not a reliable
    signal. Autonomous code paths should pass ``unattended=True`` explicitly to
    :func:`enforce_interactive_only` rather than rely on detection.
    """
    env = _env(environ)
    if _truthy(env.get(INTERACTIVE_OVERRIDE)):
        return False
    return any(_truthy(env.get(m)) for m in UNATTENDED_MARKERS)


def _message(operation: str) -> str:
    return (
        f"Guardrail G2: {operation!r} is an autonomous/unattended operation and "
        "may not run on a Claude subscription. Autonomous, scheduled, daemon, "
        "headless, or fan-out work must run on your own Claude API key "
        "(metered). Set ANTHROPIC_API_KEY to run it, or run interactively. "
        "See docs/auth-guardrails.md#billing-rule."
    )


def enforce_interactive_only(
    operation: str,
    *,
    unattended: Optional[bool] = None,
    environ: Optional[Mapping[str, str]] = None,
) -> None:
    """The G2 gate. Raise if autonomous work would run on subscription auth.

    Any code path that initiates autonomous/unattended work MUST call this,
    declaring ``unattended=True``. When ``unattended`` is ``None`` it is detected
    via :func:`is_unattended` (explicit markers only). Raises
    :class:`SubscriptionAutonomyError` iff the run is unattended AND no API key
    is configured. A no-op for interactive sessions and for API-key auth.
    """
    env = _env(environ)
    if unattended is None:
        unattended = is_unattended(env)
    if unattended and not is_api_key_auth(env):
        raise SubscriptionAutonomyError(_message(operation))


def guardrail_notice(
    operation: str = "this session",
    *,
    environ: Optional[Mapping[str, str]] = None,
) -> Optional[str]:
    """Return a visible G2 warning for an unattended subscription run, else None.

    Used by the SessionStart hook, which cannot abort Claude Code and so warns
    rather than blocks. Fires only on explicit unattended markers (never a bare
    missing TTY).
    """
    env = _env(environ)
    if is_unattended(env) and not is_api_key_auth(env):
        return (
            "[Local Yep · guardrail G2] This session looks UNATTENDED (an "
            "autonomous/headless marker is set) while signed in with a Claude "
            "subscription. Per guardrail G2, autonomous / scheduled / daemon / "
            "fan-out work must run on your own Claude API key (metered), not a "
            "subscription — set ANTHROPIC_API_KEY for unattended runs. If a "
            f"human is present, set {INTERACTIVE_OVERRIDE}=1 to silence this. "
            "See docs/auth-guardrails.md#billing-rule."
        )
    return None
