"""``yepgent secrets`` — manage installed tools' locally-stored credentials (T6.4).

Thin CLI over :mod:`local_yep.secrets`. Subcommands::

    yepgent secrets list [--tool <id>]      names + owning tool (NEVER values)
    yepgent secrets set <tool> <name> [--config]   store/replace a value
    yepgent secrets rotate <tool> <name> [--config]   alias of `set` (overwrite)
    yepgent secrets remove <tool> <name>    delete a secret/config value
    yepgent secrets status                  keyring availability + storage paths

Secret values are read with a hidden prompt (``getpass``) and stored in the OS
keyring; ``--config`` marks a NON-secret value stored as plaintext in
``~/.local-yep/tool_config.toml``. The listing surface prints only credential
NAMES and which tool owns them — never a value.
"""

from __future__ import annotations

import argparse
import getpass
import sys


def _secrets():
    """Lazy import so `yepgent --help` works without the optional extra; the
    module itself imports cleanly even when `keyring` is absent."""
    from local_yep import secrets as _s

    return _s


def _cmd_list(args: argparse.Namespace) -> int:
    s = _secrets()
    names = s.list_names(getattr(args, "tool", None))
    any_rows = any(rows for rows in names.values())
    if not any_rows:
        scope = f" for tool {args.tool!r}" if getattr(args, "tool", None) else ""
        print(f"No stored credentials{scope}.")
        return 0
    for tool_id in sorted(names):
        rows = names[tool_id]
        if not rows:
            continue
        print(f"{tool_id}:")
        for row in rows:
            kind = "secret" if row["secret"] else "config"
            state = "set" if row["present"] else "MISSING"
            print(f"  {row['name']}  ({kind}, {state})")
    if not s.keyring_available():
        print(
            "\nNote: no OS keyring backend detected — secret values cannot be "
            "read/stored until one is available (see `yepgent secrets status`).",
            file=sys.stderr,
        )
    return 0


def _read_value(name: str, *, secret: bool) -> str | None:
    """Prompt for a value. Hidden (getpass) for secrets; visible for config.
    Returns None on EOF/interrupt/empty."""
    try:
        if secret:
            val = getpass.getpass(
                f"Enter {name} (input hidden; stored in the OS keyring): "
            )
        else:
            val = input(f"Enter {name} (non-secret config, stored as plaintext): ")
    except (EOFError, KeyboardInterrupt):
        print("\nAborted — nothing stored.", file=sys.stderr)
        return None
    return val if val else None


def _cmd_set(args: argparse.Namespace) -> int:
    s = _secrets()
    is_config = bool(getattr(args, "config", False))
    if not is_config and not s.keyring_available():
        print(
            "Cannot store a secret: no OS keyring backend is available.\n"
            "Install the extra (`pip install 'local-yep[secrets]'`) or, on a "
            "headless host, a Secret Service. Use --config only for NON-secret "
            "values (stored as plaintext).",
            file=sys.stderr,
        )
        return 2
    value = _read_value(args.name, secret=not is_config)
    if value is None:
        return 1
    try:
        if is_config:
            s.set_config(args.tool, args.name, value)
        else:
            s.set_secret(args.tool, args.name, value)
    except s.NoKeyringError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    where = "tool_config.toml" if is_config else "OS keyring"
    print(f"Stored {args.name} for {args.tool} in the {where}.")
    return 0


def _cmd_remove(args: argparse.Namespace) -> int:
    s = _secrets()
    removed_secret = s.delete_secret(args.tool, args.name)
    removed_config = s.delete_config(args.tool, args.name)
    if removed_secret or removed_config:
        print(f"Removed {args.name} for {args.tool}.")
        return 0
    print(f"No stored credential {args.name!r} for tool {args.tool!r}.", file=sys.stderr)
    return 1


def _cmd_status(args: argparse.Namespace) -> int:
    s = _secrets()
    from local_yep import secrets as _s

    available = s.keyring_available()
    print(f"Keyring backend available: {'yes' if available else 'no'}")
    print(f"Config + secret-name registry: {_s._config_path()}")
    if not available:
        print(
            "\nSecrets cannot be stored until a keyring backend is available:\n"
            "  • pip install 'local-yep[secrets]'\n"
            "  • on headless Linux, run a Secret Service (gnome-keyring/KWallet)\n"
            "Non-secret config (`--config`) does not require a keyring.",
            file=sys.stderr,
        )
        return 1
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yepgent secrets",
        description="Manage installed tools' locally-stored credentials.",
    )
    sub = parser.add_subparsers(dest="action", metavar="<action>")

    p_list = sub.add_parser("list", help="list credential names per tool (never values)")
    p_list.add_argument("--tool", help="only this tool id")
    p_list.set_defaults(func=_cmd_list)

    p_set = sub.add_parser("set", help="store/replace a credential (prompts for the value)")
    p_set.add_argument("tool", help="owning tool id")
    p_set.add_argument("name", help="env var name (e.g. API_KEY)")
    p_set.add_argument(
        "--config",
        action="store_true",
        help="store as NON-secret plaintext config instead of a keyring secret",
    )
    p_set.set_defaults(func=_cmd_set)

    p_rotate = sub.add_parser("rotate", help="replace an existing credential (alias of set)")
    p_rotate.add_argument("tool", help="owning tool id")
    p_rotate.add_argument("name", help="env var name")
    p_rotate.add_argument("--config", action="store_true", help="non-secret config value")
    p_rotate.set_defaults(func=_cmd_set)

    p_remove = sub.add_parser("remove", help="delete a stored credential")
    p_remove.add_argument("tool", help="owning tool id")
    p_remove.add_argument("name", help="env var name")
    p_remove.set_defaults(func=_cmd_remove)

    p_status = sub.add_parser("status", help="show keyring availability + storage paths")
    p_status.set_defaults(func=_cmd_status)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help(sys.stderr)
        return 1
    return int(func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
