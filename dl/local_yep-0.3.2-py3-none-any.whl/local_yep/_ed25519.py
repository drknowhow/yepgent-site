"""Vendored, dependency-free Ed25519 **verification** (RFC 8032).

Derived from the public-domain Ed25519 reference implementation
(https://ed25519.cr.yp.to/python/ed25519.py — public domain), trimmed to the
verify path and sped up by (a) using Python's built-in C-level ``pow()`` for
modular exponentiation and (b) an iterative double-and-add scalar multiply. A
single :func:`verify` then runs in a few milliseconds — within the SessionStart
hook's time budget.

Why vendored: the free core needs signature *verification* only (a public-key
operation), so this adds **no runtime dependency**. Signing happens off-line at
release with a vetted library (see ``scripts/integrity_tool.py``), never here.

Supported surface: :func:`verify`. :func:`publickey` is included only so the
test suite can cross-check this implementation against ``cryptography``.
"""
from __future__ import annotations

import hashlib

_b = 256
_q = 2 ** 255 - 19
_l = 2 ** 252 + 27742317777372353535851937790883648493


def _H(m: bytes) -> bytes:
    return hashlib.sha512(m).digest()


def _inv(x: int) -> int:
    return pow(x, _q - 2, _q)


_d = (-121665 * _inv(121666)) % _q
_I = pow(2, (_q - 1) // 4, _q)


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * _inv(_d * y * y + 1)
    x = pow(xx, (_q + 3) // 8, _q)
    if (x * x - xx) % _q != 0:
        x = (x * _I) % _q
    if x % 2 != 0:
        x = _q - x
    return x


_By = (4 * _inv(5)) % _q
_Bx = _xrecover(_By)
_B = (_Bx % _q, _By % _q)


def _edwards(P, Q):
    x1, y1 = P
    x2, y2 = Q
    dxy = _d * x1 * x2 * y1 * y2
    den1 = (1 + dxy) % _q
    den2 = (1 - dxy) % _q
    # One modular inversion instead of two: invert the product, then recover
    # each reciprocal with a multiply (inv is the dominant cost here).
    j = _inv((den1 * den2) % _q)
    x3 = (x1 * y2 + x2 * y1) * (j * den2)
    y3 = (y1 * y2 + x1 * x2) * (j * den1)
    return (x3 % _q, y3 % _q)


def _scalarmult(P, e: int):
    # Iterative double-and-add (LSB first); neutral element is (0, 1).
    Q = (0, 1)
    while e > 0:
        if e & 1:
            Q = _edwards(Q, P)
        P = _edwards(P, P)
        e >>= 1
    return Q


def _bit(h: bytes, i: int) -> int:
    return (h[i // 8] >> (i % 8)) & 1


def _encodepoint(P) -> bytes:
    x, y = P
    bits = [(y >> i) & 1 for i in range(_b - 1)] + [x & 1]
    return bytes(
        sum(bits[i * 8 + j] << j for j in range(8)) for i in range(_b // 8)
    )


def _Hint(m: bytes) -> int:
    h = _H(m)
    return sum(2 ** i * _bit(h, i) for i in range(2 * _b))


def _isoncurve(P) -> bool:
    x, y = P
    return (-x * x + y * y - 1 - _d * x * x * y * y) % _q == 0


def _decodeint(s: bytes) -> int:
    return sum(2 ** i * _bit(s, i) for i in range(0, _b))


def _decodepoint(s: bytes):
    y = sum(2 ** i * _bit(s, i) for i in range(0, _b - 1))
    x = _xrecover(y)
    if x & 1 != _bit(s, _b - 1):
        x = _q - x
    P = (x, y)
    if not _isoncurve(P):
        raise ValueError("point not on curve")
    return P


def verify(public_key: bytes, message: bytes, signature: bytes) -> bool:
    """Return True iff ``signature`` is a valid Ed25519 signature of
    ``message`` under ``public_key`` (32-byte raw key, 64-byte raw signature).

    Never raises — any malformed input or internal error returns False.
    """
    try:
        if len(signature) != 64 or len(public_key) != 32:
            return False
        R = _decodepoint(signature[:32])
        A = _decodepoint(public_key)
        S = _decodeint(signature[32:])
        h = _Hint(_encodepoint(R) + public_key + message)
        return _scalarmult(_B, S) == _edwards(R, _scalarmult(A, h))
    except Exception:
        return False


def publickey(seed: bytes) -> bytes:
    """Derive the 32-byte public key from a 32-byte Ed25519 seed (test aid)."""
    h = _H(seed)
    a = 2 ** (_b - 2) + sum(2 ** i * _bit(h, i) for i in range(3, _b - 2))
    return _encodepoint(_scalarmult(_B, a))
