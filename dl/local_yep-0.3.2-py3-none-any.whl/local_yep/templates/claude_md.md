# Local Yep — Managed Instructions

You are running inside a repository managed by **Local Yep**: a local-first agent
framework for Claude Code. Memory lives on this machine (SQLite at
`~/.local-yep/memory.db`); nothing here phones home.

## Who you are
Your identity, name, owner, and voice are NOT in this file. They are injected at
the start of every session by the Local Yep **SessionStart hook** (the frozen
ethical spine + your rendered `identity.md`). Treat that injected identity as
authoritative; this block is only a pointer so you know it is coming. If you ever
find yourself without it, run `yepgent init` to (re)wire the hooks.

## Memory discipline — recall before you reason, reflect after you act
A persistent **recall -> reflect** loop is the whole point of Local Yep. The
memory MCP server exposes a small, eager-loaded tool set; use it deliberately:

- **RECALL first.** Before any context-dependent task, pull what you already
  know: `recall_facts` / `recall_fact` (durable facts about the owner and
  project), `recall_episodes` (past events), `recall_reflections` (lessons and
  preferences). Do not answer from a cold start when memory may hold the answer.
- **REMEMBER durable facts.** When you learn a stable fact about the owner or the
  work, write it with `remember_fact` (dotted keys like `user.name`). Upserts on
  key; keep it terse and high-signal.
- **REFLECT on lessons.** When you discover a pattern, preference, or mistake
  worth carrying forward, write it with `reflect`. Use sparingly — reflections
  are precious, not a log.
- **Log milestones as episodes** with `write_episode` (PR merged, decision made,
  bug found). The Stop hook also records an episode automatically at session end.

Memory is precious and 100% local. Never fabricate a recalled fact; if memory is
empty, say so plainly and learn going forward.

## Per-session memory injection
Each turn, the Local Yep UserPromptSubmit hook injects a `<memory>` block with
the most relevant facts, recent episodes, and active reflections for the current
message. Read it — it is your working memory for this turn — but still call the
recall tools when you need more than the surfaced slice.

## Notes
- Local Yep works with your own Claude (subscription or API key); it never
  touches, proxies, or resells Claude credentials.
- `alwaysLoad` eager tool loading requires Claude Code >= 2.1.121; on older
  clients the memory tools defer gracefully (you can still call them).
- `yepgent init --force` regenerates this managed block and the hook/MCP wiring;
  your prose OUTSIDE this fenced block is always preserved. `yepgent upgrade`
  re-stamps the version, and `yepgent uninstall` removes the wiring (keeping
  your memory unless you pass `--purge-memory`).
