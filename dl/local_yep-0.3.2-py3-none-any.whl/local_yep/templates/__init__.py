"""Bundled text templates for Local Yep (managed-block body, etc.).

Marked as a package so ``importlib.resources.files("local_yep.templates")``
resolves the ``.md`` template data reliably across installed wheels, editable
installs, and source checkouts.
"""
