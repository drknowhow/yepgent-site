# Yep — Tool recipes

Practical recipes for the local tool surface. Operative context, not part of the
frozen spine.

## Memory — the recall → reflect loop
The slim MCP server exposes your memory (all 100% local SQLite):
- `recall_facts` / `recall_fact` — durable facts about the owner and the work.
- `recall_episodes` — past events (semantic / lexical search).
- `recall_reflections` — lessons, patterns, preferences.
- `remember_fact(key, value)` — store a durable fact; dotted keys like
  `user.timezone`. Upserts on key.
- `reflect(note, tag)` — record a lesson. Sparingly — only a real pattern.
- `write_episode(summary, content)` — log a milestone (a decision, a bug found,
  a result).

Recall before you reason; reflect after you act, only on a real lesson. The
per-turn `<memory>` block is injected automatically as a floor — still recall
deliberately for anything substantive.

## Toolspace — installing and using tools
- `tool_search` — find a tool across the local installed index + the registry.
- Installing a code-fetching tool runs a **local confirm gate** first: it prints
  the exact source (e.g. `url@SHA` or the `pip` command), the command/argv, the
  requested scopes, and the `data_boundary`. Approve only what you actually want
  to run. Installs are fail-closed and isolated — per-tool venv, SHA-pinned, with
  a smoke test — and a forbidden "we-run-a-service" runtime is refused.
- Call an installed tool's action through the toolspace. A tool that needs
  credentials reads them from the local store at call time — never from argv or
  logs.

## Credentials — local, bring-your-own
- `yepgent secrets set <tool> <NAME>` — store an API key/secret in the OS keyring
  (never plaintext, never logged). `yepgent secrets list` shows names only.
- `yepgent tools auth <tool>` — authorize a tool's OAuth via a local loopback
  flow; tokens are stored and refreshed in the keyring.

## Entitlement / license
- `yepgent license status` — entitlement state (for premium tools or a gated build).
- `yepgent license activate <token>` — apply an activation token.

Everything here is local: no daemon, and no network beyond a tool's own
owner-authorized calls and the optional premium-manifest fetch.
