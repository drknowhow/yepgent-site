"""``gent`` — the global launcher for interactive Claude-Code-as-Yep.

Run ``gent`` from **any** directory to open an interactive Claude Code session
that IS Yep (identity + memory + continuity + the slim memory MCP), with the
current directory as the project — no per-project ``yepgent init`` required.
Plain ``claude`` stays vanilla.

Modes (mirrors the cloud-yep launcher)::

    gent [args...]            Yep here — the current directory is the project.
    gent <dir> [args...]      Yep IN <dir> — launch with <dir> as the project.
    gent -r <dir> [args...]   reach-in — stay here, grant Claude access to <dir>
                              via --add-dir (git/edits stay pointed at the cwd).

Any arg that is not a recognized mode or an existing directory (a flag like
``--resume``, or a prompt string) forwards verbatim to ``claude`` — so
``gent "do X"`` opens the session with a first prompt, and ``gent --version``
passes straight through.

How it works (mirrors the proven cloud-yep "project mode"): Claude Code accepts
``--mcp-config`` and ``--settings`` per invocation, so ``gent`` launches::

    claude --mcp-config <home>/portable/mcp.json \\
           --settings   <home>/portable/settings.json \\
           [your args...]

* ``portable/mcp.json``   registers the slim memory MCP server (``yepgent``).
* ``portable/settings.json`` wires the three ``yepgent-hook`` hooks
  (SessionStart identity, UserPromptSubmit ambient memory, Stop episode).

Both are regenerated under ``~/.local-yep/portable/`` on first run and whenever
the package version changes, reusing the exact wiring :mod:`local_yep.installer`
writes per project — so the global and per-project paths never drift. Identity
is injected by the SessionStart hook (it reads ``~/.local-yep/agent.toml``), so
it works in a foreign repo with no project files. We do NOT pass
``--strict-mcp-config``: a project's own ``.mcp.json`` servers (e.g. C3) still
load alongside Yep's memory server.

Guardrail G2 holds: this launches an **interactive** session (flat-rate
subscription is fine). Autonomous paths are gated separately by
:mod:`local_yep.guardrails`.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from local_yep import __version__, home, installer

# ---------------------------------------------------------------------------
# Portable profile location (under the shared home)
# ---------------------------------------------------------------------------

#: Directory holding the portable ``--mcp-config`` / ``--settings`` files.
PORTABLE_DIR = home.HOME / "portable"
PORTABLE_MCP = PORTABLE_DIR / "mcp.json"
PORTABLE_SETTINGS = PORTABLE_DIR / "settings.json"
PORTABLE_VERSION = PORTABLE_DIR / "version"


def _portable_settings() -> dict:
    """The portable settings doc: the three Yep hooks, nothing else.

    Reuses :data:`installer.HOOK_EVENTS` and :func:`installer._hook_command` so
    the wiring is byte-identical to what ``yepgent init`` writes per project.
    """
    command = installer._hook_command()
    hooks: dict[str, list] = {}
    for event, sub in installer.HOOK_EVENTS.items():
        hooks[event] = [
            {
                "matcher": installer._event_matcher(event),
                "hooks": [{"type": "command", "command": f"{command} {sub}"}],
            }
        ]
    return {"hooks": hooks}


def _portable_mcp() -> dict:
    """The portable MCP doc: the slim memory server, keyed as ``yepgent``."""
    return {"mcpServers": {installer.MCP_SERVER_KEY: installer._mcp_server_entry()}}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


def write_portable_profile() -> None:
    """(Re)generate the portable ``mcp.json`` + ``settings.json`` + version stamp."""
    home.bootstrap()
    _write_json(PORTABLE_MCP, _portable_mcp())
    _write_json(PORTABLE_SETTINGS, _portable_settings())
    PORTABLE_VERSION.write_text(__version__ + "\n", encoding="utf-8")


def _profile_is_current() -> bool:
    """True iff both portable files exist and the version stamp matches."""
    if not (PORTABLE_MCP.is_file() and PORTABLE_SETTINGS.is_file()):
        return False
    try:
        return PORTABLE_VERSION.read_text(encoding="utf-8").strip() == __version__
    except OSError:
        return False


def ensure_portable_profile() -> None:
    """Generate the portable profile if missing or stale (cheap, idempotent)."""
    if not _profile_is_current():
        write_portable_profile()


# ---------------------------------------------------------------------------
# Launch
# ---------------------------------------------------------------------------

def _resolve_claude() -> str | None:
    """Absolute path to the ``claude`` executable, or None if not on PATH."""
    return shutil.which("claude")


def build_claude_argv(extra: list[str], *, add_dir: str | None = None) -> list[str]:
    """The argv that launches Claude Code with the portable Yep profile.

    ``add_dir`` grants Claude file access to an extra directory (reach-in mode)
    via ``--add-dir`` without changing the project root.
    """
    claude = _resolve_claude()
    argv = [
        claude or "claude",
        "--mcp-config",
        str(PORTABLE_MCP),
        "--settings",
        str(PORTABLE_SETTINGS),
    ]
    if add_dir:
        argv += ["--add-dir", add_dir]
    argv += list(extra)
    return argv


def resolve_launch(argv: list[str]) -> tuple[str, str | None, list[str], str | None]:
    """Parse ``gent`` modes from ``argv``.

    Returns ``(cwd, add_dir, extra, notice)``:

    * ``gent``                    -> launch in the current directory.
    * ``gent <dir> [args...]``    -> launch IN <dir> (that dir becomes the project).
    * ``gent -r <dir> [args...]`` -> reach-in: stay in the current directory and
      grant Claude access to <dir> via ``--add-dir``.

    Anything that is not a recognized mode / existing directory (a flag or a
    prompt) forwards verbatim in ``extra``. ``notice`` is an optional stderr note.
    """
    args = list(argv)
    here = os.getcwd()

    # Reach-in: -r/--reach <dir>.
    if args and args[0] in ("-r", "--reach"):
        rest = args[1:]
        if rest and not rest[0].startswith("-") and Path(rest[0]).is_dir():
            target = str(Path(rest[0]).resolve())
            return here, target, rest[1:], f"reaching into {target}"
        return here, None, rest, "-r needs a directory - launching here"

    # Project: a leading existing-directory arg.
    if args and not args[0].startswith("-") and Path(args[0]).is_dir():
        target = str(Path(args[0]).resolve())
        return target, None, args[1:], None

    # Bare.
    return here, None, args, None


def _unconfigured() -> bool:
    """True when no personalized identity exists yet.

    ``bootstrap()`` creates an EMPTY ``agent.toml``, so "fresh" means the file is
    missing OR zero-byte — the same condition the SessionStart hook treats as
    "use the default identity".
    """
    try:
        p = home.AGENT_TOML
        return (not p.exists()) or p.stat().st_size == 0
    except Exception:  # noqa: BLE001 - never let this gate the launch
        return False


def _maybe_first_run_onboarding(argv: list[str]) -> None:
    """On a fresh install, offer the identity wizard before launching.

    No-op when already configured, when not on an interactive terminal, or for
    quick ``--version`` / ``--help`` invocations. Always skippable; never blocks
    automation (a non-TTY stdin or YEPGENT_NONINTERACTIVE skips it silently).
    """
    if not _unconfigured():
        return
    if argv and argv[0] in ("--version", "-V", "--help", "-h"):
        return
    try:
        from local_yep.identity import wizard
        if not wizard.should_run_interactively():
            return
    except Exception:  # noqa: BLE001
        return
    try:
        print("[gent] First run — set up your Yep (name, owner, voice).", file=sys.stderr)
        answer = input("       Run setup now? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print(file=sys.stderr)
        return
    if answer in ("n", "no"):
        print("[gent] Skipped — using defaults. Run `yepgent onboard` anytime.", file=sys.stderr)
        return
    try:
        wizard.run_wizard(io=wizard.ConsoleIO())
    except (EOFError, KeyboardInterrupt):
        print("\n[gent] Setup cancelled — using defaults.", file=sys.stderr)
    except Exception as exc:  # noqa: BLE001 - never let onboarding block the launch
        print(f"[gent] onboarding skipped ({exc})", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    """``gent`` entrypoint: ensure the profile, then hand off to Claude Code.

    All args forward to ``claude`` (so ``gent "do X"`` opens the session with a
    first prompt, and ``gent --version`` / ``gent --help`` pass straight
    through). Runs in the current working directory. Returns Claude's exit code.
    """
    raw = list(sys.argv[1:] if argv is None else argv)

    claude = _resolve_claude()
    if not claude:
        print(
            "gent: could not find the 'claude' executable on PATH. Install "
            "Claude Code (https://claude.com/claude-code) and ensure `claude` "
            "runs, then retry `gent`.",
            file=sys.stderr,
        )
        return 127

    # System-integrity gate (fail-closed): refuse to launch a tampered install.
    from local_yep import integrity

    result = integrity.check()
    if not result.ok:
        print(integrity.tamper_message(result), file=sys.stderr)
        return 3

    # Activation gate (gated alpha/beta only; off by default): refuse to launch
    # without a valid entitlement when REQUIRE_ACTIVATION / the env var is on.
    from local_yep import activation

    act = activation.check()
    if not act.ok:
        print(act.message, file=sys.stderr)
        return 4

    try:
        ensure_portable_profile()
    except OSError as exc:
        print(f"gent: could not write the portable profile: {exc}", file=sys.stderr)
        return 1

    # First-run onboarding: on a fresh install offer the identity wizard so a
    # tester gets a personalized Yep instead of the default. Skippable; only on
    # an interactive terminal; never blocks automation.
    _maybe_first_run_onboarding(raw)

    cwd, add_dir, extra, notice = resolve_launch(raw)
    cmd = build_claude_argv(extra, add_dir=add_dir)

    if notice:
        print(f"[gent] {notice}", file=sys.stderr)
    # ASCII separator only — a non-ASCII glyph mojibakes on legacy Windows
    # console codepages (cp1252) and could even raise on a strict stderr codec.
    print(f"[gent] Yep in {cwd}", file=sys.stderr)
    try:
        # Inherit stdio so Claude Code's interactive TUI works; return its code.
        return subprocess.run(cmd, cwd=cwd).returncode
    except KeyboardInterrupt:  # pragma: no cover - interactive Ctrl-C
        return 130


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
