"""``yepgent license`` — claim / activate / inspect the local entitlement.

Premium tools (and a gated alpha) are unlocked by a signed entitlement stored at
``~/.local-yep/license.json`` (override: ``LOCAL_YEP_LICENSE_FILE``). This CLI is
the buyer/tester side — it puts a token there and reports its status. It is the
verb the deploy doc previously listed as "not built".

    yepgent license status                  show entitlement state + entitled ids
    yepgent license activate <token>        save a pasted entitlement JWT
    yepgent license claim <key> [--host H]  fetch a minted token from the gated host
    yepgent license remove                  delete the local entitlement

Verifying a token needs the matching PUBLIC key — bundled in a release build or
supplied via ``LOCAL_YEP_TOOLSPACE_PUBKEY`` — and the ``[pro]`` crypto extra.
``activate`` / ``claim`` still store the token without those (so a tester can be
provisioned ahead of a build); ``status`` then reports why it can't yet verify.
No network except ``claim`` (an explicit fetch from the premium host you name).
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import sys
from typing import Optional


def _entitlement():
    from local_yep.toolspace import entitlement
    return entitlement


def _license_path():
    return _entitlement()._license_path()


def _write_token(token: str) -> None:
    p = _license_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"jwt": token.strip()}) + "\n", encoding="utf-8")


def _fmt_exp(exp) -> str:
    try:
        return _dt.datetime.fromtimestamp(int(exp), _dt.timezone.utc).strftime(
            "%Y-%m-%d %H:%M UTC"
        )
    except Exception:
        return str(exp)


def _status() -> int:
    st = _entitlement().entitlement_status()
    print(f"state:    {st.state}")
    print(f"valid:    {st.valid}")
    if st.claims:
        if st.claims.get("sub"):
            print(f"subject:  {st.claims['sub']}")
        if st.claims.get("plan"):
            print(f"plan:     {st.claims['plan']}")
        if st.claims.get("exp"):
            print(f"expires:  {_fmt_exp(st.claims['exp'])}")
        ids = sorted(st.ids)
        print(f"entitled: {', '.join(ids) if ids else '(none)'}")
    print(f"license:  {_license_path()}")
    if st.reason:
        print(f"note:     {st.reason}")
    return 0 if st.valid else 1


def _activate(token: str) -> int:
    token = (token or "").strip()
    if token.count(".") != 2:
        print("activate: that does not look like a JWT (expected three "
              "dot-separated segments).", file=sys.stderr)
        return 2
    _write_token(token)
    print(f"saved entitlement to {_license_path()}")
    return _status()


def _claim(key: str, host: Optional[str]) -> int:
    import urllib.error
    import urllib.request

    host = (host or _entitlement().DEFAULT_PREMIUM_HOST).strip().rstrip("/")
    url = f"https://{host}/claim/{key}"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:  # noqa: S310 - https only
            body = resp.read().decode("utf-8").strip()
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print("claim: no entitlement for that key yet (not purchased, or the "
                  "webhook hasn't processed it).", file=sys.stderr)
            return 4
        print(f"claim: server returned HTTP {exc.code}.", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 - network/URL errors -> friendly message
        print(f"claim: could not reach {url} ({exc}).", file=sys.stderr)
        return 1
    if not body:
        print("claim: empty response from the premium host.", file=sys.stderr)
        return 1
    # The /claim body IS the license.json record (carries the "jwt" key) — save
    # it verbatim; entitlement._read_license_token reads either shape.
    p = _license_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body + "\n", encoding="utf-8")
    print(f"claimed entitlement to {p}")
    return _status()


def _remove() -> int:
    p = _license_path()
    if not p.exists():
        print("no local entitlement to remove.")
        return 0
    try:
        p.unlink()
    except OSError as exc:
        print(f"remove: could not delete {p} ({exc}).", file=sys.stderr)
        return 1
    print(f"removed entitlement: {p}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="yepgent license", description=__doc__)
    sub = p.add_subparsers(dest="action", metavar="<action>")
    sub.add_parser("status", help="show entitlement state + entitled ids")
    a = sub.add_parser("activate", help="save a pasted entitlement JWT")
    a.add_argument("token", help="the entitlement JWT (three dot-separated segments)")
    c = sub.add_parser("claim", help="fetch a minted token from the gated host")
    c.add_argument("key", help="the claim key (from your purchase / issued to you)")
    c.add_argument("--host", default=None, help="premium host (default: the bundled one)")
    sub.add_parser("remove", help="delete the local entitlement")
    return p


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv if argv is not None else sys.argv[1:])
    if args.action == "status":
        return _status()
    if args.action == "activate":
        return _activate(args.token)
    if args.action == "claim":
        return _claim(args.key, args.host)
    if args.action == "remove":
        return _remove()
    build_parser().print_help(sys.stderr)
    return 2


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
