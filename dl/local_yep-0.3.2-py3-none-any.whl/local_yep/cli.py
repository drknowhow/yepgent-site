"""``yep`` — the Local Yep command-line entrypoint.

Argparse skeleton (T1.1). Subcommands:

    yepgent init [--force]   install/refresh the managed block + hooks + home  (G6)
    yepgent upgrade          re-run generation against the installed version    (G6)
    yepgent uninstall        remove the repo wiring (--purge-memory wipes home)
    yepgent onboard          run the identity onboarding wizard                 (H5)
    yepgent identity edit    re-run the onboarding wizard                       (H5)
    yepgent secrets ...      manage installed tools' local credentials          (T6.4)
    yepgent tools auth ...   authorize a tool's OAuth (local loopback / device)  (T6.8)
    yepgent memory ...       memory maintenance (reindex / backup / stats)      (G4)

``init`` / ``upgrade`` delegate to :mod:`local_yep.installer` (G6); ``memory``
delegates to the memory command module (G4); ``onboard`` / ``identity edit``
delegate to :mod:`local_yep.identity.wizard` (H5). Those are imported **lazily**
so this CLI — and especially ``yepgent --help`` / ``yepgent --version`` — works before a
delegate lands. When a delegate target is missing we print a friendly
"not yet implemented" message and exit non-zero rather than tracebacking.

CRITICAL (H5): ``yepgent init`` MUST stay non-interactive for automation. The
onboarding wizard runs at the end of ``init`` ONLY when ``sys.stdin.isatty()``
is true; otherwise (e.g. CI's ``yepgent init </dev/null``) ``init`` writes a sane
DEFAULT ``agent.toml`` if none exists and NEVER blocks on input. The wizard is
also reachable explicitly via ``yepgent onboard`` / ``yepgent identity edit``.
"""

from __future__ import annotations

import argparse
import os
import sys

from local_yep import __version__


def _friendly_missing(feature: str, module: str, exc: Exception) -> int:
    """Report a not-yet-wired delegate target without a traceback."""
    print(
        f"yep: '{feature}' is not yet implemented "
        f"(pending module {module!r}: {exc}).",
        file=sys.stderr,
    )
    return 2


def _cmd_init(args: argparse.Namespace) -> int:
    try:
        from local_yep import installer
    except Exception as exc:  # noqa: BLE001 - G6 may not exist yet
        return _friendly_missing("init", "local_yep.installer", exc)
    fn = getattr(installer, "init", None)
    if not callable(fn):
        return _friendly_missing(
            "init", "local_yep.installer.init", AttributeError("init")
        )
    rc = int(fn(force=getattr(args, "force", False)) or 0)
    if rc != 0:
        return rc
    # Identity step (H5). Strictly non-blocking: interactive wizard ONLY on a
    # TTY; otherwise write a default agent.toml if none exists. This is what
    # keeps `yepgent init </dev/null` (CI) from ever hanging on input.
    _run_init_identity(force=getattr(args, "force", False))
    return rc


def _run_init_identity(*, force: bool) -> None:
    """The identity step of ``yepgent init`` — never blocks on input (H5).

    On a TTY: run the onboarding wizard so a real first-run user is guided
    through name/owner/preset. With no TTY (CI, pipes): write a sensible default
    ``agent.toml`` only when one does not already exist (so re-running ``init``
    never clobbers a configured identity), then return immediately.

    All failures degrade quietly — the home/wiring from the installer already
    succeeded, and a fresh install still injects full identity via the
    render pipeline's default fallback even if no ``agent.toml`` is written here.
    """
    try:
        from local_yep import home
        from local_yep.identity import wizard
    except Exception as exc:  # noqa: BLE001 - identity module optional at runtime
        print(f"yepgent init: identity step skipped ({exc}).", file=sys.stderr)
        return

    has_config = False
    try:
        has_config = home.AGENT_TOML.is_file() and home.AGENT_TOML.stat().st_size > 0
    except OSError:
        has_config = False

    if wizard.should_run_interactively():
        try:
            wizard.run_wizard(io=wizard.ConsoleIO())
        except (KeyboardInterrupt, EOFError):
            print("\nyepgent init: onboarding cancelled; writing a default identity.")
            if not has_config:
                wizard.init_default()
        except Exception as exc:  # noqa: BLE001 - never fail init on wizard error
            print(f"yepgent init: onboarding failed ({exc}); wrote default identity.",
                  file=sys.stderr)
            if not has_config:
                wizard.init_default()
        return

    # No TTY: default path. Do not clobber an existing config.
    if has_config:
        print("yepgent init: existing agent.toml left untouched "
              "(run `yepgent onboard` to reconfigure).")
        return
    try:
        wizard.init_default()
        print(f"yepgent init: wrote a default identity to {home.AGENT_TOML} "
              "(run `yepgent onboard` to personalize).")
    except Exception as exc:  # noqa: BLE001
        print(f"yepgent init: default identity write skipped ({exc}).", file=sys.stderr)


def _cmd_upgrade(args: argparse.Namespace) -> int:
    try:
        from local_yep import installer
    except Exception as exc:  # noqa: BLE001 - G6 may not exist yet
        return _friendly_missing("upgrade", "local_yep.installer", exc)
    fn = getattr(installer, "upgrade", None)
    if not callable(fn):
        return _friendly_missing(
            "upgrade", "local_yep.installer.upgrade", AttributeError("upgrade")
        )
    return int(fn() or 0)


def _cmd_uninstall(args: argparse.Namespace) -> int:
    try:
        from local_yep import installer
    except Exception as exc:  # noqa: BLE001 - installer may not exist yet
        return _friendly_missing("uninstall", "local_yep.installer", exc)
    fn = getattr(installer, "uninstall", None)
    if not callable(fn):
        return _friendly_missing(
            "uninstall", "local_yep.installer.uninstall", AttributeError("uninstall")
        )

    purge = bool(getattr(args, "purge_memory", False))
    if purge and not getattr(args, "yes", False):
        # Deleting ~/.local-yep/ is irreversible. Require an explicit
        # confirmation, and NEVER purge unprompted in a non-interactive shell
        # (mirrors init's no-clobber safety). The wiring removal is aborted too
        # so a stray --purge-memory in CI changes nothing.
        noninteractive = bool(os.environ.get("YEPGENT_NONINTERACTIVE"))
        try:
            is_tty = (not noninteractive) and sys.stdin.isatty()
        except Exception:  # noqa: BLE001
            is_tty = False
        if not is_tty:
            print(
                "yepgent uninstall: refusing to --purge-memory without confirmation "
                "in a non-interactive shell. Re-run with --yes to purge, or drop "
                "--purge-memory to keep ~/.local-yep/.",
                file=sys.stderr,
            )
            return 2
        from local_yep import home
        try:
            reply = input(
                f"Permanently DELETE {home.HOME} (memory, identity, keys, config)? "
                "This cannot be undone. Type 'yes' to confirm: "
            )
        except (KeyboardInterrupt, EOFError):
            print("\nyepgent uninstall: cancelled — nothing removed.")
            return 1
        if reply.strip().lower() != "yes":
            print(
                "yepgent uninstall: not confirmed — nothing removed. Drop "
                "--purge-memory to remove only the repo wiring."
            )
            return 1

    return int(fn(purge_memory=purge) or 0)


def _run_wizard_interactive(verb: str) -> int:
    """Shared body for ``yepgent onboard`` / ``yepgent identity edit`` (H5).

    Runs the onboarding wizard interactively against the real terminal. Unlike
    ``yepgent init`` these verbs are *explicitly* a request to (re)configure, so they
    run the wizard regardless of TTY when given one; with no TTY they refuse
    rather than silently writing a default (the user asked to be prompted).
    """
    try:
        from local_yep.identity import wizard
    except Exception as exc:  # noqa: BLE001 - H5 module
        return _friendly_missing(verb, "local_yep.identity.wizard", exc)

    if not wizard.should_run_interactively():
        print(
            f"yep {verb}: needs an interactive terminal. "
            "Run it from a real shell, or run `yepgent init` for a default identity.",
            file=sys.stderr,
        )
        return 2
    try:
        wizard.run_wizard(io=wizard.ConsoleIO())
    except (KeyboardInterrupt, EOFError):
        print("\nyep: cancelled — no changes written.")
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"yep {verb}: onboarding failed ({exc}).", file=sys.stderr)
        return 1
    return 0


def _cmd_onboard(args: argparse.Namespace) -> int:
    return _run_wizard_interactive("onboard")


def _cmd_identity(args: argparse.Namespace) -> int:
    action = getattr(args, "identity_action", None)
    if action == "edit":
        return _run_wizard_interactive("identity edit")
    # No/unknown subcommand: show the identity sub-help.
    print("usage: yepgent identity edit", file=sys.stderr)
    return 1


def _cmd_tools(args: argparse.Namespace) -> int:
    # Installed-tool operations incl. OAuth authorization (§6 / P5, T6.8). Forward
    # the remaining argv to the tools command module (e.g. `tools auth <tool>`).
    try:
        from local_yep import tools_cmd
    except Exception as exc:  # noqa: BLE001
        return _friendly_missing("tools", "local_yep.tools_cmd", exc)
    fn = getattr(tools_cmd, "main", None)
    if not callable(fn):
        return _friendly_missing(
            "tools", "local_yep.tools_cmd.main", AttributeError("main")
        )
    return int(fn(getattr(args, "tools_args", []) or []) or 0)


def _cmd_secrets(args: argparse.Namespace) -> int:
    # Local credential management (§6 / P5, T6.4). Forward the remaining argv so
    # the secrets command module parses its own subcommands (list/set/rotate/
    # remove/status). Lazy import keeps `yepgent --help` working without the
    # optional `keyring` extra installed.
    try:
        from local_yep import secrets_cmd
    except Exception as exc:  # noqa: BLE001
        return _friendly_missing("secrets", "local_yep.secrets_cmd", exc)
    fn = getattr(secrets_cmd, "main", None)
    if not callable(fn):
        return _friendly_missing(
            "secrets", "local_yep.secrets_cmd.main", AttributeError("main")
        )
    return int(fn(getattr(args, "secrets_args", []) or []) or 0)


def _cmd_memory(args: argparse.Namespace) -> int:
    # Memory maintenance verbs (reindex/backup/stats) are owned by G4. Forward
    # the remaining argv so the memory module can parse its own subcommands.
    try:
        from local_yep.memory import cmd as memory_cmd
    except Exception as exc:  # noqa: BLE001 - G4 may not exist yet
        return _friendly_missing("memory", "local_yep.memory.cmd", exc)
    fn = getattr(memory_cmd, "main", None)
    if not callable(fn):
        return _friendly_missing(
            "memory", "local_yep.memory.cmd.main", AttributeError("main")
        )
    return int(fn(getattr(args, "memory_args", []) or []) or 0)


def _cmd_license(args: argparse.Namespace) -> int:
    # Entitlement claim/activate/status/remove (§4 / P4, buyer + alpha-tester
    # side). Forward the remaining argv so the license module parses its own
    # subcommands. Lazy import keeps `yepgent --help` working without `[pro]`.
    try:
        from local_yep import license_cmd
    except Exception as exc:  # noqa: BLE001
        return _friendly_missing("license", "local_yep.license_cmd", exc)
    fn = getattr(license_cmd, "main", None)
    if not callable(fn):
        return _friendly_missing(
            "license", "local_yep.license_cmd.main", AttributeError("main")
        )
    return int(fn(getattr(args, "license_args", []) or []) or 0)


def _cmd_doctor(args: argparse.Namespace) -> int:
    """``yepgent doctor`` — offline health report (safe to paste in a bug report)."""
    from local_yep import doctor

    return doctor.run(as_json=getattr(args, "json", False))


def _cmd_events(args: argparse.Namespace) -> int:
    """``yepgent events`` — read the local activity ledger (PLAN §8 T8.4)."""
    from local_yep import events_cmd

    return events_cmd.main(args)


def _cmd_confirm(args: argparse.Namespace) -> int:
    """``yepgent confirm`` — typed confirmation for protected-file edits.

    Writes the short-lived token the PreToolUse enforcement gate checks
    (:mod:`local_yep.enforcement`). Interactive-only by design: a typed
    phrase from a real TTY is the whole point; non-interactive callers are
    refused (fail closed).
    """
    from local_yep import enforcement

    if getattr(args, "status", False):
        held, detail = enforcement.rule_change_lock_held()
        print(("HELD — " if held else "not held — ") + detail)
        return 0
    if getattr(args, "revoke", False):
        removed = enforcement.revoke_confirmation_token()
        print("confirmation token revoked." if removed
              else "no confirmation token present.")
        return 0

    if os.environ.get("YEPGENT_NONINTERACTIVE"):
        print("confirm: refusing in non-interactive mode — a typed "
              "confirmation cannot be automated.", file=sys.stderr)
        return 2
    if not sys.stdin.isatty():
        print("confirm: stdin is not a TTY — a typed confirmation cannot be "
              "piped; refusing.", file=sys.stderr)
        return 2

    print("This authorizes edits to PROTECTED governance files (spine, "
          "identity, hook wiring, enforcement) for the next "
          f"{enforcement.TOKEN_TTL_SECONDS // 60} minutes.")
    try:
        typed = input(f"Type the phrase exactly to proceed "
                      f"[{enforcement.CONFIRM_PHRASE}]: ")
    except EOFError:
        print("confirm: no input — refusing.", file=sys.stderr)
        return 2
    if typed.strip() != enforcement.CONFIRM_PHRASE:
        print("confirm: phrase mismatch — nothing written.", file=sys.stderr)
        return 2

    reason = getattr(args, "reason", None)
    if not reason:
        try:
            reason = input("Why (one line, recorded in the token): ").strip()
        except EOFError:
            reason = ""
    path = enforcement.write_confirmation_token(reason or "")
    print(f"confirmation token written ({path}) — valid "
          f"{enforcement.TOKEN_TTL_SECONDS // 60} minutes.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="yep",
        description=(
            "Local Yep — a local-first agent framework for your Claude Code. "
            "Remembers you across sessions, on your machine, with nothing in "
            "the cloud."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"local-yep {__version__}",
    )

    sub = parser.add_subparsers(dest="command", metavar="<command>")

    p_init = sub.add_parser(
        "init",
        help="install/refresh the managed block, hooks, MCP wiring and home",
    )
    p_init.add_argument(
        "--force",
        action="store_true",
        help="regenerate managed block + wiring even if already present",
    )
    p_init.set_defaults(func=_cmd_init)

    p_upgrade = sub.add_parser(
        "upgrade",
        help="re-run generation against the installed version",
    )
    p_upgrade.set_defaults(func=_cmd_upgrade)

    p_uninstall = sub.add_parser(
        "uninstall",
        help="remove Local Yep's repo wiring (hooks, MCP entry, managed block)",
    )
    p_uninstall.add_argument(
        "--purge-memory",
        action="store_true",
        dest="purge_memory",
        help="also DELETE ~/.local-yep/ (memory, identity, keys) — irreversible",
    )
    p_uninstall.add_argument(
        "-y",
        "--yes",
        action="store_true",
        dest="yes",
        help="skip the confirmation prompt for --purge-memory",
    )
    p_uninstall.set_defaults(func=_cmd_uninstall)

    p_onboard = sub.add_parser(
        "onboard",
        help="run the identity onboarding wizard (name, owner, preset, dials)",
    )
    p_onboard.set_defaults(func=_cmd_onboard)

    p_identity = sub.add_parser(
        "identity",
        help="manage the configurable identity (e.g. `yepgent identity edit`)",
    )
    identity_sub = p_identity.add_subparsers(
        dest="identity_action", metavar="<action>"
    )
    p_identity_edit = identity_sub.add_parser(
        "edit",
        help="re-run the onboarding wizard to reconfigure name/owner/preset/dials",
    )
    p_identity_edit.set_defaults(func=_cmd_identity, identity_action="edit")
    p_identity.set_defaults(func=_cmd_identity)

    p_tools = sub.add_parser(
        "tools",
        help="installed-tool operations: OAuth authorization (`tools auth <tool>`)",
    )
    p_tools.add_argument(
        "tools_args",
        nargs=argparse.REMAINDER,
        help="tools subcommand and its arguments",
    )
    p_tools.set_defaults(func=_cmd_tools)

    p_secrets = sub.add_parser(
        "secrets",
        help="manage installed tools' local credentials (list/set/rotate/remove)",
    )
    # Collect everything after `secrets` and hand it to the T6.4 command module.
    p_secrets.add_argument(
        "secrets_args",
        nargs=argparse.REMAINDER,
        help="secrets subcommand and its arguments",
    )
    p_secrets.set_defaults(func=_cmd_secrets)

    p_memory = sub.add_parser(
        "memory",
        help="memory maintenance: reindex / backup / stats",
    )
    # Collect everything after `memory` and hand it to the G4 memory command.
    p_memory.add_argument(
        "memory_args",
        nargs=argparse.REMAINDER,
        help="memory subcommand and its arguments",
    )
    p_memory.set_defaults(func=_cmd_memory)

    p_license = sub.add_parser(
        "license",
        help="entitlement: claim / activate / status / remove (premium + alpha)",
    )
    # Collect everything after `license` and hand it to the license command module.
    p_license.add_argument(
        "license_args",
        nargs=argparse.REMAINDER,
        help="license subcommand and its arguments",
    )
    p_license.set_defaults(func=_cmd_license)

    p_doctor = sub.add_parser(
        "doctor",
        help="offline health report: wiring, PATH, memory DB, integrity, activation",
    )
    p_doctor.add_argument(
        "--json",
        action="store_true",
        help="machine-readable output",
    )
    p_doctor.set_defaults(func=_cmd_doctor)

    p_events = sub.add_parser(
        "events",
        help="read the local activity ledger (what the agent did, and when)",
    )
    # Built lazily-ish: importing events_cmd here is cheap (stdlib + events)
    # and keeps the flag/verb definitions next to the code that uses them.
    from local_yep import events_cmd as _events_cmd

    _events_cmd.build_parser(p_events)
    p_events.set_defaults(func=_cmd_events)

    p_confirm = sub.add_parser(
        "confirm",
        help=(
            "type the confirmation phrase to authorize a protected-file "
            "edit (writes a short-lived token)"
        ),
    )
    p_confirm.add_argument(
        "--reason",
        help="why the protected edit is authorized (recorded in the token)",
    )
    p_confirm.add_argument(
        "--status",
        action="store_true",
        help="show whether a valid token is currently held",
    )
    p_confirm.add_argument(
        "--revoke",
        action="store_true",
        help="delete the current token",
    )
    p_confirm.set_defaults(func=_cmd_confirm)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    func = getattr(args, "func", None)
    if func is None:
        parser.print_help(sys.stderr)
        return 1

    return int(func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
