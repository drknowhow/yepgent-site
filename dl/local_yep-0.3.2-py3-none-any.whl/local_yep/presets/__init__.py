"""Voice presets for Local Yep — the personality moat (PLAN.md §3 T3.3/T3.4).

A *preset* is the SEED voice an agent ships with on day one. It carries VOICE,
never BIOGRAPHY: a crafted character (Character / Voice / Opinions / What I'm
not) plus a six-dial vector and one in-voice sample line. Memory is the
authenticity engine; the preset is only the starting timbre. A preset must
NEVER assert a relationship that does not exist on a fresh install ("the owner
built me", "we've worked together", "shaped my values") — the render pipeline
prepends a forming-bond frame instead, and the lint here rejects biography.

Each preset lives in a bundled directory ``presets/<id>/`` with four files:

* ``preset.toml`` — ``[preset]`` table: ``id``, ``display_name``,
  ``description`` (one line), ``paid`` (bool).
* ``voice.md``    — the authored first-person VOICE block.
* ``dials.toml``  — ``[dials]`` table: the six voice dials, each a legal value.
* ``sample.txt``  — one in-voice sample line.

Public API
----------
* :func:`list_presets` — ids of all bundled presets (sorted).
* :func:`load_preset`  — a typed :class:`Preset` for one id.
* :func:`validate_preset` — structural + lint validation; raises
  :class:`PresetError` on the first problem, else returns the :class:`Preset`.

Presets resolve from TWO roots (T3.11): the *bundled* package directory and the
toolspace install dir ``~/.local-yep/presets/`` (see :func:`installed_presets_dir`).
A pack the loader drops into the install dir is therefore immediately selectable
by the wizard and a legal ``agent.toml`` ``preset`` value — with an installed id
overriding a bundled one of the same name. This module never touches the frozen
spine.
"""
from __future__ import annotations

import os

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib
from dataclasses import dataclass, field
from importlib.resources import files
from pathlib import Path
from typing import Final

__all__ = [
    "DIAL_NAMES",
    "DIAL_VALUES",
    "Preset",
    "PresetError",
    "installed_presets_dir",
    "list_presets",
    "load_preset",
    "validate_preset",
]


# --------------------------------------------------------------------------- #
# Dial vocabulary — the single source of truth for legal dial values.
# Order is load-bearing: it is the canonical assembly order a dials->prose
# compiler (T3.5) walks, and the order a "dial vector" tuple is built in.
# --------------------------------------------------------------------------- #
DIAL_VALUES: Final[dict[str, tuple[str, ...]]] = {
    "verbosity": ("terse", "balanced", "expansive"),
    "formality": ("casual", "neutral", "formal"),
    "warmth": ("cool", "measured", "warm"),
    "humor": ("none", "dry", "playful"),
    "emoji": ("never", "sparing", "free"),
    "directness": ("diplomatic", "direct", "blunt"),
}

#: Canonical dial order (keys of :data:`DIAL_VALUES`).
DIAL_NAMES: Final[tuple[str, ...]] = tuple(DIAL_VALUES)

#: The four files every preset directory must contain.
_REQUIRED_FILES: Final[tuple[str, ...]] = (
    "preset.toml",
    "voice.md",
    "dials.toml",
    "sample.txt",
)

# --------------------------------------------------------------------------- #
# VOICE-not-BIOGRAPHY lint (T3.8 mitigation #1, applied at preset load).
#
# A preset describes a *character and a manner of speaking*. It must not claim
# a shared past with an owner who, on a fresh memory DB, is a stranger. These
# patterns catch the day-one relationship assertions the moat forbids. Matching
# is case-insensitive against the collapsed-whitespace voice text.
# --------------------------------------------------------------------------- #
_BIOGRAPHY_PATTERNS: Final[tuple[str, ...]] = (
    "built me",
    "made me",
    "created me",
    "named me",
    "shaped me",
    "shaped my values",
    "shaped who i am",
    "we've worked together",
    "we have worked together",
    "we've worked",
    "we have worked",
    "we worked together",
    "you built me",
    "you made me",
    "the owner built",
    "the owner and i",
    "owner and i",
    "my creator",
    "my owner built",
    "trained me",
    "raised me",
    "you and i have",
    "our history",
    "over the months",
    "months of working",
    "years of working",
    "ever since you",
)


class PresetError(ValueError):
    """A preset is missing files, malformed, or asserts biography."""


@dataclass(frozen=True)
class Preset:
    """A loaded, validated voice preset.

    Attributes
    ----------
    id:
        Stable identifier; matches the directory name and ``[preset].id``.
    display_name:
        Human-facing name shown in the wizard list.
    description:
        One-line pitch for the wizard list.
    paid:
        ``True`` for packs gated behind an entitlement (T3.11/§4).
    voice:
        The authored first-person VOICE block (markdown).
    dials:
        The six voice dials, each a legal value from :data:`DIAL_VALUES`.
    sample:
        One in-voice sample line previewed in the wizard.
    """

    id: str
    display_name: str
    description: str
    paid: bool
    voice: str
    dials: dict[str, str]
    sample: str = ""

    def dial_vector(self) -> tuple[str, ...]:
        """The dials as a tuple in canonical :data:`DIAL_NAMES` order.

        Two presets with the same ``dial_vector`` are voice-distinct only in
        prose, not in the compiled dials stanza — the authoring guarantee is
        that no two bundled presets share a vector.
        """
        return tuple(self.dials[name] for name in DIAL_NAMES)


# --------------------------------------------------------------------------- #
# Resource resolution — importlib.resources when packaged, path fallback for
# editable / source checkouts (mirrors managed_block._read_template()).
# --------------------------------------------------------------------------- #
def _presets_root() -> Path:
    """Return the bundled ``presets/`` directory as a real path."""
    try:
        return Path(str(files("local_yep.presets")))
    except Exception:  # pragma: no cover - source-tree fallback
        return Path(__file__).resolve().parent


#: Env override for the toolspace install dir (tests / alternate homes).
_ENV_PRESETS_DIR: Final[str] = "YEP_PRESETS_DIR"


def installed_presets_dir() -> Path:
    """The directory holding toolspace-INSTALLED preset packs.

    Honors the ``YEP_PRESETS_DIR`` override (used by tests and alternate homes);
    otherwise resolves the shared ``~/.local-yep/presets`` home (PLAN.md §3/§4
    layout, via :mod:`local_yep.home`). Installed presets augment the bundled
    set with NEW ids, so a pack the loader drops here becomes immediately
    selectable — but a bundled id can never be shadowed (the bundled voices
    are integrity-signed; see :func:`_resolve_preset_dir`). Never creates the
    directory.
    """
    override = os.environ.get(_ENV_PRESETS_DIR)
    if override:
        return Path(override).expanduser()
    try:
        from local_yep import home  # lazy — keep presets importable standalone

        return home.PRESETS_DIR
    except Exception:  # pragma: no cover - defensive
        return Path.home() / ".local-yep" / "presets"


def _preset_dirs() -> list[Path]:
    """Existing roots scanned for presets (install dir first, then bundled).

    The bundled package dir is always present; the install dir is included only
    when it exists. Used for LISTING; id resolution goes through
    :func:`_resolve_preset_dir`, where a bundled id always wins.
    """
    roots: list[Path] = []
    inst = installed_presets_dir()
    if inst.is_dir():
        roots.append(inst)
    roots.append(_presets_root())
    return roots


def _resolve_preset_dir(preset_id: str) -> Path | None:
    """Return the directory for ``preset_id``, or ``None``.

    BUNDLED ids always resolve to the bundled directory: the bundled voices
    are covered by the signed integrity manifest, so a same-id directory in
    the user-writable install dir must never silently replace them (that
    would swap the injected voice for unsigned text). A shadow attempt is
    warned about on stderr and ignored. Non-bundled ids resolve through the
    install dir — that's how toolspace preset packs stay selectable.

    Resolves to the first root containing a ``<preset_id>/`` directory so the
    missing-required-file diagnostics in :func:`load_preset` still fire on a
    present-but-incomplete preset directory.
    """
    bundled = _presets_root() / preset_id
    if bundled.is_dir():
        installed = installed_presets_dir() / preset_id
        if installed.is_dir():
            try:
                import sys

                print(
                    f"[yep presets] ignoring installed preset '{preset_id}' — "
                    "it shadows a bundled (integrity-signed) preset",
                    file=sys.stderr,
                )
            except Exception:  # pragma: no cover - defensive
                pass
        return bundled
    for root in _preset_dirs():
        cand = root / preset_id
        if cand.is_dir():
            return cand
    return None


def _read_text(base_dir: Path, name: str) -> str:
    """Read one file ``<base_dir>/<name>`` as UTF-8 text."""
    return (base_dir / name).read_text(encoding="utf-8")


def list_presets() -> list[str]:
    """Return the ids of all available presets (bundled + installed), sorted.

    A directory counts as a preset iff it contains a ``preset.toml`` — this skips
    ``__pycache__``, ``__init__.py``, the ``_packs`` content staging dir, and any
    stray files. Both the bundled package dir and the toolspace install dir
    (:func:`installed_presets_dir`) are scanned; an id present in both is listed
    once. This union is what makes a freshly-installed preset pack immediately
    selectable in the wizard and valid in ``agent.toml`` (PLAN.md §3 T3.11).
    """
    ids: set[str] = set()
    for root in _preset_dirs():
        if not root.is_dir():
            continue
        for child in root.iterdir():
            if child.is_dir() and (child / "preset.toml").is_file():
                ids.add(child.name)
    return sorted(ids)


def _normalize(text: str) -> str:
    """Lower-case + collapse all whitespace runs to single spaces.

    So the biography lint is robust to line-wrapping and markdown emphasis
    that would otherwise split a banned phrase across tokens.
    """
    return " ".join(text.lower().split())


def lint_biography(voice: str) -> list[str]:
    """Return the biography-assertion phrases found in ``voice`` (T3.8 #1).

    An empty list means the voice is biography-clean. Markdown emphasis markers
    are stripped so ``built *me*`` is still caught.
    """
    haystack = _normalize(voice).replace("*", "").replace("_", "")
    return [p for p in _BIOGRAPHY_PATTERNS if p in haystack]


def load_preset(preset_id: str) -> Preset:
    """Load (without full validation) the preset ``preset_id``.

    Raises :class:`PresetError` if the directory or any required file is
    missing, the TOML is malformed, or required keys are absent. For the full
    contract (legal dial values + biography lint) call :func:`validate_preset`.
    """
    pdir = _resolve_preset_dir(preset_id)
    if pdir is None:
        raise PresetError(f"preset {preset_id!r}: directory not found")

    missing = [f for f in _REQUIRED_FILES if not (pdir / f).is_file()]
    if missing:
        raise PresetError(
            f"preset {preset_id!r}: missing file(s): {', '.join(missing)}"
        )

    try:
        meta = tomllib.loads(_read_text(pdir, "preset.toml"))
    except tomllib.TOMLDecodeError as exc:
        raise PresetError(f"preset {preset_id!r}: preset.toml is not valid TOML: {exc}")
    try:
        dials_doc = tomllib.loads(_read_text(pdir, "dials.toml"))
    except tomllib.TOMLDecodeError as exc:
        raise PresetError(f"preset {preset_id!r}: dials.toml is not valid TOML: {exc}")

    pm = meta.get("preset")
    if not isinstance(pm, dict):
        raise PresetError(f"preset {preset_id!r}: preset.toml needs a [preset] table")

    for key in ("id", "display_name", "description"):
        if not isinstance(pm.get(key), str) or not pm[key].strip():
            raise PresetError(
                f"preset {preset_id!r}: preset.toml [preset].{key} "
                "must be a non-empty string"
            )
    if pm["id"] != preset_id:
        raise PresetError(
            f"preset {preset_id!r}: preset.toml [preset].id is "
            f"{pm['id']!r}; must equal the directory name"
        )
    paid = pm.get("paid", False)
    if not isinstance(paid, bool):
        raise PresetError(f"preset {preset_id!r}: [preset].paid must be a boolean")

    dials = dials_doc.get("dials")
    if not isinstance(dials, dict):
        raise PresetError(f"preset {preset_id!r}: dials.toml needs a [dials] table")
    dials = {k: v for k, v in dials.items()}

    voice = _read_text(pdir, "voice.md").strip()
    sample = _read_text(pdir, "sample.txt").strip()

    return Preset(
        id=preset_id,
        display_name=pm["display_name"].strip(),
        description=pm["description"].strip(),
        paid=paid,
        voice=voice,
        dials=dials,
        sample=sample,
    )


def validate_preset(preset_id: str) -> Preset:
    """Fully validate the preset ``preset_id`` and return it.

    Beyond :func:`load_preset`'s structural checks this asserts:

    * all six dials are present and every value is legal
      (:data:`DIAL_VALUES`), with errors naming the dial + allowed set;
    * ``voice.md`` is non-empty;
    * ``sample.txt`` is non-empty;
    * the voice carries NO biography assertion (T3.8 lint).

    Raises :class:`PresetError` on the first failure.
    """
    preset = load_preset(preset_id)

    missing_dials = [d for d in DIAL_NAMES if d not in preset.dials]
    if missing_dials:
        raise PresetError(
            f"preset {preset_id!r}: dials.toml missing dial(s): "
            f"{', '.join(missing_dials)}"
        )
    extra = [d for d in preset.dials if d not in DIAL_VALUES]
    if extra:
        raise PresetError(
            f"preset {preset_id!r}: dials.toml has unknown dial(s): "
            f"{', '.join(sorted(extra))}"
        )
    for dial in DIAL_NAMES:
        value = preset.dials[dial]
        allowed = DIAL_VALUES[dial]
        if value not in allowed:
            raise PresetError(
                f"preset {preset_id!r}: dial {dial!r}={value!r} is not legal; "
                f"allowed: {{{', '.join(allowed)}}}"
            )

    if not preset.voice:
        raise PresetError(f"preset {preset_id!r}: voice.md is empty")
    if not preset.sample:
        raise PresetError(f"preset {preset_id!r}: sample.txt is empty")

    found = lint_biography(preset.voice)
    if found:
        raise PresetError(
            f"preset {preset_id!r}: voice.md asserts a day-one relationship "
            f"(biography). Offending phrase(s): {', '.join(repr(f) for f in found)}. "
            "Presets carry VOICE, never BIOGRAPHY — the bond forms through memory."
        )

    return preset
