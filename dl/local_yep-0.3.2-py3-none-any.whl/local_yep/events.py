"""The activity ledger — a local, append-only record of what the agent did.

PLAN §8 T8.1. This is the "track" half of Activity Tracking & Notifications.

Before this module, Local Yep's idea of tracking was five write-only sinks with
no reader and no timeline: ``memory.db`` episodes (written only when a Stop-hook
transcript tail matched git/PR patterns), ``audit.log`` (append-only text),
``last_hook_error.json`` (a **single slot** — error #2 erased error #1),
``continuity/<slug>.json`` and ``stop_history/`` (single-slot, for the next
session rather than for the human). ``yepgent doctor`` could report a moment; it
could not report a history.

Design decisions worth keeping:

- **A separate database.** The ledger lives in ``~/.local-yep/events.db``, NOT
  in ``memory.db``. Activity is high-volume, prunable, and time-ordered;
  memory is precious, curated, and semantically recalled. Mixing them would
  pollute the recall corpus and compete for the ambient ``<memory>`` budget.
  Nothing in :mod:`local_yep.memory` reads this file.

- **Fail-open, always.** :func:`emit` never raises, never blocks, and never
  breaks a session. A ledger bug must be less harmful than no ledger.

- **Cheap in-band.** A hook pays one INSERT. Delivery of notifications (§8
  T8.5/T8.6) happens out of process and is deliberately not implemented here.

- **Muting suppresses DELIVERY, never the LEDGER.** This is the load-bearing
  promise of §8. :func:`emit` records a row unconditionally; when a mute is in
  force it records *why* delivery was suppressed in ``suppressed_reason`` so
  the user can always see what they missed. Nothing in this module can be
  configured to drop an event on the floor.

The store is 100% local. Nothing here phones home.
"""

from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from local_yep import home

#: Env override for the ledger path (tests, and power users with odd homes).
ENV_EVENTS_DB = "YEPGENT_EVENTS_DB"

#: Default retention. Pruning happens in the CLI, never in a hook.
DEFAULT_KEEP_DAYS = 30

#: Ordered severity ladder. Anything unrecognised is treated as ``info``.
SEVERITIES: tuple[str, ...] = ("debug", "info", "warn", "error")

_SEVERITY_RANK: dict[str, int] = {s: i for i, s in enumerate(SEVERITIES)}

#: Longest body we will store. The ledger is a record, not a log sink; a
#: multi-megabyte traceback belongs in a file, not in every future query.
_MAX_BODY = 4000
_MAX_TITLE = 500

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_utc            TEXT    NOT NULL,
    session_id        TEXT    NOT NULL DEFAULT '',
    project           TEXT    NOT NULL DEFAULT '',
    event             TEXT    NOT NULL,
    category          TEXT    NOT NULL DEFAULT 'general',
    severity          TEXT    NOT NULL DEFAULT 'info',
    title             TEXT    NOT NULL DEFAULT '',
    body              TEXT    NOT NULL DEFAULT '',
    meta_json         TEXT    NOT NULL DEFAULT '{}',
    delivered         INTEGER NOT NULL DEFAULT 0,
    suppressed_reason TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events (ts_utc);
CREATE INDEX IF NOT EXISTS idx_events_cat ON events (category, ts_utc);
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

#: Bump when the table shape changes in a way readers must know about.
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Paths & connection
# ---------------------------------------------------------------------------

def events_db_path() -> Path:
    """Resolve the ledger path, honouring :data:`ENV_EVENTS_DB`."""
    override = os.environ.get(ENV_EVENTS_DB, "").strip()
    if override:
        return Path(override)
    return home.HOME / "events.db"


def _connect(path: Path | None = None) -> sqlite3.Connection:
    """Open (and if needed create) the ledger. Caller owns closing it."""
    p = path or events_db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(p), timeout=2.0)
    conn.row_factory = sqlite3.Row
    conn.executescript(_SCHEMA)
    conn.execute(
        "INSERT OR IGNORE INTO meta (key, value) VALUES ('schema_version', ?)",
        (str(SCHEMA_VERSION),),
    )
    conn.commit()
    return conn


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clamp(text: Any, limit: int) -> str:
    s = "" if text is None else str(text)
    if len(s) <= limit:
        return s
    return s[: limit - 1] + "…"


def _norm_severity(severity: str | None) -> str:
    s = (severity or "info").strip().lower()
    return s if s in _SEVERITY_RANK else "info"


def severity_at_least(severity: str, floor: str) -> bool:
    """True when ``severity`` is at or above ``floor`` on the ladder."""
    return _SEVERITY_RANK.get(_norm_severity(severity), 1) >= _SEVERITY_RANK.get(
        _norm_severity(floor), 1
    )


# ---------------------------------------------------------------------------
# Write
# ---------------------------------------------------------------------------

def emit(
    event: str,
    title: str = "",
    *,
    category: str = "general",
    severity: str = "info",
    body: str = "",
    session_id: str = "",
    project: str = "",
    meta: dict | None = None,
    db_path: Path | None = None,
) -> int | None:
    """Record one activity event. Returns the row id, or ``None`` on failure.

    **Never raises.** Hooks call this in-band, so a ledger problem must degrade
    to "no row written" rather than to a broken session.

    The event is recorded whether or not notifications are muted; if a mute is
    in force, ``suppressed_reason`` explains why nothing was delivered. That
    asymmetry is the point — see the module docstring.
    """
    try:
        if not event:
            return None
        payload = "{}"
        if meta:
            try:
                payload = json.dumps(meta, ensure_ascii=False, default=str)
            except Exception:
                payload = "{}"

        try:
            suppressed = mute_reason()
        except Exception:
            suppressed = ""

        conn = _connect(db_path)
        try:
            cur = conn.execute(
                "INSERT INTO events (ts_utc, session_id, project, event, category,"
                " severity, title, body, meta_json, delivered, suppressed_reason)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)",
                (
                    _now_iso(),
                    _clamp(session_id, 200),
                    _clamp(project, 500),
                    _clamp(event, 100),
                    _clamp(category or "general", 100),
                    _norm_severity(severity),
                    _clamp(title, _MAX_TITLE),
                    _clamp(body, _MAX_BODY),
                    payload,
                    suppressed,
                ),
            )
            conn.commit()
            return int(cur.lastrowid)
        finally:
            conn.close()
    except Exception:
        # Fail-open by design. A ledger that can break a session is worse than
        # no ledger at all.
        return None


def mark_delivered(row_id: int, *, db_path: Path | None = None) -> None:
    """Flag a row as delivered by a notification channel. Best-effort."""
    try:
        conn = _connect(db_path)
        try:
            conn.execute("UPDATE events SET delivered = 1 WHERE id = ?", (row_id,))
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

def parse_since(spec: str | None) -> str | None:
    """Turn ``24h`` / ``7d`` / ``30m`` / an ISO stamp into an ISO lower bound.

    Returns ``None`` when ``spec`` is empty or unparseable (meaning "no bound"),
    so a typo widens the query rather than silently emptying it.
    """
    if not spec:
        return None
    s = str(spec).strip().lower()
    units = {"m": "minutes", "h": "hours", "d": "days", "w": "weeks"}
    if len(s) >= 2 and s[-1] in units and s[:-1].replace(".", "", 1).isdigit():
        try:
            amount = float(s[:-1])
        except ValueError:
            return None
        delta = timedelta(**{units[s[-1]]: amount})
        return (datetime.now(timezone.utc) - delta).isoformat(timespec="seconds")
    try:
        return datetime.fromisoformat(s).isoformat(timespec="seconds")
    except ValueError:
        return None


def query(
    *,
    since: str | None = None,
    project: str | None = None,
    category: str | None = None,
    severity: str | None = None,
    event: str | None = None,
    limit: int = 100,
    db_path: Path | None = None,
) -> list[dict]:
    """Read events newest-first. Returns ``[]`` rather than raising."""
    try:
        clauses: list[str] = []
        params: list[Any] = []
        bound = parse_since(since)
        if bound:
            clauses.append("ts_utc >= ?")
            params.append(bound)
        if project:
            clauses.append("project LIKE ?")
            params.append(f"%{project}%")
        if category:
            clauses.append("category = ?")
            params.append(category)
        if event:
            clauses.append("event = ?")
            params.append(event)
        if severity:
            floor = _SEVERITY_RANK.get(_norm_severity(severity), 1)
            allowed = [s for s in SEVERITIES if _SEVERITY_RANK[s] >= floor]
            clauses.append(
                "severity IN (%s)" % ",".join("?" for _ in allowed)
            )
            params.extend(allowed)

        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = (
            "SELECT id, ts_utc, session_id, project, event, category, severity,"
            " title, body, meta_json, delivered, suppressed_reason"
            f" FROM events{where} ORDER BY ts_utc DESC, id DESC LIMIT ?"
        )
        params.append(max(1, int(limit)))

        conn = _connect(db_path)
        try:
            rows = conn.execute(sql, params).fetchall()
        finally:
            conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def counts_by_category(
    *, since: str | None = None, db_path: Path | None = None
) -> list[tuple[str, int]]:
    """``[(category, n), ...]`` descending. Used by ``doctor`` and digests."""
    try:
        bound = parse_since(since)
        sql = "SELECT category, COUNT(*) AS n FROM events"
        params: list[Any] = []
        if bound:
            sql += " WHERE ts_utc >= ?"
            params.append(bound)
        sql += " GROUP BY category ORDER BY n DESC"
        conn = _connect(db_path)
        try:
            return [(r["category"], int(r["n"])) for r in conn.execute(sql, params)]
        finally:
            conn.close()
    except Exception:
        return []


def suppressed_since(
    ts_iso: str | None, *, db_path: Path | None = None
) -> list[dict]:
    """Events recorded with a suppression reason since ``ts_iso``.

    This is what the digest-on-unmute reads: the buzzing stopped, the record
    did not, and the user gets one line telling them what they missed.
    """
    try:
        sql = (
            "SELECT id, ts_utc, event, category, severity, title, suppressed_reason"
            " FROM events WHERE suppressed_reason != ''"
        )
        params: list[Any] = []
        if ts_iso:
            sql += " AND ts_utc >= ?"
            params.append(ts_iso)
        sql += " ORDER BY ts_utc ASC"
        conn = _connect(db_path)
        try:
            return [dict(r) for r in conn.execute(sql, params)]
        finally:
            conn.close()
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Retention
# ---------------------------------------------------------------------------

def prune(
    keep_days: int = DEFAULT_KEEP_DAYS, *, db_path: Path | None = None
) -> int:
    """Delete events older than ``keep_days``. Returns rows removed.

    Called by the CLI, never by a hook — retention work must not land on a
    user's turn latency.
    """
    try:
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=max(0, int(keep_days)))
        ).isoformat(timespec="seconds")
        conn = _connect(db_path)
        try:
            cur = conn.execute("DELETE FROM events WHERE ts_utc < ?", (cutoff,))
            conn.commit()
            return int(cur.rowcount or 0)
        finally:
            conn.close()
    except Exception:
        return 0


def stats(*, db_path: Path | None = None) -> dict:
    """Small summary for ``yepgent doctor``. Never raises."""
    try:
        conn = _connect(db_path)
        try:
            total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            oldest = conn.execute("SELECT MIN(ts_utc) FROM events").fetchone()[0]
            newest = conn.execute("SELECT MAX(ts_utc) FROM events").fetchone()[0]
            suppressed = conn.execute(
                "SELECT COUNT(*) FROM events WHERE suppressed_reason != ''"
            ).fetchone()[0]
        finally:
            conn.close()
        return {
            "total": int(total or 0),
            "oldest": oldest or "",
            "newest": newest or "",
            "suppressed": int(suppressed or 0),
            "path": str(events_db_path()),
        }
    except Exception:
        return {"total": 0, "oldest": "", "newest": "", "suppressed": 0,
                "path": str(events_db_path())}


# ---------------------------------------------------------------------------
# Mute state (§8 T8.7 core)
# ---------------------------------------------------------------------------
# Delivery channels land in T8.5/T8.6. The mute *state* lives here because the
# ledger is what must record a suppression, and because the invariant worth
# testing from day one is: a mute changes delivery and nothing else.

MUTE_KEY = "muted_until"
MUTE_SCOPE_KEY = "mute_scope"

#: Sentinel stored in ``meta`` for an indefinite mute.
MUTE_FOREVER = "forever"


def _meta_get(key: str, *, db_path: Path | None = None) -> str:
    try:
        conn = _connect(db_path)
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
            return str(row["value"]) if row else ""
        finally:
            conn.close()
    except Exception:
        return ""


def _meta_set(key: str, value: str, *, db_path: Path | None = None) -> None:
    try:
        conn = _connect(db_path)
        try:
            conn.execute(
                "INSERT INTO meta (key, value) VALUES (?, ?)"
                " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def mute(until_iso: str | None, *, scope: str = "", db_path: Path | None = None) -> None:
    """Silence *delivery* until ``until_iso`` (or :data:`MUTE_FOREVER`).

    The ledger keeps recording. That is not a bug to be fixed later; it is the
    §8 promise.
    """
    _meta_set(MUTE_KEY, until_iso or MUTE_FOREVER, db_path=db_path)
    _meta_set(MUTE_SCOPE_KEY, scope or "", db_path=db_path)


def unmute(*, db_path: Path | None = None) -> None:
    """Resume delivery."""
    _meta_set(MUTE_KEY, "", db_path=db_path)
    _meta_set(MUTE_SCOPE_KEY, "", db_path=db_path)


def mute_reason(*, db_path: Path | None = None) -> str:
    """Why delivery is currently suppressed, or ``''`` when not muted.

    An expired mute is simply not in force — note that we do NOT rewrite the
    stored value here. Refreshing mute state as a side effect of *checking* it
    is how a cooldown ends up extending itself indefinitely; the check stays
    pure and only an explicit verb changes state.
    """
    raw = _meta_get(MUTE_KEY, db_path=db_path)
    if not raw:
        return ""
    if raw == MUTE_FOREVER:
        return "muted (indefinitely)"
    try:
        until = datetime.fromisoformat(raw)
    except ValueError:
        return ""
    if until.tzinfo is None:
        until = until.replace(tzinfo=timezone.utc)
    if datetime.now(timezone.utc) >= until:
        return ""
    return f"muted until {until.isoformat(timespec='seconds')}"


def is_muted(*, db_path: Path | None = None) -> bool:
    return bool(mute_reason(db_path=db_path))


__all__: Iterable[str] = (
    "emit",
    "query",
    "counts_by_category",
    "suppressed_since",
    "prune",
    "stats",
    "mark_delivered",
    "parse_since",
    "severity_at_least",
    "mute",
    "unmute",
    "mute_reason",
    "is_muted",
    "events_db_path",
    "SEVERITIES",
    "DEFAULT_KEEP_DAYS",
    "MUTE_FOREVER",
)
