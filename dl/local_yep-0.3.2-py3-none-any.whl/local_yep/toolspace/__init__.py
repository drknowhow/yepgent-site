"""Local Yep Toolspace (PLAN.md §4).

The install-manifest loader, premium entitlement client, registry discovery and
the MCP tool surface for discovering + installing pre-built tools/packs.

This package is intentionally light at import time: submodules
(:mod:`local_yep.toolspace.entitlement`, ``loader``, ``discovery`` …) are
imported on demand so the free core never pulls optional/heavy dependencies
(e.g. the ``[pro]`` crypto extra) just by importing the package.
"""

__all__: list[str] = []
