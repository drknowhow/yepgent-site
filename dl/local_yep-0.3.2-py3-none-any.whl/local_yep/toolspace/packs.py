"""Preset packs — installing a voice preset through the toolspace (PLAN.md T3.11).

A *preset pack* is a personality preset (the four files :mod:`local_yep.presets`
expects: ``preset.toml`` / ``voice.md`` / ``dials.toml`` / ``sample.txt``)
delivered as an install-manifest v0.4 document and materialized into the
toolspace install dir ``~/.local-yep/presets/<id>/`` (see
:func:`local_yep.presets.installed_presets_dir`). Once materialized it is
immediately selectable by the ``yepgent`` identity wizard and a legal
``agent.toml`` ``preset`` value — *without* touching the frozen spine.

Why a dedicated installer (not the generic tool loader)?
-------------------------------------------------------
The generic :func:`local_yep.toolspace.loader.install` builds *runnable tools*
(per-tool venv, smoke gate, registered actions). A preset is **content**, not a
runtime, so installing it = copying four validated files into the presets home.
The pack still rides the v0.4 manifest so it gets the same disclosure surface
(identity, license, cost block) and the same entitlement gate as any other
premium artifact:

* **Free preset packs** ship the content inside the package (``runtime.install.
  method = "preinstalled"``, content under ``local_yep/presets/_packs/<id>/``)
  and install with **no gating and no network**.
* **Paid preset packs** are ``license = "PROPRIETARY"`` and/or carry a non-zero
  ``cost`` block. They **fail closed without a valid entitlement** — the
  authoritative paywall remains the gated premium-manifest fetch (the cost block
  is consent *disclosure*, not local DRM). Their curated content is delivered as
  a private bundle via that gated endpoint, which is **scaffolded, not deployed**
  (see ``docs/deploy-monetization.md``); installing entitled paid content from a
  remote source is therefore intentionally not wired in this local build.

Recognition is by the manifest tag :data:`PRESET_PACK_TAG`. Materialization is
fail-closed and path-confined: the preset id is pattern-checked and the write
target is asserted to live inside the presets home, so a manifest can never
write outside ``~/.local-yep/presets/`` (and never near ``spine.md``).
"""
from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

from local_yep import presets as _presets
from local_yep.toolspace import discovery, loader

__all__ = [
    "PRESET_PACK_TAG",
    "PresetPackError",
    "is_preset_pack",
    "pack_preset_id",
    "install_preset_pack",
]

#: Manifests carry this tag in ``tool.tags`` to declare themselves a preset pack.
PRESET_PACK_TAG = "preset-pack"

#: Bundled staging dir for FREE preset-pack content (NOT auto-listed by
#: :func:`local_yep.presets.list_presets`, which only scans top-level dirs).
_PACKS_SUBDIR = "_packs"

#: A legal preset id (mirrors the v0.4 schema ``tool.id`` shape). Doubles as the
#: path-traversal guard — no ``/``, ``\\``, ``.`` or ``..`` can slip through.
_PRESET_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$")


class PresetPackError(RuntimeError):
    """A manifest is not a valid/installable preset pack, or install failed."""


# --------------------------------------------------------------------------- #
# Manifest classification
# --------------------------------------------------------------------------- #
def is_preset_pack(doc: dict[str, Any]) -> bool:
    """True iff ``doc`` declares itself a preset pack (``preset-pack`` tag)."""
    tool = (doc or {}).get("tool") or {}
    tags = tool.get("tags") or []
    return isinstance(tags, (list, tuple)) and PRESET_PACK_TAG in tags


def pack_preset_id(doc: dict[str, Any]) -> str:
    """The preset id a pack installs as — its ``tool.id``.

    Raises :class:`PresetPackError` if absent or not a legal preset id (the same
    check guards against path traversal in the install target).
    """
    tool = (doc or {}).get("tool") or {}
    pid = tool.get("id")
    if not isinstance(pid, str) or not _PRESET_ID_RE.match(pid):
        raise PresetPackError(
            f"preset pack tool.id {pid!r} is not a legal preset id "
            "(lowercase, hyphenated, 3-64 chars)"
        )
    return pid


# --------------------------------------------------------------------------- #
# Source resolution
# --------------------------------------------------------------------------- #
def _install_method(doc: dict[str, Any]) -> str | None:
    return ((doc.get("runtime") or {}).get("install") or {}).get("method")


def _bundled_pack_source(preset_id: str) -> Path | None:
    """The bundled content dir for a FREE preset pack, or ``None`` if absent."""
    cand = _presets._presets_root() / _PACKS_SUBDIR / preset_id
    if cand.is_dir() and (cand / "preset.toml").is_file():
        return cand
    return None


def _resolve_pack_source(doc: dict[str, Any], preset_id: str) -> Path:
    """Return the directory holding the pack's four preset files.

    * ``method = "preinstalled"`` → the bundled ``_packs/<id>/`` content (free).
    * Any other method (e.g. ``git`` for a curated private bundle) is the gated
      premium-delivery path, which is scaffolded but not deployed — raise a clear
      error rather than pretend to fetch it. (Unreachable for an un-entitled paid
      pack, which fails closed at the entitlement gate first.)
    """
    method = _install_method(doc)
    if method == "preinstalled":
        src = _bundled_pack_source(preset_id)
        if src is None:
            raise PresetPackError(
                f"preset pack {preset_id!r} declares method='preinstalled' but no "
                f"bundled content was found under presets/{_PACKS_SUBDIR}/{preset_id}/"
            )
        return src
    raise PresetPackError(
        f"preset pack {preset_id!r} uses install.method={method!r}: premium preset "
        "content is delivered as a curated private bundle via the gated premium "
        "endpoint, which is scaffolded but not deployed in this build "
        "(see docs/deploy-monetization.md). Only 'preinstalled' (bundled, free) "
        "preset packs install from this local path."
    )


# --------------------------------------------------------------------------- #
# Materialization (path-confined, atomic, spine-safe)
# --------------------------------------------------------------------------- #
def _materialize(src: Path, target_root: Path, preset_id: str) -> Path:
    """Copy the four preset files from ``src`` into ``target_root/<preset_id>/``.

    Atomic-ish: stage into a temp dir under ``target_root`` then swap into place.
    Asserts the resolved target lives inside ``target_root`` (defence in depth on
    top of the id pattern check) so a pack can never escape the presets home.
    """
    missing = [f for f in _presets._REQUIRED_FILES if not (src / f).is_file()]
    if missing:
        raise PresetPackError(
            f"preset pack {preset_id!r} source is incomplete; missing: "
            f"{', '.join(missing)}"
        )

    target_root = target_root.resolve()
    dest = (target_root / preset_id).resolve()
    # Path-confinement: dest must be a direct child of target_root.
    if dest.parent != target_root:
        raise PresetPackError(
            f"refusing to install preset {preset_id!r} outside the presets home"
        )

    target_root.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{preset_id}.", dir=target_root))
    try:
        for name in _presets._REQUIRED_FILES:
            shutil.copy2(src / name, staging / name)
        # Swap: remove any prior copy, then move staging into place.
        if dest.exists():
            shutil.rmtree(dest, ignore_errors=True)
        staging.replace(dest)
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
    return dest


# --------------------------------------------------------------------------- #
# Public install entry
# --------------------------------------------------------------------------- #
def install_preset_pack(
    doc_or_url: Any,
    *,
    confirm: "loader.ConfirmFn | None" = None,
) -> dict[str, Any]:
    """Install a preset pack from a manifest dict or URL.

    Flow: resolve doc (premium fetch attaches the entitlement bearer; a gated
    HTTP 402 becomes a purchase-required result) → validate against the v0.4
    schema → compatibility fence → confirm it is a preset pack → **entitlement
    gate** (premium-without-entitlement fails closed with a purchase-required
    result, installing nothing) → copy the four preset files into the presets
    home → validate the installed preset.

    Returns one of::

        {"ok": True, "installed_preset": "<id>", "selectable": True, ...}  # done
        {"ok": True, "purchase_required": True, "price": {...}, ...}        # gated

    Never modifies the frozen spine. ``confirm`` is accepted for API symmetry
    with the tool loader (used only by the gated premium-delivery path, which is
    not wired locally).
    """
    del confirm  # only the (non-local) gated premium-delivery path would use it

    # 1. Resolve the manifest. A premium URL fetch attaches the bearer header in
    #    the loader; a gated 402 is surfaced as purchase-required (not an error).
    if isinstance(doc_or_url, str):
        url: str | None = doc_or_url
        try:
            doc = loader.fetch_manifest(doc_or_url)
        except loader.PaymentRequiredError as exc:
            return discovery._purchase_required_from_http(doc_or_url, exc)
    elif isinstance(doc_or_url, dict):
        doc, url = doc_or_url, None
    else:
        raise TypeError(
            "install_preset_pack takes a manifest dict or URL str, got "
            f"{type(doc_or_url).__name__}"
        )

    # 2. Schema validation (fail-closed) — the loader's bundled v0.4 validator.
    result = loader.validate_manifest(doc)
    if not result.get("ok"):
        errs = "; ".join(
            f"{e.get('pointer')}: {e.get('message')}" for e in result.get("errors", [])
        )
        raise loader.ValidationError(
            f"preset pack manifest failed v0.4 schema validation: {errs or 'invalid'}",
            phase="validate",
            retryable=False,
        )

    # 3. Compatibility fence (T4.7) — refuse any we-run-a-service shape.
    loader._compatibility_fence(doc)

    # 4. Must actually be a preset pack.
    if not is_preset_pack(doc):
        raise PresetPackError(
            f"manifest is not a preset pack (missing the {PRESET_PACK_TAG!r} tag "
            "in tool.tags); use install_tool for runnable tools"
        )
    preset_id = pack_preset_id(doc)

    # 5. Entitlement gate — premium pack without a valid entitlement fails closed
    #    (installs nothing). Free packs return None and proceed.
    pr = discovery.purchase_required(doc, url=url)
    if pr is not None:
        return pr

    # 6. Resolve source + materialize into the presets home (path-confined).
    src = _resolve_pack_source(doc, preset_id)
    target_root = _presets.installed_presets_dir()
    dest = _materialize(src, target_root, preset_id)

    # 7. Validate the just-installed preset (the installed copy now wins on
    #    resolution) so a broken pack never silently becomes selectable.
    try:
        preset = _presets.validate_preset(preset_id)
    except _presets.PresetError as exc:
        shutil.rmtree(dest, ignore_errors=True)
        raise PresetPackError(
            f"installed preset pack {preset_id!r} failed validation and was "
            f"rolled back: {exc}"
        ) from exc

    return {
        "ok": True,
        "installed_preset": preset_id,
        "display_name": preset.display_name,
        "paid": bool(preset.paid),
        "path": str(dest),
        "selectable": preset_id in _presets.list_presets(),
    }
