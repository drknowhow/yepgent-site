"""Bundled reference tools (Model B / P5). These ship inside the package so a
`preinstalled` manifest can register them without a network fetch — the first
worked example of an OAuth tool (`google_calendar`)."""
