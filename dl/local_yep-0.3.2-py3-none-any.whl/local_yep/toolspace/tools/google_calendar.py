"""Reference OAuth tool: Google Calendar (read-only) — the first worked example
of Model B end-to-end (PLAN.md §6 / P5, T6.8).

It reads a Google access token from the ``GOOGLE_ACCESS_TOKEN`` environment
variable (injected by the loader from the OS keyring at call time — never argv,
never logged) and lists upcoming events from the user's calendar via the Google
Calendar REST API. The user authorizes once with their OWN Google Cloud OAuth
client: ``yepgent tools auth google-calendar`` (see docs/oauth-google-setup.md).

Invoked as a local subprocess (``python -m
local_yep.toolspace.tools.google_calendar list-events``); prints a JSON result on
stdout. No third-party dependency — stdlib ``urllib`` only.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

_API = "https://www.googleapis.com/calendar/v3"
_TIMEOUT_S = 30


def _list_events(token: str, calendar_id: str, max_results: int) -> dict:
    params = {
        "maxResults": str(max_results),
        "orderBy": "startTime",
        "singleEvents": "true",
        # The caller can set GOOGLE_CALENDAR_TIME_MIN; default is "now" server-side
        # when omitted, so we leave it out unless provided.
    }
    time_min = os.environ.get("GOOGLE_CALENDAR_TIME_MIN")
    if time_min:
        params["timeMin"] = time_min
    url = f"{_API}/calendars/{urllib.parse.quote(calendar_id)}/events?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(
        url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=_TIMEOUT_S) as resp:
        data = json.loads(resp.read().decode("utf-8") or "{}")
    events = [
        {
            "id": e.get("id"),
            "summary": e.get("summary"),
            "start": (e.get("start") or {}).get("dateTime") or (e.get("start") or {}).get("date"),
            "end": (e.get("end") or {}).get("dateTime") or (e.get("end") or {}).get("date"),
        }
        for e in (data.get("items") or [])
    ]
    return {"calendar": calendar_id, "count": len(events), "events": events}


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    action = argv[0] if argv else "list-events"
    token = os.environ.get("GOOGLE_ACCESS_TOKEN")
    if not token:
        # The loader injects this from the keyring; its absence means the tool was
        # invoked without an authorized OAuth token.
        print(json.dumps({"error": "missing GOOGLE_ACCESS_TOKEN — run `yepgent tools auth google-calendar`"}))
        return 2
    calendar_id = os.environ.get("GOOGLE_CALENDAR_ID", "primary")
    try:
        max_results = int(os.environ.get("GOOGLE_CALENDAR_MAX", "10"))
    except ValueError:
        max_results = 10

    if action != "list-events":
        print(json.dumps({"error": f"unknown action {action!r}; expected 'list-events'"}))
        return 2
    try:
        result = _list_events(token, calendar_id, max_results)
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8")[:300]
        except Exception:
            pass
        print(json.dumps({"error": f"Google API HTTP {e.code}", "detail": body}))
        return 1
    except urllib.error.URLError as e:
        print(json.dumps({"error": f"could not reach Google API: {e.reason}"}))
        return 1
    print(json.dumps(result))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised as a subprocess
    raise SystemExit(main())
