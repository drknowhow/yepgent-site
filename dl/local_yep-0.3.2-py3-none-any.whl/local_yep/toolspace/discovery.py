"""Toolspace discovery + free/paid install UX (PLAN.md §4 · T4.12 / P3-WIRE).

Two discovery surfaces, one ranked answer:

* the **local installed-tools index** — :func:`local_yep.toolspace.loader.list_installed`
  (rehydrated from ``~/.local-yep/installed.json``), and
* the **toolspace REGISTRY** — the static, CORS-open ``manifests.json`` published
  by the toolspace site (``toolspace-site``). It is fetched read-only with a
  small TTL cache and **no auth** (discovery is never gated); a network failure
  degrades to "registry unavailable", never an error.

:func:`tool_search` ranks both by a simple lexical match over name / id /
description / tags and returns *installable* (registry) + *installed* tools.

This module deliberately does NOT port the cloud build's Supabase ``tools`` table
or pgvector semantic index — discovery here is registry + local-index based, in
keeping with the decided scope (no we-run-a-service dependency).

Free-vs-paid install UX (T4.12)
-------------------------------
:func:`install_tool` is the UX-aware wrapper over
:func:`local_yep.toolspace.loader.install`:

* a **free / public** manifest installs with no entitlement check and no auth
  header (the loader's free path);
* a **premium** manifest (``tool.license == "PROPRIETARY"`` or a non-zero
  ``cost`` fee) attempted with **no usable entitlement** returns a structured
  **purchase-required RESULT** (``{ok: True, purchase_required: True, …}``) — the
  price + estimate from the manifest's ``cost`` block — rather than an error;
* a gated host that answers **HTTP 402** (:class:`loader.PaymentRequiredError`)
  is likewise treated as *purchasable-not-broken* and surfaced with whatever
  price the server disclosed.

The real paywall is enforced **server-side** at the gated fetch; this client adds
no local DRM. The local premium check exists only so a user who has not bought
the tool sees a clear, actionable "purchase required" instead of a confusing
auth/approval failure.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from typing import Any

from local_yep.toolspace import loader

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

#: The static, CORS-open toolspace registry index. Override for staging/tests via
#: the ``LOCAL_YEP_REGISTRY_URL`` env var. Discovery-only: fetched read-only with
#: no Authorization header (the registry is never gated).
DEFAULT_REGISTRY_URL = "https://toolspace.yepgent.com/manifests.json"

#: TTL for the in-process registry cache, in seconds. Override via
#: ``LOCAL_YEP_REGISTRY_TTL``.
DEFAULT_REGISTRY_TTL_SECONDS = 300

#: Registry fetch HTTP timeout.
_HTTP_TIMEOUT_S = 10

_ENV_REGISTRY_URL = "LOCAL_YEP_REGISTRY_URL"
_ENV_REGISTRY_TTL = "LOCAL_YEP_REGISTRY_TTL"


def registry_url() -> str:
    """The toolspace registry index URL (env-overridable)."""
    return os.environ.get(_ENV_REGISTRY_URL, "").strip() or DEFAULT_REGISTRY_URL


def _registry_ttl() -> float:
    raw = os.environ.get(_ENV_REGISTRY_TTL, "").strip()
    if raw:
        try:
            return float(raw)
        except ValueError:
            pass
    return float(DEFAULT_REGISTRY_TTL_SECONDS)


# ---------------------------------------------------------------------------
# Registry fetch + TTL cache (discovery-only, no auth)
# ---------------------------------------------------------------------------
#
# `_CACHE` maps a registry URL -> (fetched_at_monotonic, entries). A failed
# fetch is NOT cached (so a transient network blip self-heals on the next call);
# discovery degrades to the local index alone.

_CACHE: dict[str, tuple[float, list[dict[str, Any]]]] = {}


def clear_registry_cache() -> None:
    """Drop the in-process registry cache. Test/ops hook."""
    _CACHE.clear()


def _http_get_json(url: str, *, timeout: float = _HTTP_TIMEOUT_S) -> Any:
    """GET ``url`` and parse JSON. The sole network seam — tests monkeypatch this
    to run fully offline. NO Authorization header is ever sent (discovery is not
    gated). Raises on transport / decode error (the caller degrades to ``[]``)."""
    req = urllib.request.Request(
        url, headers={"User-Agent": "local-yep-toolspace-discovery/0.1"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        body = resp.read()
    return json.loads(body.decode("utf-8"))


def _normalize_registry(payload: Any) -> list[dict[str, Any]]:
    """Pull the ``manifests[]`` array out of a registry document.

    Tolerates either the full registry doc (``{"manifests": [...]}``) or a bare
    array of manifest entries. Non-dict entries are dropped."""
    if isinstance(payload, dict):
        items = payload.get("manifests")
    else:
        items = payload
    if not isinstance(items, list):
        return []
    return [m for m in items if isinstance(m, dict)]


def fetch_registry(
    *, url: str | None = None, force: bool = False, ttl: float | None = None
) -> list[dict[str, Any]]:
    """Return the registry's ``manifests[]`` list (TTL-cached, no auth).

    On any network/parse failure returns ``[]`` (registry unavailable) — never
    raises, so discovery always degrades gracefully to the local index alone.
    Pass ``force=True`` to bypass the cache."""
    u = url or registry_url()
    ttl_s = _registry_ttl() if ttl is None else ttl
    now = time.monotonic()
    if not force:
        cached = _CACHE.get(u)
        if cached is not None and (now - cached[0]) < ttl_s:
            return cached[1]
    try:
        entries = _normalize_registry(_http_get_json(u))
    except (urllib.error.URLError, OSError, ValueError, json.JSONDecodeError):
        return []
    except Exception:  # noqa: BLE001 - discovery must never hard-fail on the registry
        return []
    _CACHE[u] = (now, entries)
    return entries


# ---------------------------------------------------------------------------
# Local installed-tools index
# ---------------------------------------------------------------------------


def installed_index() -> list[dict[str, Any]]:
    """The local installed-tools index (public registry entries from the loader)."""
    return loader.list_installed()


# ---------------------------------------------------------------------------
# Lexical ranking
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[^a-z0-9]+")


def _tokenize(text: str) -> list[str]:
    return [t for t in _TOKEN_RE.split((text or "").lower()) if t]


def _lexical_score(
    query: str,
    *,
    name: str = "",
    ident: str = "",
    summary: str = "",
    tags: Any = None,
) -> float:
    """A simple, deterministic lexical score: per query token, a hit in the
    name/id weighs most, then tags, then the description. A whole-query substring
    in the name/id adds a phrase bonus. Returns 0.0 for an empty query (caller
    treats that as "match all")."""
    q = (query or "").strip().lower()
    qtokens = _tokenize(q)
    if not qtokens:
        return 0.0
    name_l = (name or "").lower()
    id_l = (ident or "").lower()
    summary_l = (summary or "").lower()
    tag_list = tags if isinstance(tags, (list, tuple, set)) else ([tags] if tags else [])
    tags_l = " ".join(str(t).lower() for t in tag_list)
    score = 0.0
    for tok in qtokens:
        if tok in name_l:
            score += 3.0
        if tok in id_l:
            score += 3.0
        if tok in tags_l:
            score += 2.0
        if tok in summary_l:
            score += 1.0
    if q and (q in name_l or q in id_l):
        score += 2.0
    return score


def _installed_result(entry: dict[str, Any], query: str) -> dict[str, Any]:
    tool_id = entry.get("tool_id")
    name = entry.get("name") or tool_id or ""
    summary = entry.get("summary") or ""
    tags = entry.get("capabilities") or []
    return {
        "id": tool_id,
        "name": name,
        "summary": summary,
        "source": "installed",
        "installed": True,
        "manifest_version": None,
        "manifest_url": None,
        "tags": list(tags),
        "method": entry.get("method"),
        "actions": entry.get("actions") or [],
        "version": entry.get("version"),
        "score": _lexical_score(
            query, name=name, ident=str(tool_id or ""), summary=summary, tags=tags
        ),
    }


def _registry_result(
    entry: dict[str, Any], query: str, *, installed: bool
) -> dict[str, Any]:
    ident = entry.get("id")
    name = entry.get("name") or ident or ""
    summary = entry.get("description") or entry.get("summary") or ""
    tags = entry.get("capabilities") or entry.get("tags") or []
    return {
        "id": ident,
        "name": name,
        "summary": summary,
        "source": "registry",
        "installed": installed,
        "manifest_version": entry.get("manifest_version"),
        "manifest_url": entry.get("manifest_url"),
        "registry_source": entry.get("source"),
        "status": entry.get("status"),
        "tags": list(tags) if isinstance(tags, (list, tuple)) else [tags],
        "score": _lexical_score(
            query, name=name, ident=str(ident or ""), summary=summary, tags=tags
        ),
    }


def tool_search(
    query: str = "",
    *,
    include_registry: bool = True,
    limit: int = 20,
) -> dict[str, Any]:
    """Search the local installed index + (optionally) the toolspace registry.

    Returns a ranked answer::

        {
          "query": ...,
          "count": <len(results)>,
          "results": [ {id, name, summary, source, installed, score, ...}, ... ],
          "registry_available": <bool>,   # did the registry fetch return data?
          "installed_count": ..., "registry_count": ...,
        }

    Results are ranked by lexical score (desc), installed-first on a tie, then by
    name. An empty ``query`` returns everything (score 0, name-sorted). A tool
    present both installed and in the registry is de-duplicated, the installed
    view winning (so its actions/version show)."""
    installed = installed_index()
    installed_ids = {e.get("tool_id") for e in installed}

    registry: list[dict[str, Any]] = []
    registry_available = False
    if include_registry:
        registry = fetch_registry()
        registry_available = bool(registry)

    results: list[dict[str, Any]] = [_installed_result(e, query) for e in installed]
    for entry in registry:
        rid = entry.get("id")
        if rid in installed_ids:
            # Already represented by its installed view — skip the registry dup.
            continue
        results.append(_registry_result(entry, query, installed=False))

    has_query = bool(_tokenize(query))
    if has_query:
        results = [r for r in results if r["score"] > 0]

    results.sort(
        key=lambda r: (-r["score"], not r["installed"], (r["name"] or "").lower())
    )
    if limit and limit > 0:
        results = results[:limit]

    return {
        "query": query,
        "count": len(results),
        "results": results,
        "registry_available": registry_available,
        "installed_count": len(installed),
        "registry_count": len(registry),
    }


# ---------------------------------------------------------------------------
# Free-vs-paid install UX (T4.12)
# ---------------------------------------------------------------------------


def manifest_cost(doc: dict[str, Any]) -> dict[str, Any]:
    """The manifest's ``cost`` block (``{}`` when absent / malformed)."""
    cost = (doc or {}).get("cost")
    return cost if isinstance(cost, dict) else {}


def _as_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def is_paid_manifest(doc: dict[str, Any]) -> bool:
    """True iff this manifest is *premium* — a closed-source proprietary tool or
    one declaring a non-zero install/monthly fee. Usage-based disclosure
    (``usage_model``) alone is NOT a purchase gate (it is consent disclosure, not
    a fee to install)."""
    tool = (doc or {}).get("tool") or {}
    if str(tool.get("license") or "").upper() == "PROPRIETARY":
        return True
    cost = manifest_cost(doc)
    return _as_int(cost.get("install_fee_cents")) > 0 or _as_int(
        cost.get("monthly_fee_cents")
    ) > 0


def cost_summary(cost: dict[str, Any]) -> dict[str, Any]:
    """A human + machine readable view of a ``cost`` block: USD dollars plus a
    one-line ``human`` summary. Cents are the source of truth in the manifest."""
    cost = cost or {}
    install_c = cost.get("install_fee_cents")
    monthly_c = cost.get("monthly_fee_cents")
    usage = cost.get("usage_model")
    out: dict[str, Any] = {
        "usage_model": usage,
        "estimate_url": cost.get("estimate_url"),
    }
    parts: list[str] = []
    if install_c is not None:
        out["install_fee_cents"] = _as_int(install_c)
        out["install_fee_usd"] = round(_as_int(install_c) / 100, 2)
        parts.append(f"one-time ${_as_int(install_c) / 100:.2f}")
    if monthly_c is not None:
        out["monthly_fee_cents"] = _as_int(monthly_c)
        out["monthly_fee_usd"] = round(_as_int(monthly_c) / 100, 2)
        parts.append(f"${_as_int(monthly_c) / 100:.2f}/mo")
    if usage and usage != "none":
        parts.append(f"usage: {usage}")
    out["human"] = "; ".join(parts) if parts else "price not specified"
    return out


def _purchase_hint(doc: dict[str, Any]) -> str | None:
    """A best-effort URL the user can go to in order to buy / learn more — the
    cost estimate URL, else the tool homepage, else a support/issues URL."""
    cost = manifest_cost(doc)
    if cost.get("estimate_url"):
        return cost.get("estimate_url")
    tool = (doc or {}).get("tool") or {}
    if tool.get("homepage"):
        return tool.get("homepage")
    support = (doc or {}).get("support") or {}
    return support.get("docs_url") or support.get("issues_url")


def _purchase_required_result(
    doc: dict[str, Any],
    *,
    url: str | None,
    reason: str | None,
    entitlement_state: str | None,
    cost_override: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the purchase-required RESULT envelope (an OK outcome, not an error)."""
    tool = (doc or {}).get("tool") or {}
    cost = cost_override if cost_override is not None else manifest_cost(doc)
    summary = cost_summary(cost)
    return {
        "ok": True,
        "purchase_required": True,
        "tool_id": tool.get("id"),
        "name": tool.get("name"),
        "license": tool.get("license"),
        "cost": cost,
        "price": summary,
        "estimate_url": cost.get("estimate_url"),
        "purchase_url": _purchase_hint(doc),
        "manifest_url": url,
        "entitlement_state": entitlement_state,
        "reason": reason
        or "this is a premium tool and no usable entitlement was found",
        "message": (
            f"'{tool.get('name') or tool.get('id') or 'This tool'}' is a premium "
            f"tool ({summary.get('human')}). Purchase an entitlement to install it "
            "(already-installed tools keep working offline; the free tool catalog "
            "is unaffected)."
        ),
    }


def purchase_required(
    doc: dict[str, Any], *, url: str | None = None
) -> dict[str, Any] | None:
    """Return a purchase-required RESULT for a *premium* manifest with no usable
    entitlement, else ``None`` (free manifest, or a valid/within-grace
    entitlement is present → install proceeds).

    No local DRM: this is a UX gate only. The authoritative paywall is the gated
    server fetch. Entitlement evaluation is delegated to the (optional)
    entitlement module, imported lazily so the free path never depends on it."""
    if not is_paid_manifest(doc):
        return None
    try:
        from local_yep.toolspace import entitlement as ent
    except Exception:
        # No entitlement module at all → treat premium as purchasable (free path
        # is never reached here because is_paid_manifest already returned True).
        return _purchase_required_result(
            doc,
            url=url,
            reason="entitlement support is not available in this build",
            entitlement_state="unavailable",
        )
    try:
        status = ent.entitlement_status()
    except Exception:
        status = None
    if status is not None and getattr(status, "valid", False):
        return None  # entitled (active or within grace) → install proceeds
    return _purchase_required_result(
        doc,
        url=url,
        reason=getattr(status, "reason", None),
        entitlement_state=getattr(status, "state", "absent"),
    )


def _purchase_required_from_http(
    url: str, exc: "loader.PaymentRequiredError"
) -> dict[str, Any]:
    """Turn a gated host's HTTP 402 into a purchase-required RESULT. The 402 body
    may itself carry the manifest / a cost or price block — surface it when so."""
    body = exc.body if isinstance(exc.body, dict) else {}
    # The body may BE a manifest, or wrap {tool, cost, price}.
    doc = body if (body.get("tool") or body.get("manifest_version")) else {
        "tool": body.get("tool") or {},
    }
    cost_override = None
    if isinstance(body.get("cost"), dict):
        cost_override = body["cost"]
    elif isinstance(body.get("price"), dict):
        cost_override = body["price"]
    result = _purchase_required_result(
        doc,
        url=url,
        reason="the premium host returned HTTP 402 Payment Required",
        entitlement_state="server_gated",
        cost_override=cost_override,
    )
    result["http_status"] = 402
    if body:
        result["server_detail"] = body
    return result


def install_tool(
    doc_or_url: Any,
    *,
    confirm: loader.ConfirmFn | None = None,
    check_purchase: bool = True,
) -> dict[str, Any]:
    """UX-aware install: free tools install; premium-without-entitlement returns
    a purchase-required RESULT (price + estimate) instead of an error (T4.12).

    ``doc_or_url`` is a manifest dict or a manifest URL string. Returns either::

        {"ok": True, "installed": <public registry entry>}            # installed
        {"ok": True, "purchase_required": True, "price": {...}, ...}  # purchasable

    A gated host's HTTP 402 is caught and surfaced as purchase-required. Genuine
    failures (compatibility fence, schema validation, the headless confirm gate)
    propagate as :class:`loader.ManifestError` for the caller to render."""
    if isinstance(doc_or_url, str):
        url: str | None = doc_or_url
        try:
            doc = loader.fetch_manifest(doc_or_url)
        except loader.PaymentRequiredError as e:
            return _purchase_required_from_http(doc_or_url, e)
    elif isinstance(doc_or_url, dict):
        doc, url = doc_or_url, None
    else:
        raise TypeError(
            "install_tool takes a manifest dict or URL str, got "
            f"{type(doc_or_url).__name__}"
        )

    if check_purchase:
        pr = purchase_required(doc, url=url)
        if pr is not None:
            return pr

    entry = loader.install(doc, confirm=confirm)
    return {"ok": True, "installed": entry}


__all__ = [
    "DEFAULT_REGISTRY_URL",
    "DEFAULT_REGISTRY_TTL_SECONDS",
    "registry_url",
    "clear_registry_cache",
    "fetch_registry",
    "installed_index",
    "tool_search",
    "manifest_cost",
    "is_paid_manifest",
    "cost_summary",
    "purchase_required",
    "install_tool",
]
