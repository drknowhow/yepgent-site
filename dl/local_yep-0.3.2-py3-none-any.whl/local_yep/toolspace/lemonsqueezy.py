"""LemonSqueezy **license-key** client (PLAN.md §4 · T4.9).

This is the net-new, client-side half of the LemonSqueezy integration: the
``/v1/licenses/{activate,validate,deactivate}`` endpoints a buyer uses to
prove + manage a purchased license key. It is deliberately *distinct* from the
store-management API (products / orders / webhooks) which uses a Bearer
``LS_API_KEY``:

* The **license API** is authenticated by the license key itself — there is no
  ``Authorization`` header. Requests are ``application/x-www-form-urlencoded``;
  responses are plain JSON (NOT JSON:API), e.g.::

      activate   -> {"activated": true,  "instance": {"id": "...", ...}, "license_key": {...}, "meta": {...}}
      validate   -> {"valid": true,      "instance": {...} | null,       "license_key": {...}, "meta": {...}}
      deactivate -> {"deactivated": true,                                "license_key": {...}, "meta": {...}}

* On an HTTP error the LS body is preserved inside the project's
  ``{error, status, detail}`` envelope so callers get both the status and the
  LS message.

Typical flow surfaced to ``yepgent``: the user pastes a license key →
:func:`activate_license` binds this machine as an *instance* (returns an
``instance_id`` to cache) → :func:`validate_license` confirms it later →
:func:`deactivate_license` frees the seat. The entitlement JWT
(``license.json``) is minted separately by the premium-manifest webhook
(T4.10); this client only manages the LemonSqueezy license-key lifecycle.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

_BASE_URL = "https://api.lemonsqueezy.com/v1"

#: Default instance name sent at activation when the caller supplies none.
DEFAULT_INSTANCE_NAME = "local-yep"


def _http_post(url: str, data: bytes, headers: dict[str, str]) -> tuple[int, bytes]:
    """POST ``data`` to ``url`` → ``(status_code, body_bytes)``.

    Sole network seam: tests monkeypatch this to run fully offline. Raises
    :class:`urllib.error.URLError` for transport failures (caller wraps).
    """
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req) as resp:  # noqa: S310 - fixed https host
        return resp.getcode(), resp.read()


def _post_form(path: str, fields: dict[str, Any]) -> dict:
    """POST form-encoded ``fields`` to the LS license API and parse the JSON.

    Returns the parsed LS body on success; on an HTTP error returns the project
    ``{error, status, detail}`` envelope (with the LS JSON body as ``detail``
    when parseable). Network/transport failures yield ``status=0``.
    """
    url = f"{_BASE_URL}{path}"
    data = urllib.parse.urlencode(
        {k: v for k, v in fields.items() if v is not None}
    ).encode()
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    try:
        status, raw = _http_post(url, data, headers)
    except urllib.error.HTTPError as exc:
        body = exc.read()
        return {"error": True, "status": exc.code, "detail": _parse_or_raw(body)}
    except urllib.error.URLError as exc:
        return {"error": True, "status": 0, "detail": {"reason": str(exc.reason)}}
    parsed = _parse_or_raw(raw)
    if not isinstance(parsed, dict):
        return {"error": True, "status": status, "detail": parsed}
    return parsed


def _parse_or_raw(body: bytes) -> Any:
    text = body.decode("utf-8", errors="replace") if body else ""
    if not text.strip():
        return {}
    try:
        return json.loads(text)
    except Exception:
        return {"raw": text}


# ---------------------------------------------------------------------------
# License-key endpoints
# ---------------------------------------------------------------------------

def activate_license(license_key: str, instance_name: str = DEFAULT_INSTANCE_NAME) -> dict:
    """Activate ``license_key`` for this machine (POST ``/licenses/activate``).

    On success the LS body contains ``activated: true`` and
    ``instance: {"id": ...}`` — cache that instance id for later
    validate/deactivate calls.
    """
    return _post_form(
        "/licenses/activate",
        {"license_key": license_key, "instance_name": instance_name},
    )


def validate_license(license_key: str, instance_id: str | None = None) -> dict:
    """Validate ``license_key`` (POST ``/licenses/validate``).

    Pass the ``instance_id`` from a prior activation to validate *this* seat;
    omit it to validate the key alone. The LS body reports ``valid`` plus the
    license-key status and activation counts.
    """
    return _post_form(
        "/licenses/validate",
        {"license_key": license_key, "instance_id": instance_id},
    )


def deactivate_license(license_key: str, instance_id: str) -> dict:
    """Deactivate (free) a seat (POST ``/licenses/deactivate``).

    ``instance_id`` is the id returned by :func:`activate_license`. The LS body
    reports ``deactivated: true`` on success.
    """
    return _post_form(
        "/licenses/deactivate",
        {"license_key": license_key, "instance_id": instance_id},
    )


def run(args: dict) -> dict:
    """Thin dispatcher so the client can be surfaced as one MCP/CLI tool.

    ``action`` ∈ {``activate``, ``validate``, ``deactivate``}. This keeps the
    license client callable the same way ``yepgent`` invokes other tools while
    the plain functions above stay ergonomic for direct import.
    """
    action = args.get("action", "")
    key = args.get("license_key", "")
    if action == "activate":
        return activate_license(key, args.get("instance_name", DEFAULT_INSTANCE_NAME))
    if action == "validate":
        return validate_license(key, args.get("instance_id"))
    if action == "deactivate":
        return deactivate_license(key, args["instance_id"])
    return {"error": True, "detail": f"Unknown action: {action!r}"}
