"""Local-first install runtime for install-manifest-spec tools.

Ported from the source repo's ``src/tools/manifest_loader.py`` (+ the thin
``src/tools/manifest.py`` MCP surface) and localized for Local Yep. It fetches
an install-manifest JSON doc (spec: github.com/drknowhow/install-manifest-spec),
validates it via the bundled ``install_manifest.validate.validate``, then
installs the tool by:

  - applying the COMPATIBILITY FENCE (T4.7) — refusing any manifest that implies
    a we-run-a-service dependency (``mcp-http`` / ``url`` / ``container``);
  - dispatching to the registered ``InstallHandler`` for
    ``runtime.install.method`` (``preinstalled`` / ``git`` / ``pip``), which
    materializes the artifact and returns an ``exec_ctx``;
  - for code-fetching methods, driving a LOCAL confirm gate (T4.6) BEFORE any
    clone/build;
  - registering each ``actions[]`` entry in a DURABLE on-disk index (T4.5);
  - exposing ``call(tool_id, action_name, params)`` which dispatches to the
    registered ``InvocationStrategy`` for ``actions[].invocation.kind``.

What this port KEEPS verbatim-in-spirit (the security machinery)
---------------------------------------------------------------
  * **SHA-pin only** for git: ``_resolve_pin`` refuses any ``ref`` that isn't a
    full 40-hex commit SHA before the clone runs.
  * **Default-refuse + live confirmation** for every code-fetching method (the
    fail-closed ``requires_confirmation`` flag, default True on ``FetchHandler``).
  * **Isolation**: per-tool venv built+run with ``_fetched_child_env`` (a
    stripped non-secret allowlist ∪ the manifest's declared ``env[]`` only).
  * **Fail-closed smoke gate**: ``SmokeRunner`` runs the manifest's ``smoke``
    block against the freshly-built tool; any failure purges staging+venv.
  * **Atomic + content-addressed**: clone cache + staging dir + ``os.replace``
    transactional swap into the final install dir on smoke-pass.
  * Registered handlers: ``preinstalled`` / ``git`` / ``pip``. ``npm`` / ``url``
    / ``container`` stay UNregistered (and ``url`` / ``container`` are also
    refused up-front by the fence).

What this port ADAPTS for Local Yep
-----------------------------------
  * **DURABLE INSTALL INDEX (T4.5)** — ``_INSTALLED`` is persisted to
    ``~/.local-yep/installed.json`` (atomic write) and rehydrated on import, so a
    restart does NOT re-prompt the confirm gate for an already-approved tool. A
    re-install of the SAME approved pin returns idempotently with no prompt.
  * **LOCAL TTY CONFIRM (T4.6)** — the cloud Telegram-async PARK confirm is
    replaced by a local terminal yes/no that shows the exact argv + resolved SHA
    + scopes + data_boundary. When no TTY is available (headless) it fails CLOSED.
  * **COMPATIBILITY FENCE (T4.7)** — see ``_compatibility_fence``.
  * **PREMIUM auth header** — ``fetch_manifest`` attaches
    ``Authorization: Bearer <jwt>`` ONLY for premium hosts, resolved lazily via
    :func:`local_yep.toolspace.entitlement.authorize_header`. Free/static
    fetches send no auth, and the entitlement module is never a hard dependency.

What this port DROPS
--------------------
The Supabase/daemon-audit coupling, the Telegram operator-chat confirm, and the
entire park / resume / reconcile / boot-maintenance machinery. No network is
touched except the user's own pip/git pull and the manifest fetch.

Security posture (v0): NO sandboxing of the action body — installed actions run
as a subprocess of the parent. The manifest contract surfaces ``scopes``,
``kill_switch``, and ``data_boundary`` to the caller; honoring them is the
agent's job above this layer. The single highest-value hardening is env
isolation: the child subprocess never inherits the parent's full environment —
only ``_safe_base_env()`` ∪ the manifest's declared ``env[]`` ∪ any explicit
``env=`` passed to ``call()``.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
import urllib.error
import urllib.request
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Protocol, runtime_checkable

from local_yep import home as _home

try:
    from install_manifest.validate import validate as _imv_validate  # type: ignore
except Exception:  # pragma: no cover - import-time fallback for envs without the dep
    _imv_validate = None


# ---------------------------------------------------------------------------
# Timeouts
# ---------------------------------------------------------------------------

#: Manifest-fetch HTTP timeout (the only network call besides the user's own
#: pip/git pull).
_HTTP_TIMEOUT_S = 15

#: Action-call subprocess budget.
_DEFAULT_TIMEOUT_S = 30

#: Install-time budget (clone/build/venv/smoke) — far slower than an action call.
_INSTALL_TIMEOUT_S = 600


# ---------------------------------------------------------------------------
# Typed exception hierarchy
# ---------------------------------------------------------------------------
#
# All subclass RuntimeError so existing `except RuntimeError` handlers stay
# green. The base carries optional structured fields a caller can branch on
# without string-parsing.


class ManifestError(RuntimeError):
    """Base for all loader-raised errors. Subclasses RuntimeError so legacy
    `except RuntimeError` paths keep working; the structured fields are an
    additive surface for callers that want to branch on them."""

    def __init__(
        self,
        message: str,
        *,
        phase: str | None = None,
        retryable: bool = False,
        returncode: int | None = None,
        stderr_tail: str | None = None,
        status: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.phase = phase
        self.retryable = retryable
        self.returncode = returncode
        self.stderr_tail = stderr_tail
        # HTTP status + parsed response body for fetch-time failures. `status` lets
        # a caller branch on (e.g.) 402 without string-parsing; `body` carries any
        # JSON the server returned (a 402 may disclose the price/cost).
        self.status = status
        self.body = body


class FetchError(ManifestError):
    """Manifest could not be fetched / parsed (transport, decode, JSON)."""


class PaymentRequiredError(FetchError):
    """The gated premium-manifest fetch returned HTTP 402 Payment Required.

    NOT "broken" — *purchasable*. The toolspace UX layer
    (:mod:`local_yep.toolspace.discovery`) converts this into a purchase-required
    RESULT (price + estimate) rather than an error (T4.12). Carries the 402
    ``status`` and any parsed ``body`` the gated host returned (which may itself
    disclose the cost/price). Deterministic — not retryable."""


class ValidationError(ManifestError):
    """Manifest failed schema validation, or required fields are missing."""


class BuildError(ManifestError):
    """Materializing the artifact failed (clone/venv/build)."""


class SmokeError(ManifestError):
    """Post-install fail-closed smoke gate failed."""


class InvocationError(ManifestError):
    """An action invocation failed at runtime (subprocess error / nonzero)."""


class UnsupportedManifestError(ManifestError):
    """The loader declines to install or invoke this manifest shape — either no
    handler is registered for the method, or the compatibility fence refuses a
    we-run-a-service runtime. Deterministic — not retryable."""


class ApprovalRequiredError(ManifestError):
    """A code-fetching install was attempted without an explicit confirmation.

    This is the human-in-the-loop gate (safety invariant #2): default-refuse.
    The gate is structural — it proves a user deliberately approved THIS
    manifest's exact scope + executable surface. Raised when the confirm
    callable did not return literal True (declined, headless/no-TTY fail-closed,
    or the callable raised). Deterministic, not retryable."""


# ---------------------------------------------------------------------------
# Registry + durable on-disk install index (T4.5)
# ---------------------------------------------------------------------------
#
# `_INSTALLED` is the in-process registry, keyed by `tool.id`. Unlike the
# source (which was process-local and re-fetched on every daemon restart), the
# local product persists it to `~/.local-yep/installed.json` (atomic write) and
# rehydrates it on import — so a restart never re-prompts the confirm gate for an
# already-approved tool. A corrupt/missing index degrades to empty (re-fetch),
# never crashing boot.

_INSTALLED: dict[str, dict[str, Any]] = {}

# Stable marker text in the `_InstallLock` contention BuildError. A same-pin lock
# loss is benign (the other installer is doing the work).
_LOCK_CONTENTION_MARKER = "another install of this pin is in progress"


def _index_path() -> Path:
    """Resolve the durable install-index file. Honors the ``YEP_MANIFEST_INDEX``
    env override (tests/headless point it at a scratch file) and otherwise lands
    at the canonical ``~/.local-yep/installed.json`` (see ``local_yep.home``)."""
    override = os.environ.get("YEP_MANIFEST_INDEX")
    if override:
        return Path(override)
    return _home.INSTALLED_JSON


def _persist_index() -> None:
    """Atomically write the durable install index. Best-effort: a durability
    failure must NEVER break an install (the in-memory registry is authoritative
    for the running process). Staging-namespaced smoke-window keys are never
    persisted."""
    payload = {
        tid: entry
        for tid, entry in _INSTALLED.items()
        if not str(tid).startswith("__staging__:")
    }
    path = _index_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp-{os.getpid()}")
        tmp.write_text(
            json.dumps(payload, default=str, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(str(tmp), str(path))
    except Exception:
        # Never let a disk hiccup turn a successful install into a crash.
        pass


def rehydrate() -> int:
    """Repopulate ``_INSTALLED`` from the durable index. Returns the count
    rehydrated. A missing/empty/corrupt index degrades to a no-op (the registry
    stays whatever it was) rather than crashing — boot must always proceed.

    Called once at import time and re-callable to simulate a restart."""
    path = _index_path()
    try:
        if not path.exists():
            return 0
        text = path.read_text(encoding="utf-8")
        if not text.strip():
            return 0
        data = json.loads(text)
        if not isinstance(data, dict):
            return 0
    except Exception:
        # Corrupt/unreadable index → ignore (re-fetch), never crash boot.
        return 0
    count = 0
    for tid, entry in data.items():
        if isinstance(entry, dict) and not str(tid).startswith("__staging__:"):
            _INSTALLED[str(tid)] = entry
            count += 1
    return count


def _registry_entry(tool_id: str) -> dict[str, Any]:
    entry = _INSTALLED.get(tool_id)
    if entry is None:
        raise LookupError(f"tool not installed: {tool_id!r}")
    return entry


# ---------------------------------------------------------------------------
# Fetch + validate
# ---------------------------------------------------------------------------


def _premium_auth_headers(url: str) -> dict[str, str]:
    """Resolve the optional ``Authorization: Bearer`` header for a PREMIUM host.

    Delegates the entire premium-host + entitlement decision to
    :func:`local_yep.toolspace.entitlement.authorize_header`, imported LAZILY so
    the free core never depends on the (optional) entitlement module or its
    ``[pro]`` crypto extra. Returns ``{}`` (no auth) when the module is absent,
    the host is free/static, or no usable entitlement exists — and never raises.
    A free fetch therefore always sends NO Authorization header."""
    try:
        from local_yep.toolspace.entitlement import authorize_header
    except Exception:
        # Entitlement module not present (parallel/optional) → free path only.
        return {}
    try:
        headers = authorize_header(url)
    except Exception:
        # An entitlement problem must never break the free fetch path.
        return {}
    return headers if isinstance(headers, dict) else {}


def _read_http_error_body(e: urllib.error.HTTPError) -> Any:
    """Best-effort parse of an ``HTTPError`` response body — JSON if parseable,
    else the raw text, else ``None``. Never raises (the body is advisory; a 402's
    body may carry the price/cost disclosure)."""
    try:
        raw = e.read()
    except Exception:
        return None
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except Exception:
        try:
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return None


def fetch_manifest(url: str) -> dict[str, Any]:
    """Fetch a manifest JSON doc by URL. Raises on transport / parse error.

    Sends a ``User-Agent`` always; attaches ``Authorization: Bearer <jwt>`` ONLY
    for premium hosts (via :func:`_premium_auth_headers` → the entitlement hook).
    Free/static manifest fetches send no auth header."""
    headers = {"User-Agent": "local-yep-manifest-loader/0.1"}
    headers.update(_premium_auth_headers(url))
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT_S) as resp:
            body = resp.read()
    except urllib.error.HTTPError as e:
        # HTTPError is a subclass of URLError — catch it FIRST so a 402 from a
        # gated premium host becomes a purchasable signal, not a generic failure.
        detail = _read_http_error_body(e)
        if e.code == 402:
            raise PaymentRequiredError(
                f"payment required (402) for premium manifest: {url}",
                phase="fetch",
                retryable=False,
                status=402,
                body=detail,
            ) from e
        raise FetchError(
            f"fetch failed: {url}: {e}",
            phase="fetch",
            retryable=e.code >= 500,
            status=e.code,
            body=detail,
        ) from e
    except urllib.error.URLError as e:
        raise FetchError(
            f"fetch failed: {url}: {e}", phase="fetch", retryable=True
        ) from e
    try:
        return json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise FetchError(
            f"manifest is not valid JSON: {url}: {e}", phase="fetch", retryable=False
        ) from e


# Manifest-declared OAuth (Model B / T6.5). A Local Yep extension carried in a
# top-level `auth` block. The bundled install-manifest schema is strict
# (additionalProperties:false at the root) and has no `auth` key, so we STRIP the
# block before the bundled validator and validate it ourselves here — forward-
# compatible with the anticipated install-manifest v0.5 `auth` block (file the
# upstream spec bump separately; this keeps Local Yep shippable today).
_AUTH_KEYS = ("auth", "oauth")  # `auth` is canonical; `oauth` accepted as alias.
_AUTH_TYPES = frozenset({"oauth2"})
_AUTH_CLIENTS = frozenset({"user-supplied"})
_AUTH_REDIRECTS = frozenset({"loopback"})
_ENV_NAME_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")


def _manifest_auth(doc: dict[str, Any]) -> dict[str, Any] | None:
    """The manifest's OAuth block (`auth`, or the `oauth` alias), or None."""
    if not isinstance(doc, dict):
        return None
    for key in _AUTH_KEYS:
        block = doc.get(key)
        if isinstance(block, dict):
            return block
    return None


def _validate_auth_block(auth: dict[str, Any]) -> list[tuple[str, str]]:
    """Validate a manifest `auth` block. Returns a list of (pointer, message)
    in the same shape as the bundled validator's errors."""
    errs: list[tuple[str, str]] = []

    def req_https(field: str, *, required: bool) -> None:
        val = auth.get(field)
        if val is None:
            if required:
                errs.append((f"/auth/{field}", f"{field} is required"))
            return
        if not isinstance(val, str) or not val:
            errs.append((f"/auth/{field}", f"{field} must be a non-empty string"))
        elif not val.startswith("https://"):
            errs.append((f"/auth/{field}", f"{field} must be an https:// URL"))

    if auth.get("type") not in _AUTH_TYPES:
        errs.append(("/auth/type", f"type must be one of {sorted(_AUTH_TYPES)}"))
    req_https("authorize_url", required=True)
    req_https("token_url", required=True)
    req_https("device_code_url", required=False)

    scopes = auth.get("scopes")
    if not isinstance(scopes, list) or not scopes or not all(
        isinstance(s, str) and s for s in scopes
    ):
        errs.append(("/auth/scopes", "scopes must be a non-empty array of strings"))

    env_name = auth.get("access_token_env")
    if not isinstance(env_name, str) or not _ENV_NAME_RE.match(env_name or ""):
        errs.append(
            ("/auth/access_token_env", "access_token_env must be a SCREAMING_SNAKE env name")
        )

    client = auth.get("client", "user-supplied")
    if client not in _AUTH_CLIENTS:
        errs.append(("/auth/client", f"client must be one of {sorted(_AUTH_CLIENTS)} (Local Yep is user-brings-own)"))
    redirect = auth.get("redirect", "loopback")
    if redirect not in _AUTH_REDIRECTS:
        errs.append(("/auth/redirect", f"redirect must be one of {sorted(_AUTH_REDIRECTS)}"))
    return errs


def validate_manifest(doc: dict[str, Any]) -> dict[str, Any]:
    """Validate against the bundled install-manifest schema.

    Returns a normalized dict: {ok, summary, errors, manifest_version,
    pin_warnings}. Never raises on schema failure. Raises only if the
    install_manifest package isn't importable in this environment.

    A Local Yep `auth` block (Model B / T6.5) is stripped before the strict
    bundled validator and validated locally (the bundled v0.4 schema is
    additionalProperties:false and has no `auth` key)."""
    if _imv_validate is None:
        raise ValidationError(
            "install_manifest package not importable — "
            "`pip install install-manifest` first",
            phase="validate",
            retryable=False,
        )
    auth_block = _manifest_auth(doc)
    core = doc
    if auth_block is not None and isinstance(doc, dict):
        core = {k: v for k, v in doc.items() if k not in _AUTH_KEYS}
    result = _imv_validate(core)
    errors = [
        {"pointer": p, "message": m}
        for p, m in (getattr(result, "errors", None) or [])
    ]
    auth_errors = _validate_auth_block(auth_block) if auth_block is not None else []
    errors += [{"pointer": p, "message": m} for p, m in auth_errors]
    install_block = ((doc.get("runtime") or {}).get("install")) or {}
    return {
        "ok": bool(getattr(result, "ok", False)) and not auth_errors,
        "summary": getattr(result, "summary", ""),
        "errors": errors,
        "manifest_version": doc.get("manifest_version"),
        "pin_warnings": validate_pin(install_block),
    }


# ---------------------------------------------------------------------------
# Pin-integrity validation (consumer-side primitive)
# ---------------------------------------------------------------------------

# `\Z` (end-of-string), NOT `$` — `$` also matches just before a trailing
# newline. Anchored with \A..\Z these only accept an EXACT 40/64-hex string.
_SHA1_RE = re.compile(r"\A[a-f0-9]{40}\Z")
_SHA256_RE = re.compile(r"\A[a-f0-9]{64}\Z")
_PIP_EXACT_RE = re.compile(r"\A===?\s*[A-Za-z0-9][A-Za-z0-9.\-_+!]*\Z")


def normalize_version_spec(version_spec: Any) -> str | None:
    """Normalize a pip `version_spec` to a stable canonical string, or None when
    absent. Collapses whitespace around clause separators so two visually-equal
    specs digest identically; returns None for a missing/blank spec."""
    if version_spec is None:
        return None
    s = str(version_spec).strip()
    if not s:
        return None
    s = re.sub(r"\s*,\s*", ",", s)
    s = re.sub(r"\s+", " ", s)
    return s


def is_exact_pip_spec(version_spec: str | None) -> bool:
    """True iff `version_spec` is a single exact `==`/`===` pin over one concrete
    version (no range, no wildcard, no comma-joined clauses)."""
    if not version_spec:
        return False
    if "," in version_spec:
        return False
    if "*" in version_spec:
        return False
    return bool(_PIP_EXACT_RE.match(version_spec.strip()))


def validate_pin(install_block: dict[str, Any]) -> list[str]:
    """Return human-readable supply-chain pin problems for a `runtime.install`
    block (empty list == none found). Consumer-side documentation only — it does
    NOT gate install (methods without a registered handler are refused at
    install() time)."""
    if not isinstance(install_block, dict):
        return []
    method = install_block.get("method")
    warnings: list[str] = []

    if method == "git":
        git = install_block.get("git") or {}
        ref = git.get("ref") or install_block.get("ref")
        if not ref:
            warnings.append("git install missing 'ref'; pin to a commit SHA")
        elif not _SHA1_RE.match(str(ref)):
            warnings.append(
                f"git ref {ref!r} is a mutable ref; pin to a commit SHA (40-hex)"
            )
    elif method == "url":
        url_block = install_block.get("url") or {}
        sha256 = url_block.get("sha256") or install_block.get("sha256")
        if not sha256:
            warnings.append("url install missing 'sha256' integrity hash")
        elif not _SHA256_RE.match(str(sha256)):
            warnings.append(f"url sha256 {sha256!r} is not a valid 64-hex digest")
    elif method == "pip":
        spec = normalize_version_spec(install_block.get("version_spec"))
        if spec is None:
            warnings.append(
                "pip install missing 'version_spec'; installing 'latest' is an "
                "unpinned moving target — pin to an exact '==<version>'"
            )
        elif not is_exact_pip_spec(spec):
            warnings.append(
                f"pip version_spec {spec!r} is not an exact pin (a range/wildcard "
                "is a moving target); the user approves it as a RANGE, not a "
                "fixed version"
            )
        warnings.append(
            "pip install has no artifact integrity hash "
            "(no hash field in the v0.4 schema yet)"
        )
    elif method == "npm":
        warnings.append(
            "npm install has no artifact integrity hash "
            "(no hash field in the v0.4 schema yet)"
        )

    return warnings


# ---------------------------------------------------------------------------
# Compatibility fence (T4.7) — refuse we-run-a-service manifests
# ---------------------------------------------------------------------------
#
# Local Yep installs ONLY tools that run locally on the user's own machine:
#   * python-module / mcp-stdio (local subprocess) / shell-binary runtimes;
#   * user-cred API wrappers (the user supplies their own keys via env[].secret).
# It REFUSES anything that implies a service WE would have to run/operate — an
# `mcp-http` runtime, a `container` runtime/install, or a `url` direct-download
# install — because that breaks the "no we-run-a-service" product invariant
# (PLAN.md §4 / §5). These are also kept UNregistered as handlers; the fence is
# the explicit, clearly-errored up-front refusal (so the user sees WHY, not a
# bare "no handler"). The fence runs BEFORE schema validation so a forbidden
# shape is refused with a clear reason even if it would also fail the schema.

_ALLOWED_RUNTIME_KINDS = frozenset({"python-module", "mcp-stdio", "shell-binary"})
_FORBIDDEN_RUNTIME_KINDS = frozenset({"mcp-http", "container"})
_FORBIDDEN_INSTALL_METHODS = frozenset({"url", "container"})
# Action transports that reach an external/remote service rather than a local
# subprocess. subcommand / stdin-json (local subprocess) are allowed.
_FORBIDDEN_INVOCATION_KINDS = frozenset({"http", "mcp-http", "mcp-tool-call"})


def _compatibility_fence(doc: dict[str, Any]) -> None:
    """Refuse a manifest that implies a we-run-a-service dependency (T4.7).

    Raises ``UnsupportedManifestError`` (``"unsupported runtime: …"``) for an
    ``mcp-http`` / ``container`` runtime, a ``url`` / ``container`` install
    method, or any action whose ``invocation.kind`` reaches a remote service.
    Allows ``python-module`` / ``mcp-stdio`` / ``shell-binary`` runtimes and
    local (``subcommand`` / ``stdin-json``) invocations. No-op on a permitted
    manifest."""
    if not isinstance(doc, dict):
        return
    runtime = doc.get("runtime") or {}
    kind = runtime.get("kind")
    if kind in _FORBIDDEN_RUNTIME_KINDS:
        raise UnsupportedManifestError(
            f"unsupported runtime: runtime.kind={kind!r} implies a "
            "we-run-a-service dependency (a remote/containerized backend Local "
            "Yep would have to operate). Local Yep installs only LOCAL tools: "
            f"{sorted(_ALLOWED_RUNTIME_KINDS)} (mcp-stdio = local subprocess) "
            "plus user-cred API wrappers where you supply your own keys via "
            "env[]. Refused.",
            phase="install",
            retryable=False,
        )

    install_block = runtime.get("install") or {}
    method = install_block.get("method")
    if method in _FORBIDDEN_INSTALL_METHODS:
        raise UnsupportedManifestError(
            f"unsupported runtime: install.method={method!r} implies a "
            "we-run-a-service / non-local artifact dependency. Local Yep "
            "installs only via 'preinstalled', 'git' (SHA-pinned), or 'pip' "
            "(version-pinned PyPI). Refused.",
            phase="install",
            retryable=False,
        )

    for action in doc.get("actions") or []:
        if not isinstance(action, dict):
            continue
        inv_kind = (action.get("invocation") or {}).get("kind")
        if inv_kind in _FORBIDDEN_INVOCATION_KINDS:
            raise UnsupportedManifestError(
                f"unsupported runtime: action {action.get('name')!r} "
                f"invocation.kind={inv_kind!r} reaches a remote/we-run service. "
                "Local Yep tools invoke a LOCAL subprocess (subcommand / "
                "stdin-json) only. Refused.",
                phase="install",
                retryable=False,
            )


# ---------------------------------------------------------------------------
# Shared install helpers
# ---------------------------------------------------------------------------


def _probe_python_module(module_name: str) -> None:
    try:
        importlib.import_module(module_name)
    except ImportError as e:
        raise InvocationError(
            f"locator probe failed: cannot import {module_name!r}: {e}",
            phase="install",
            retryable=False,
        ) from e


def _declared_env_names(doc: dict[str, Any]) -> list[str]:
    """The manifest-declared env var NAMES (the passthrough allowlist). At call()
    time, any of them present in os.environ are forwarded to the child."""
    out: list[str] = []
    for item in doc.get("env") or []:
        if isinstance(item, dict):
            name = item.get("name")
            if isinstance(name, str) and name:
                out.append(name)
    return out


def _source_summary(install_block: dict[str, Any]) -> dict[str, Any]:
    """Compact provenance view of `runtime.install` for the blast-radius surface:
    install method + the identifying pin. Best-effort; never raises."""
    if not isinstance(install_block, dict):
        return {}
    method = install_block.get("method")
    src: dict[str, Any] = {"method": method}
    raw_url = install_block.get("url")
    url_block = raw_url if isinstance(raw_url, dict) else {}
    flat_url = raw_url if isinstance(raw_url, str) else None
    if method == "git" and flat_url or install_block.get("ref"):
        src["url"] = flat_url or install_block.get("url")
        src["ref"] = install_block.get("ref")
    if url_block.get("url") or url_block.get("sha256") or install_block.get("sha256"):
        src["url"] = url_block.get("url") or src.get("url")
        src["sha256"] = url_block.get("sha256") or install_block.get("sha256")
    if method in ("pip", "npm"):
        src["package"] = install_block.get("package")
        src["version_spec"] = install_block.get("version_spec")
    return {k: v for k, v in src.items() if v is not None}


# ---------------------------------------------------------------------------
# Confirmation context — domain-separated digests over the bound surface
# ---------------------------------------------------------------------------


def _canonical_digest(value: Any, *, domain: bytes) -> str:
    """Deterministic sha256 over a JSON-canonicalized value, NFC-normalized and
    domain-separated, so the same logical surface always digests identically and
    two different surfaces can't collide."""

    def _nfc(v: Any) -> Any:
        if isinstance(v, str):
            return unicodedata.normalize("NFC", v)
        if isinstance(v, list):
            return [_nfc(x) for x in v]
        if isinstance(v, dict):
            return {_nfc(k): _nfc(val) for k, val in v.items()}
        return v

    blob = json.dumps(_nfc(value), sort_keys=True, separators=(",", ":"))
    h = hashlib.sha256()
    h.update(domain)
    h.update(blob.encode("utf-8"))
    return h.hexdigest()


def scopes_digest(doc: dict[str, Any]) -> str:
    """Domain-separated canonical digest of the manifest's `scopes`."""
    return _canonical_digest(doc.get("scopes") or [], domain=b"scopes:")


def data_boundary_digest(doc: dict[str, Any]) -> str:
    """Domain-separated canonical digest of the manifest's `data_boundary`."""
    return _canonical_digest(doc.get("data_boundary") or {}, domain=b"data_boundary:")


def _smoke_surface(doc: dict[str, Any]) -> dict[str, Any]:
    """The SMOKE COMMAND surface the user is approving — the smoke block runs at
    install time AFTER confirmation, so a shell smoke's full argv must be shown
    and bound into the digest (a benign entrypoint can't hide a different smoke
    command)."""
    smoke = doc.get("smoke") or {}
    if not isinstance(smoke, dict):
        return {}
    kind = smoke.get("kind")
    surface: dict[str, Any] = {"kind": kind}
    if kind == "shell":
        surface["command"] = list(smoke.get("command") or [])
    elif kind == "action-call":
        surface["action"] = smoke.get("action")
    elif kind == "http":
        surface["method"] = smoke.get("method")
        surface["url"] = smoke.get("url")
    return surface


def _executable_surface(doc: dict[str, Any]) -> dict[str, Any]:
    """The EXECUTABLE SURFACE the user actually approves — the argv that will run,
    not just where it is fetched from. The SHA pin binds the SOURCE; the command
    comes from entrypoint.command + each action's argv_template + the install-time
    smoke command, none of which the SHA covers."""
    runtime = doc.get("runtime") or {}
    entrypoint = runtime.get("entrypoint") or {}
    argv_templates: dict[str, Any] = {}
    for action in doc.get("actions") or []:
        if not isinstance(action, dict):
            continue
        name = action.get("name")
        invocation = action.get("invocation") or {}
        if isinstance(name, str) and name:
            argv_templates[name] = list(invocation.get("argv_template") or [])
    return {
        "entrypoint_command": list(entrypoint.get("command") or []),
        "argv_templates": argv_templates,
        "env_names": _declared_env_names(doc),
        "kill_switch": doc.get("kill_switch") or {},
        "smoke": _smoke_surface(doc),
    }


def entrypoint_digest(doc: dict[str, Any]) -> str:
    """Domain-separated canonical digest of the manifest's EXECUTABLE SURFACE."""
    return _canonical_digest(_executable_surface(doc), domain=b"entrypoint:")


def source_digest(source: dict[str, Any]) -> str:
    """Domain-separated canonical digest of the RESOLVED SOURCE the user approved —
    the FULL fetch identity, so ANY change (url/ref/subpath/layout for git;
    package/version_spec for pip) diverges the digest. ``method`` is always in the
    hash so a method-flip cannot collide."""
    method = source.get("method")
    if method == "pip":
        canonical: dict[str, Any] = {
            "method": "pip",
            "package": source.get("package"),
            "version_spec": source.get("version_spec"),
        }
    else:
        canonical = {
            "method": method,
            "url": source.get("url"),
            "ref": source.get("ref"),
            "subpath": source.get("subpath"),
            "layout": source.get("layout") or "package",
        }
    return _canonical_digest(canonical, domain=b"source:")


def tool_identity_digest(doc: dict[str, Any]) -> str:
    """Domain-separated canonical digest of the manifest's TOOL IDENTITY
    (`tool.id` + `tool.version`) — bound so a relabel can't land approved bytes
    under a different tool's slot."""
    tool = doc.get("tool") or {}
    canonical = {"id": tool.get("id"), "version": tool.get("version")}
    return _canonical_digest(canonical, domain=b"tool:")


# The confirmation callable seam. A confirmer receives the bound context dict and
# approves THIS code from THIS SHA running THIS command with THESE scopes. It may
# return a bool, or a (bool, operator_id) tuple. Anything whose decision is not
# literal True is treated as refusal (fail-closed).
ConfirmResult = bool | tuple[bool, str | None]
ConfirmFn = Callable[[dict[str, Any]], ConfirmResult]


def _decode_confirm_result(
    result: Any, context: dict[str, Any]
) -> tuple[bool, str | None]:
    """Normalize a confirm callable's return into (approved, operator_id).
    `approved` is True ONLY when the decision component is the literal True object
    (a truthy non-bool like 1 or "yes" is NOT an approval — fail-closed)."""
    if isinstance(result, tuple) and len(result) == 2:
        decision, operator = result
    else:
        decision, operator = result, None
    approved = decision is True
    op = operator or context.get("operator")
    return approved, (str(op) if op else None)


def _require_scopes(doc: dict[str, Any], *, method: str) -> list[Any]:
    """Refuse a code-fetching install whose `scopes` is absent or empty — a
    fetch-and-run tool with no declared surface gives the user nothing to
    approve. Returns the validated non-empty scopes list."""
    scopes = doc.get("scopes")
    if not isinstance(scopes, list) or len(scopes) == 0:
        raise ApprovalRequiredError(
            f"install method {method!r} fetches and executes third-party code "
            "but the manifest declares no `scopes` — a fetch-and-run tool with "
            "an empty scope surface is refused (it gives you nothing to approve "
            "and cannot be confirmed). Declare the tool's scopes.",
            phase="install",
            retryable=False,
        )
    return scopes


def build_confirm_context(
    doc: dict[str, Any], *, source: dict[str, Any]
) -> dict[str, Any]:
    """Build the context handed to the confirm callable. It BINDS exactly what
    will execute — tool_id+version, the resolved source, the executable surface
    (entrypoint argv + per-action argv_templates + env names + kill_switch + the
    install-time smoke command), the full scopes, data_boundary, and the
    domain-separated audit digests — so the user approves THIS code running THIS
    command, not an abstract profile."""
    tool = doc.get("tool") or {}
    exec_surface = _executable_surface(doc)
    return {
        "tool_id": tool.get("id"),
        "version": tool.get("version"),
        "name": tool.get("name"),
        "source": dict(source),
        "entrypoint_command": exec_surface["entrypoint_command"],
        "argv_templates": exec_surface["argv_templates"],
        "env_names": exec_surface["env_names"],
        "kill_switch": exec_surface["kill_switch"],
        "smoke": exec_surface["smoke"],
        "scopes": doc.get("scopes") or [],
        "data_boundary": doc.get("data_boundary") or {},
        "scopes_digest": scopes_digest(doc),
        "data_boundary_digest": data_boundary_digest(doc),
        "entrypoint_digest": entrypoint_digest(doc),
        "source_digest": source_digest(source),
        "tool_identity_digest": tool_identity_digest(doc),
    }


def pip_install_argument(package: str, version_spec: str | None) -> str:
    """The exact pip requirement string installed and approved —
    `<package><version_spec>` (e.g. `requests==2.31.0`)."""
    return f"{package}{version_spec or ''}"


def _source_confirm_line(src: dict[str, Any]) -> str:
    """A one-line, method-appropriate description of the RESOLVED source for the
    confirm summary. git shows url@SHA+subpath+layout; pip shows the literal
    `pip install <package><version_spec>` command."""
    method = src.get("method")
    if method == "pip":
        return (
            "via `pip install "
            f"{pip_install_argument(str(src.get('package')), src.get('version_spec'))}`"
        )
    if method == "preinstalled":
        return f"preinstalled module {src.get('locator')!r}"
    return (
        f"from {src.get('url')} @ {src.get('ref')} "
        f"(subpath={src.get('subpath')!r}, layout={src.get('layout')!r})"
    )


# ---------------------------------------------------------------------------
# Local TTY confirm channel (T4.6) — replaces the cloud Telegram-async PARK
# ---------------------------------------------------------------------------
#
# The default confirmer for a code-fetching install. It shows the exact argv +
# resolved SHA + scopes + data_boundary on the terminal and asks a yes/no. When
# no TTY is available (headless / daemon / piped), there is no interactive
# channel to ask on, so it FAILS CLOSED (returns False → ApprovalRequiredError).
# Tests inject their own `confirm` to drive the approve path; the deny path and
# the headless fail-closed path exercise this default.


def _stdin_is_tty() -> bool:
    """Whether an interactive terminal is attached (best-effort). A seam so tests
    can simulate a TTY vs a headless run."""
    try:
        return bool(sys.stdin and sys.stdin.isatty())
    except Exception:
        return False


def _read_confirm_line(prompt: str) -> str:
    """Read one line of the user's yes/no decision. A seam so tests can feed an
    answer without a real terminal."""
    return input(prompt)


def _render_confirm_summary(context: dict[str, Any]) -> str:
    """A human-readable block showing exactly what is being approved: the source
    (url@SHA / pip command), the argv that will run, the smoke command, declared
    env var names, scopes, and data_boundary."""
    src = context.get("source") or {}
    bar = "=" * 72
    rule = "-" * 72
    lines = [
        "",
        bar,
        "  Local Yep — install confirmation required",
        bar,
        f"  tool:          {context.get('tool_id')} "
        f"v{context.get('version')}  ({context.get('name')})",
        f"  source:        {_source_confirm_line(src)}",
        f"  resolved ref:  {src.get('ref')}",
        f"  runs (argv):   {context.get('entrypoint_command')}",
        f"  action argv:   {context.get('argv_templates')}",
        f"  smoke:         {context.get('smoke')}",
        f"  env vars:      {context.get('env_names')}",
        f"  kill_switch:   {context.get('kill_switch')}",
        f"  scopes:        {json.dumps(context.get('scopes') or [])}",
        f"  data_boundary: {json.dumps(context.get('data_boundary') or {})}",
        rule,
    ]
    return "\n".join(lines)


def _local_tty_confirm(context: dict[str, Any]) -> ConfirmResult:
    """The default local confirmer. Prompts on the terminal and returns
    ``(True, 'local-tty')`` only on an explicit yes; returns ``False`` on a no,
    on EOF/interrupt, or when no TTY is attached (headless fail-closed)."""
    if not _stdin_is_tty():
        # No interactive channel — never fall open.
        return False
    try:
        print(_render_confirm_summary(context), file=sys.stderr, flush=True)
    except Exception:
        pass
    try:
        answer = _read_confirm_line(
            f"Install fetch-and-run tool {context.get('tool_id')!r}? "
            "Type 'yes' to approve: "
        )
    except (EOFError, KeyboardInterrupt):
        return False
    return (True, "local-tty") if str(answer).strip().lower() in ("y", "yes") else False


def _run_confirmation(
    doc: dict[str, Any],
    *,
    source: dict[str, Any],
    confirm: ConfirmFn | None,
) -> str:
    """Drive the confirm gate for a code-fetching method BEFORE any clone/build.
    Returns the approving operator id on success; raises ApprovalRequiredError on
    refusal. The proof of approval is the confirm callable's decision being
    literal True — never caller-supplied data. `confirm` defaults to the local
    TTY confirmer (which fails closed when headless)."""
    context = build_confirm_context(doc, source=source)
    confirmer = confirm if confirm is not None else _local_tty_confirm
    try:
        result = confirmer(context)
    except ApprovalRequiredError:
        raise
    except Exception as e:
        raise ApprovalRequiredError(
            f"confirmation callable raised ({e}); refusing the code-fetching "
            "install (fail-closed)",
            phase="install",
            retryable=False,
        ) from e
    approved, operator = _decode_confirm_result(result, context)
    if not approved:
        raise ApprovalRequiredError(
            f"install of {context.get('tool_id')!r} from {source.get('url')} @ "
            f"{source.get('ref')} was not confirmed — code-fetching installs are "
            "default-refuse and require an explicit confirmation before any "
            "clone/build (no interactive terminal fails closed).",
            phase="install",
            retryable=False,
        )
    return operator or "local-confirm"


# ---------------------------------------------------------------------------
# Install-root, cache, venv + filesystem helpers
# ---------------------------------------------------------------------------


def _install_root() -> Path:
    root = os.environ.get("YEP_MANIFEST_INSTALL_ROOT")
    if root:
        return Path(root)
    return Path(tempfile.gettempdir()) / "local-yep-manifest-installs"


def _git_allow_file_url() -> bool:
    """Whether `file://` git urls are permitted. OFF by default (prod refuses
    file:// — a local-path clone is an exfil / arbitrary-read vector). Tests set
    `YEP_MANIFEST_ALLOW_FILE_URL=1`."""
    return os.environ.get("YEP_MANIFEST_ALLOW_FILE_URL") == "1"


def _cache_key(method: str, url: str, ref: str, subpath: str | None) -> str:
    """Content-addressed key for a resolved pin — sha256 over a JSON-canonical,
    length-safe encoding of (method, normalized url, ref, subpath)."""
    norm_url = str(url).strip().rstrip("/")
    payload = {"method": method, "url": norm_url, "ref": ref, "subpath": subpath or ""}
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:32]


def _cache_marker_path(cache_dir: Path) -> Path:
    """Resolved-SHA marker, stored OUTSIDE the worktree
    (`<root>/cache-meta/<key>.sha`) so a cache-hit `git clean -ffdx` can't sweep
    it (keeps the content-addressed cache multi-use)."""
    return cache_dir.parent.parent / "cache-meta" / f"{cache_dir.name}.sha"


def _venv_python(venv_dir: Path) -> Path:
    """Path to the python interpreter inside a venv, cross-platform."""
    if os.name == "nt":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _rmtree_safe(path: Path) -> None:
    """Remove a tree; on Windows a held handle can raise PermissionError, so fall
    back to renaming into the `.trash` sink. Never raises — used on rollback."""
    if not path.exists():
        return
    try:
        shutil.rmtree(path, ignore_errors=False)
        return
    except (PermissionError, OSError):
        pass
    try:
        trash = _install_root() / ".trash"
        trash.mkdir(parents=True, exist_ok=True)
        dest = trash / f"{path.name}-{int(time.time() * 1000)}"
        os.replace(str(path), str(dest))
    except Exception:
        shutil.rmtree(path, ignore_errors=True)


class _InstallLock:
    """Per-key install lockfile (O_CREAT|O_EXCL) so concurrent installers of the
    same pin coalesce instead of racing into the same staging/final dirs. A stale
    lock older than the install timeout is reclaimed."""

    def __init__(self, key: str) -> None:
        self._dir = _install_root() / "locks"
        self._path = self._dir / f"{key}.lock"
        self._fd: int | None = None

    def __enter__(self) -> "_InstallLock":
        self._dir.mkdir(parents=True, exist_ok=True)
        try:
            if self._path.exists():
                age = time.time() - self._path.stat().st_mtime
                if age > _INSTALL_TIMEOUT_S:
                    self._path.unlink()
        except OSError:
            pass
        try:
            self._fd = os.open(str(self._path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(self._fd, str(os.getpid()).encode("ascii"))
        except FileExistsError as e:
            raise BuildError(
                f"{_LOCK_CONTENTION_MARKER} (lock held: {self._path}); "
                "refusing to race",
                phase="install",
                retryable=True,
            ) from e
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
        try:
            self._path.unlink()
        except OSError:
            pass


def sweep_trash() -> int:
    """Delete anything parked in the `.trash` sink by a prior rollback whose file
    handles have since been released. Best-effort; returns the count removed."""
    trash = _install_root() / ".trash"
    if not trash.exists():
        return 0
    removed = 0
    for child in list(trash.iterdir()):
        try:
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=False)
            else:
                child.unlink()
            removed += 1
        except Exception:
            continue
    return removed


# ---------------------------------------------------------------------------
# Local install audit (replaces the dropped Supabase/daemon audit episode)
# ---------------------------------------------------------------------------


def _write_audit_episode(record: dict[str, Any]) -> None:
    """Append a best-effort local audit line under the install root. This REPLACES
    the source's Supabase/daemon audit episode — it is purely local, never on any
    network path, and never raises (an audit hiccup must not fail an install)."""
    try:
        root = _install_root()
        root.mkdir(parents=True, exist_ok=True)
        line = json.dumps({**record, "logged_at": time.time()}, default=str)
        with open(root / "install-audit.jsonl", "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# InstallHandler registry — one handler per runtime.install.method
# ---------------------------------------------------------------------------


@runtime_checkable
class InstallHandler(Protocol):
    """Strategy for one `runtime.install.method`. `materialize` does the
    fetch/probe and returns an exec_ctx; `capabilities` declares the resource
    needs. `requires_confirmation` is EXPLICIT + fail-closed (default True on
    FetchHandler) so a future handler can never silently bypass the confirm
    gate."""

    method: str
    requires_confirmation: bool

    def capabilities(self) -> set[str]:
        ...

    def resolve_source(self, doc: dict[str, Any]) -> dict[str, Any]:
        ...

    def materialize(
        self, doc: dict[str, Any], *, approval_operator: str | None = None
    ) -> dict[str, Any]:
        ...


class FetchHandler:
    """Base for any code-FETCHING install handler. Makes "requires confirmation"
    an EXPLICIT, fail-closed default (True) so every fetch handler is gated unless
    it deliberately opts out (only `_PreinstalledHandler` does)."""

    requires_confirmation: bool = True


class _PreinstalledHandler:
    """`preinstalled` — the artifact is already importable. Runs the python-module
    locator probe and builds an exec_ctx whose argv_prefix is the manifest's
    declared entrypoint command. No fetch, no network, no confirmation."""

    method = "preinstalled"
    requires_confirmation = False

    def capabilities(self) -> set[str]:
        return {"subprocess"}

    def resolve_source(self, doc: dict[str, Any]) -> dict[str, Any]:
        install = ((doc.get("runtime") or {}).get("install")) or {}
        return {"method": self.method, "locator": install.get("locator")}

    def materialize(
        self, doc: dict[str, Any], *, approval_operator: str | None = None
    ) -> dict[str, Any]:
        runtime = doc.get("runtime") or {}
        if runtime.get("kind") != "python-module":
            raise UnsupportedManifestError(
                f"preinstalled handler requires runtime.kind='python-module', "
                f"got {runtime.get('kind')!r}",
                phase="install",
                retryable=False,
            )
        install = runtime.get("install") or {}
        locator = install.get("locator") or {}
        if locator.get("kind") != "python-module":
            raise UnsupportedManifestError(
                f"runtime.install.locator.kind={locator.get('kind')!r} not "
                "supported for preinstalled (only 'python-module')",
                phase="install",
                retryable=False,
            )
        module_name = locator.get("module")
        if not module_name:
            raise UnsupportedManifestError(
                "runtime.install.locator.module is required",
                phase="install",
                retryable=False,
            )
        _probe_python_module(module_name)
        entrypoint = runtime.get("entrypoint") or {}
        return {
            "method": self.method,
            "module": module_name,
            "argv_prefix": list(entrypoint.get("command") or []),
            "cwd": entrypoint.get("cwd") or None,
            "capabilities": sorted(self.capabilities()),
        }


# ---------------------------------------------------------------------------
# SmokeRunner — fail-closed post-install gate (safety invariant #4)
# ---------------------------------------------------------------------------


def _check_smoke_success(
    success: dict[str, Any],
    *,
    exit_code: int | None = None,
    stdout: str | None = None,
    result_obj: Any = None,
) -> tuple[bool, str]:
    """Evaluate a `smoke.success` predicate (logical AND across present fields)
    against a smoke run's outputs. Returns (passed, reason-if-failed)."""
    success = success or {}

    if exit_code is not None:
        want = success.get("exit_code", 0)
        if exit_code != want:
            return False, f"exit_code {exit_code} != required {want}"

    if "stdout_regex" in success and stdout is not None:
        if re.search(success["stdout_regex"], stdout) is None:
            return False, f"stdout did not match {success['stdout_regex']!r}"

    pointer_target = result_obj
    if pointer_target is None and stdout is not None:
        try:
            pointer_target = json.loads(stdout) if stdout.strip() else None
        except json.JSONDecodeError:
            pointer_target = None

    def _resolve_pointer(obj: Any, pointer: str) -> tuple[bool, Any]:
        if pointer == "":
            return True, obj
        cur = obj
        for raw in pointer.lstrip("/").split("/"):
            tok = raw.replace("~1", "/").replace("~0", "~")
            if isinstance(cur, dict) and tok in cur:
                cur = cur[tok]
            elif isinstance(cur, list) and tok.isdigit() and int(tok) < len(cur):
                cur = cur[int(tok)]
            else:
                return False, None
        return True, cur

    for ptr, want in (success.get("json_pointer_equals") or {}).items():
        found, val = _resolve_pointer(pointer_target, ptr)
        if not found or val != want:
            return False, f"json_pointer_equals {ptr!r}: {val!r} != {want!r}"

    for ptr, allowed in (success.get("json_pointer_in") or {}).items():
        found, val = _resolve_pointer(pointer_target, ptr)
        if not found or val not in allowed:
            return False, f"json_pointer_in {ptr!r}: {val!r} not in {allowed!r}"

    if "json_pointer_exists" in success:
        found, _ = _resolve_pointer(pointer_target, success["json_pointer_exists"])
        if not found:
            return False, f"json_pointer_exists {success['json_pointer_exists']!r} unresolved"

    if "json_pointer_present" in success:
        found, val = _resolve_pointer(pointer_target, success["json_pointer_present"])
        if not found or val is None or (isinstance(val, str) and not val.strip()):
            return False, f"json_pointer_present {success['json_pointer_present']!r} null/empty"

    if success.get("no_error_field") and isinstance(pointer_target, dict):
        if "error" in pointer_target:
            return False, "result carries a top-level 'error' field"

    return True, ""


class SmokeRunner:
    """Runs a manifest's `smoke` block against a freshly-installed tool.
    Fail-closed: returns nothing on success; raises SmokeError on ANY failure."""

    def run(
        self,
        *,
        smoke: dict[str, Any],
        tool_id: str,
        exec_ctx: dict[str, Any],
        child_env: dict[str, str],
    ) -> None:
        if not isinstance(smoke, dict) or not smoke.get("kind"):
            raise SmokeError(
                "manifest is missing a required `smoke` block; the fetch path is "
                "smoke-gated and refuses to register an unverified tool",
                phase="smoke",
                retryable=False,
            )
        kind = smoke.get("kind")
        timeout_s = int(smoke.get("timeout_seconds") or 30)
        success = smoke.get("success") or {}

        if kind == "action-call":
            action = smoke.get("action")
            args = smoke.get("arguments") or {}
            try:
                env_obj = call(tool_id, action, params=args, timeout=timeout_s)
            except ManifestError as e:
                raise SmokeError(
                    f"smoke action-call {action!r} raised: {e}",
                    phase="smoke",
                    retryable=False,
                ) from e
            result_obj = env_obj.get("result") if isinstance(env_obj, dict) else env_obj
            ok, reason = _check_smoke_success(success, result_obj=result_obj)
            if not ok:
                raise SmokeError(
                    f"smoke action-call {action!r} predicate failed: {reason}",
                    phase="smoke",
                    retryable=False,
                )
            return

        if kind == "shell":
            command = list(smoke.get("command") or [])
            if not command:
                raise SmokeError(
                    "shell smoke missing `command`", phase="smoke", retryable=False
                )
            try:
                proc = subprocess.run(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=exec_ctx.get("cwd") or None,
                    timeout=timeout_s,
                    check=False,
                    env=child_env,
                )
            except subprocess.TimeoutExpired as e:
                raise SmokeError(
                    f"shell smoke timed out after {timeout_s}s: {command!r}",
                    phase="smoke",
                    retryable=False,
                ) from e
            except FileNotFoundError as e:
                raise SmokeError(
                    f"shell smoke command not found: {command[0]!r}",
                    phase="smoke",
                    retryable=False,
                ) from e
            stdout = proc.stdout.decode("utf-8", errors="replace")
            ok, reason = _check_smoke_success(
                success, exit_code=proc.returncode, stdout=stdout
            )
            if not ok:
                tail = proc.stderr.decode("utf-8", errors="replace")[-500:]
                raise SmokeError(
                    f"shell smoke predicate failed: {reason}; stderr_tail={tail!r}",
                    phase="smoke",
                    retryable=False,
                )
            return

        raise SmokeError(
            f"smoke kind {kind!r} is not implemented by this loader yet; the "
            "fetch path refuses to register a tool whose smoke gate cannot run",
            phase="smoke",
            retryable=False,
        )


# ---------------------------------------------------------------------------
# _GitHandler — SHA-pinned git install, venv-isolated, smoke-gated, atomic
# ---------------------------------------------------------------------------


def _assert_no_escaping_symlink(tree: Path) -> None:
    """Walk `tree` and reject any symlink/junction whose realpath escapes it (an
    exfiltration vector — e.g. a link to `../../.env`). Raises BuildError."""
    root = tree.resolve()
    for dirpath, dirnames, filenames in os.walk(tree):
        for name in list(dirnames) + list(filenames):
            p = Path(dirpath) / name
            if p.is_symlink() or _is_reparse_point(p):
                try:
                    target = p.resolve()
                except OSError:
                    target = None
                contained = False
                if target is not None:
                    try:
                        target.relative_to(root)
                        contained = True
                    except ValueError:
                        contained = False
                if not contained:
                    raise BuildError(
                        f"refusing install: {p} is a symlink/junction whose "
                        f"target escapes the clone ({target!r} not under "
                        f"{root!r}) — exfiltration vector",
                        phase="install",
                        retryable=False,
                    )


def _is_reparse_point(p: Path) -> bool:
    """Windows junction / reparse-point detection (is_symlink misses junctions)."""
    try:
        st = os.lstat(p)
    except OSError:
        return False
    return bool(getattr(st, "st_file_attributes", 0) & 0x400)


# Per-argv config neutralization, prepended after `git` in EVERY loader git
# subprocess — belt-and-suspenders to the env-level GIT_CONFIG_GLOBAL/SYSTEM
# scrub: forces an empty hooks dir + no template dir so no repo/global/system
# hook fires on checkout/reset and no global init.templateDir seeds a clone.
_GIT_CONFIG_HARDENING: list[str] = [
    "-c", "core.hooksPath=",
    "-c", "init.templateDir=",
]


def _scrubbed_git_env(*, allow_file_url: bool = False) -> dict[str, str]:
    """Minimal, scrubbed environment for every git subprocess. Starts from the
    non-secret base allowlist; pins GIT_ALLOW_PROTOCOL (https only in prod, +file
    behind the test opt-in); clears every transport/redirect override; and points
    GIT_CONFIG_GLOBAL/SYSTEM at os.devnull so no external hooksPath/alias applies."""
    env = _safe_base_env()
    env.pop("PYTHONPATH", None)
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GIT_ALLOW_PROTOCOL"] = "https:file" if allow_file_url else "https"
    env["GIT_CONFIG_GLOBAL"] = os.devnull
    env["GIT_CONFIG_SYSTEM"] = os.devnull
    for danger in (
        "GIT_SSH_COMMAND", "GIT_SSH", "GIT_PROXY_COMMAND",
        "GIT_CONFIG", "GIT_CONFIG_COUNT",
    ):
        env.pop(danger, None)
    return env


class _GitHandler(FetchHandler):
    """`git` — clone a SHA-pinned repo, build it in an isolated per-tool venv with
    a stripped env, run the manifest's smoke gate, and only then return an
    exec_ctx pointing at the venv python. Safe by construction: SHA-pin only;
    per-tool venv isolation; content-addressed clone cache; fail-closed smoke;
    atomic staging→final swap; local audit. The confirm gate runs in install()
    before this handler is reached."""

    method = "git"

    def capabilities(self) -> set[str]:
        return {"network", "subprocess", "venv_write"}

    def resolve_source(self, doc: dict[str, Any]) -> dict[str, Any]:
        install_block = ((doc.get("runtime") or {}).get("install")) or {}
        url, ref, subpath, layout = self._resolve_pin(install_block)
        return {
            "method": self.method,
            "url": url,
            "ref": ref,
            "subpath": subpath,
            "layout": layout,
        }

    @staticmethod
    def _validate_git_url(url: str, *, allow_file_url: bool) -> str:
        """Validate a git clone url BEFORE it is handed to git argv: reject a
        `-`-leading url (option injection), control chars (CR/LF/NUL), and any
        scheme but https:// (+ file:// behind the test opt-in)."""
        u = str(url).strip()
        if not u:
            raise FetchError(
                "git install missing 'url'", phase="fetch", retryable=False
            )
        if any(c in u for c in ("\r", "\n", "\x00")):
            raise FetchError(
                f"git url {url!r} contains a control character (CR/LF/NUL); "
                "refused (argv-injection / url-smuggling vector)",
                phase="fetch",
                retryable=False,
            )
        if u.startswith("-"):
            raise FetchError(
                f"git url {url!r} begins with '-'; refused (would be parsed as a "
                "git option — option-injection vector)",
                phase="fetch",
                retryable=False,
            )
        low = u.lower()
        allowed = ("https://",)
        if allow_file_url:
            allowed = allowed + ("file://",)
        if not low.startswith(allowed):
            raise FetchError(
                f"git url scheme not allowed: {url!r}; permitted: {allowed} "
                "(git://, ext::, ssh://, file://(prod) are refused — "
                "unauthenticated-transport / remote-code / redirect vectors)",
                phase="fetch",
                retryable=False,
            )
        return u

    def _resolve_pin(
        self, install_block: dict[str, Any]
    ) -> tuple[str, str, str | None, str]:
        url = install_block.get("url")
        ref = install_block.get("ref")
        subpath = install_block.get("subpath")
        layout = install_block.get("layout") or "package"
        if not url:
            raise FetchError(
                "git install missing 'url'", phase="fetch", retryable=False
            )
        url = self._validate_git_url(url, allow_file_url=_git_allow_file_url())
        if not ref:
            raise FetchError(
                "git install missing 'ref'; pin to a full 40-hex commit SHA",
                phase="fetch",
                retryable=False,
            )
        if not _SHA1_RE.match(str(ref)):
            raise FetchError(
                f"git ref {ref!r} is not a full 40-hex commit SHA; mutable refs "
                "(branch/tag/short-sha) are refused — pin to a SHA",
                phase="fetch",
                retryable=False,
            )
        if layout not in ("package", "skill-bundle", "raw"):
            raise UnsupportedManifestError(
                f"git layout {layout!r} not supported (package|skill-bundle|raw)",
                phase="install",
                retryable=False,
            )
        subpath = self._safe_subpath(subpath)
        return url, str(ref), subpath, layout

    @staticmethod
    def _safe_subpath(subpath: Any) -> str | None:
        """Reject a `subpath` that would escape the clone (absolute, drive-
        qualified, or with a `..` component). Returns a normalized relative path."""
        if not subpath:
            return None
        s = str(subpath).replace("\\", "/").strip()
        if not s:
            return None
        if s.startswith("/") or s.startswith("//") or re.match(r"^[A-Za-z]:", s):
            raise UnsupportedManifestError(
                f"git subpath {subpath!r} must be a repo-relative path, not absolute",
                phase="install",
                retryable=False,
            )
        parts = [p for p in s.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            raise UnsupportedManifestError(
                f"git subpath {subpath!r} escapes the repo (contains '..')",
                phase="install",
                retryable=False,
            )
        return "/".join(parts) or None

    def _git_head(self, cache_dir: Path, git_env: dict[str, str]) -> str | None:
        """`git -C <dir> rev-parse HEAD` with the scrubbed env."""
        head = subprocess.run(
            ["git", "-C", str(cache_dir), *_GIT_CONFIG_HARDENING, "rev-parse", "HEAD"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=git_env,
        )
        if head.returncode != 0:
            return None
        return head.stdout.decode("utf-8", "replace").strip()

    def _force_worktree_to_ref(
        self, cache_dir: Path, ref: str, git_env: dict[str, str]
    ) -> bool:
        """Force the on-disk worktree back to exactly `ref` from `.git`, removing
        any untracked files. Returns True on success, False if either step fails."""
        reset = subprocess.run(
            [
                "git", "-C", str(cache_dir), *_GIT_CONFIG_HARDENING,
                "-c", "core.symlinks=false", "reset", "--hard", ref, "--",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=git_env,
        )
        if reset.returncode != 0:
            return False
        clean = subprocess.run(
            ["git", "-C", str(cache_dir), *_GIT_CONFIG_HARDENING, "clean", "-ffdx"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=git_env,
        )
        return clean.returncode == 0

    def _clone_at_sha(self, url: str, ref: str, cache_dir: Path) -> None:
        """Clone `url` and check out exactly `ref` (a SHA) into cache_dir, reusing
        a verified cache hit when present. All git subprocesses run scrubbed, with
        `--` before url/dest and symlinks disabled."""
        git_env = _scrubbed_git_env(allow_file_url=_git_allow_file_url())
        marker = _cache_marker_path(cache_dir)
        if marker.exists() and marker.read_text(encoding="utf-8").strip() == ref:
            resolved = self._git_head(cache_dir, git_env)
            if resolved == ref and self._force_worktree_to_ref(cache_dir, ref, git_env):
                return
        _rmtree_safe(cache_dir)
        cache_dir.parent.mkdir(parents=True, exist_ok=True)
        clone = subprocess.run(
            [
                "git", *_GIT_CONFIG_HARDENING, "-c", "core.symlinks=false",
                "clone", "--quiet", "--no-checkout", "--", url, str(cache_dir),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=git_env,
        )
        if clone.returncode != 0:
            _rmtree_safe(cache_dir)
            raise FetchError(
                f"git clone failed: {clone.stderr.decode('utf-8', 'replace')[-500:]}",
                phase="fetch",
                retryable=True,
            )
        checkout = subprocess.run(
            [
                "git", "-C", str(cache_dir), *_GIT_CONFIG_HARDENING,
                "-c", "core.symlinks=false", "checkout", "--quiet", ref, "--",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=git_env,
        )
        if checkout.returncode != 0:
            _rmtree_safe(cache_dir)
            raise FetchError(
                f"git checkout {ref!r} failed (SHA not in repo?): "
                f"{checkout.stderr.decode('utf-8', 'replace')[-500:]}",
                phase="fetch",
                retryable=False,
            )
        resolved = self._git_head(cache_dir, git_env)
        if resolved != ref:
            _rmtree_safe(cache_dir)
            raise FetchError(
                f"post-checkout HEAD {resolved!r} != requested SHA {ref!r}",
                phase="fetch",
                retryable=False,
            )
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(ref, encoding="utf-8")

    def _create_venv(self, venv_dir: Path, *, with_pip: bool) -> Path:
        """Create the per-tool venv via the shared substrate."""
        return _create_venv(venv_dir, with_pip=with_pip)

    def _pip_install(
        self, venv_python: Path, target: Path, child_env: dict[str, str]
    ) -> None:
        """`pip install <local target>` for layout=package, in the per-tool venv
        with the stripped child env."""
        res = subprocess.run(
            [
                str(venv_python), "-m", "pip", "install",
                "--disable-pip-version-check", "--no-input", str(target),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=child_env,
        )
        if res.returncode != 0:
            raise BuildError(
                f"pip install failed: {res.stderr.decode('utf-8', 'replace')[-800:]}",
                phase="install",
                retryable=False,
                returncode=res.returncode,
            )

    def materialize(
        self, doc: dict[str, Any], *, approval_operator: str | None = None
    ) -> dict[str, Any]:
        runtime = doc.get("runtime") or {}
        if runtime.get("kind") != "python-module":
            raise UnsupportedManifestError(
                f"git handler currently supports runtime.kind='python-module' "
                f"only, got {runtime.get('kind')!r}",
                phase="install",
                retryable=False,
            )
        install_block = runtime.get("install") or {}
        url, ref, subpath, layout = self._resolve_pin(install_block)

        tool = doc.get("tool") or {}
        tool_id = tool.get("id")
        if not tool_id:
            raise ValidationError(
                "manifest missing tool.id", phase="validate", retryable=False
            )

        root = _install_root()
        key = _cache_key(self.method, url, ref, subpath)
        cache_dir = root / "cache" / key
        staging_dir = root / "staging" / f"{tool_id}-{key}"
        final_dir = root / "installs" / tool_id
        venv_staging_dir = root / "venvs-staging" / f"{tool_id}-{key}"
        venv_dir = root / "venvs" / tool_id

        declared = _declared_env_names(doc)
        child_env = _fetched_child_env(declared, {})

        with _InstallLock(key):
            return self._materialize_locked(
                doc=doc, tool_id=tool_id, url=url, ref=ref, subpath=subpath,
                layout=layout, key=key, cache_dir=cache_dir,
                staging_dir=staging_dir, final_dir=final_dir,
                venv_staging_dir=venv_staging_dir, venv_dir=venv_dir,
                runtime=runtime, child_env=child_env,
                approval_operator=approval_operator,
            )

    def _materialize_locked(
        self, *, doc, tool_id, url, ref, subpath, layout, key, cache_dir,
        staging_dir, final_dir, venv_staging_dir, venv_dir, runtime, child_env,
        approval_operator,
    ) -> dict[str, Any]:
        # 1. clone at SHA (cache-aware, scrubbed env).
        self._clone_at_sha(url, ref, cache_dir)

        # 2. stage a copy so the cache stays pristine; reject escaping symlinks.
        _rmtree_safe(staging_dir)
        staging_dir.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(cache_dir, staging_dir, symlinks=True)
        try:
            _assert_no_escaping_symlink(staging_dir)
        except BuildError:
            _rmtree_safe(staging_dir)
            raise

        code_root = staging_dir / subpath if subpath else staging_dir
        if not code_root.exists():
            _rmtree_safe(staging_dir)
            raise BuildError(
                f"subpath {subpath!r} does not exist in the repo",
                phase="install",
                retryable=False,
            )
        try:
            code_root.resolve().relative_to(staging_dir.resolve())
        except ValueError:
            _rmtree_safe(staging_dir)
            raise BuildError(
                f"code_root {code_root} resolves outside the staging dir "
                f"{staging_dir} — refusing (path-escape)",
                phase="install",
                retryable=False,
            )

        entrypoint = runtime.get("entrypoint") or {}
        command = list(entrypoint.get("command") or [])
        if not command:
            _rmtree_safe(staging_dir)
            raise BuildError(
                "git install requires runtime.entrypoint.command",
                phase="install",
                retryable=False,
            )

        # 3. build the per-tool venv at a staging path.
        try:
            venv_python_staging = self._create_venv(
                venv_staging_dir, with_pip=layout in ("package", "skill-bundle")
            )
        except ManifestError:
            _rmtree_safe(staging_dir)
            raise

        # 4. build (package) / set explicit minimal PYTHONPATH (raw).
        try:
            run_env = dict(child_env)
            run_env.pop("PYTHONPATH", None)
            if layout in ("package", "skill-bundle"):
                self._pip_install(venv_python_staging, code_root, run_env)
            else:
                run_env["PYTHONPATH"] = str(code_root)
        except ManifestError:
            _rmtree_safe(staging_dir)
            _rmtree_safe(venv_staging_dir)
            raise

        smoke_exec_ctx = {
            "method": self.method,
            "module": None,
            "argv_prefix": [str(venv_python_staging)] + command[1:],
            "cwd": str(code_root),
            "capabilities": sorted(self.capabilities()),
        }
        smoke_env = dict(run_env)

        # 5. fail-closed smoke gate against the staged tool.
        _run_smoke_gate_or_purge(
            doc=doc,
            tool_id=tool_id,
            key=key,
            smoke_exec_ctx=smoke_exec_ctx,
            smoke_env=smoke_env,
            purge_paths=[staging_dir, venv_staging_dir],
        )

        final_code_root = (final_dir / subpath) if subpath else final_dir
        venv_python_final = _venv_python(venv_dir)
        exec_ctx = {
            "method": self.method,
            "module": None,
            "argv_prefix": [str(venv_python_final)] + command[1:],
            "cwd": str(final_code_root),
            "capabilities": sorted(self.capabilities()),
            "venv_dir": str(venv_dir),
            "install_dir": str(final_dir),
            "cache_dir": str(cache_dir),
            "staging_dir": str(staging_dir),
            "venv_staging_dir": str(venv_staging_dir),
            "source": {"method": self.method, "url": url, "ref": ref,
                       "subpath": subpath, "layout": layout},
        }

        # 6. transactional swap staging → final (code + venv as one transaction).
        self._transactional_swap(
            code_src=staging_dir, code_dst=final_dir,
            venv_src=venv_staging_dir, venv_dst=venv_dir,
        )

        if layout == "raw":
            exec_ctx["pythonpath"] = str(final_code_root)

        # 7. local audit (best-effort, never blocks).
        _write_audit_episode(
            {
                "tool_id": tool_id,
                "method": self.method,
                "source_url": url,
                "resolved_sha": ref,
                "subpath": subpath,
                "layout": layout,
                "scopes_digest": scopes_digest(doc),
                "data_boundary_digest": data_boundary_digest(doc),
                "entrypoint_digest": entrypoint_digest(doc),
                "approval_operator": approval_operator,
                "install_dir": str(final_dir),
                "venv_dir": str(venv_dir),
            }
        )
        return exec_ctx

    def _provisional_entry(
        self,
        doc: dict[str, Any],
        exec_ctx: dict[str, Any],
        smoke_env: dict[str, str],
        *,
        smoke: dict[str, Any],
    ) -> dict[str, Any]:
        return _build_provisional_entry(doc, exec_ctx, smoke_env, smoke=smoke)

    def _transactional_swap(
        self, *, code_src: Path, code_dst: Path, venv_src: Path, venv_dst: Path
    ) -> None:
        _transactional_swap(
            code_src=code_src, code_dst=code_dst, venv_src=venv_src, venv_dst=venv_dst
        )


# ---------------------------------------------------------------------------
# Shared fetch-substrate helpers (used by _GitHandler AND _PipHandler)
# ---------------------------------------------------------------------------


def _create_venv(venv_dir: Path, *, with_pip: bool) -> Path:
    """Create a per-tool venv (uv if available, else `python -m venv`) and return
    its python. Raises BuildError + purges the venv dir on failure."""
    _rmtree_safe(venv_dir)
    venv_dir.parent.mkdir(parents=True, exist_ok=True)
    if shutil.which("uv"):
        res = subprocess.run(
            ["uv", "venv", str(venv_dir)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
        )
    else:
        cmd = [sys.executable, "-m", "venv", str(venv_dir)]
        if not with_pip:
            cmd.append("--without-pip")
        res = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
        )
    if res.returncode != 0:
        _rmtree_safe(venv_dir)
        raise BuildError(
            f"venv creation failed: {res.stderr.decode('utf-8', 'replace')[-500:]}",
            phase="install",
            retryable=False,
        )
    vp = _venv_python(venv_dir)
    if not vp.exists():
        _rmtree_safe(venv_dir)
        raise BuildError(
            f"venv python not found at {vp}", phase="install", retryable=False
        )
    return vp


def _build_provisional_entry(
    doc: dict[str, Any],
    exec_ctx: dict[str, Any],
    smoke_env: dict[str, str],
    *,
    smoke: dict[str, Any],
) -> dict[str, Any]:
    """A minimal `_INSTALLED` entry sufficient for SmokeRunner's action-call path
    to drive the tool during the smoke gate. Exposes ONLY the single smoke action,
    under a staging-namespaced key the public `call()` can't address."""
    ctx = dict(exec_ctx)
    if "pythonpath" not in ctx and smoke_env.get("PYTHONPATH"):
        ctx["pythonpath"] = smoke_env["PYTHONPATH"]
    actions = doc.get("actions") or []
    all_actions = {a["name"]: a for a in actions if "name" in a}
    smoke_action = smoke.get("action") if isinstance(smoke, dict) else None
    if smoke_action and smoke_action in all_actions:
        exposed = {smoke_action: all_actions[smoke_action]}
    else:
        exposed = {}
    return {
        "tool_id": (doc.get("tool") or {}).get("id"),
        "actions": exposed,
        "exec_ctx": ctx,
        "declared_env": _declared_env_names(doc),
    }


def _run_smoke_gate_or_purge(
    *,
    doc: dict[str, Any],
    tool_id: str,
    key: str,
    smoke_exec_ctx: dict[str, Any],
    smoke_env: dict[str, str],
    purge_paths: list[Path],
) -> None:
    """Invariant #4: run the fail-closed smoke gate against the still-staged tool
    under a staging-namespaced key, purging every `purge_paths` entry on ANY
    failure and re-raising — nothing registered, any prior install untouched."""
    smoke = doc.get("smoke") or {}
    staging_key = f"__staging__:{tool_id}:{key}"
    provisional = _build_provisional_entry(doc, smoke_exec_ctx, smoke_env, smoke=smoke)
    _INSTALLED[staging_key] = provisional
    smoke_ok = False
    try:
        SmokeRunner().run(
            smoke=smoke,
            tool_id=staging_key,
            exec_ctx=provisional["exec_ctx"],
            child_env=smoke_env,
        )
        smoke_ok = True
    finally:
        _INSTALLED.pop(staging_key, None)
        if not smoke_ok:
            for p in purge_paths:
                _rmtree_safe(p)


def _transactional_swap(
    *, code_src: Path, code_dst: Path, venv_src: Path, venv_dst: Path
) -> None:
    """Move the staged code + venv into their final paths as ONE transaction. The
    prior install is moved ASIDE (not deleted) only AFTER the new dir is
    committed; a failed second swap rolls the first back."""

    def _aside(p: Path) -> Path | None:
        if not p.exists():
            return None
        trash = _install_root() / ".trash"
        trash.mkdir(parents=True, exist_ok=True)
        dest = trash / f"{p.name}-{int(time.time() * 1000000)}"
        os.replace(str(p), str(dest))
        return dest

    def _move_in(src: Path, dst: Path) -> None:
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.replace(str(src), str(dst))
        except OSError:
            shutil.copytree(src, dst, symlinks=True)
            _rmtree_safe(src)

    old_code = _aside(code_dst)
    try:
        _move_in(code_src, code_dst)
    except Exception:
        if old_code is not None:
            try:
                os.replace(str(old_code), str(code_dst))
            except OSError:
                pass
        raise

    old_venv = _aside(venv_dst)
    try:
        _move_in(venv_src, venv_dst)
    except Exception:
        _rmtree_safe(code_dst)
        if old_code is not None:
            try:
                os.replace(str(old_code), str(code_dst))
            except OSError:
                pass
        if old_venv is not None:
            try:
                os.replace(str(old_venv), str(venv_dst))
            except OSError:
                raise BuildError(
                    "MANUAL RECOVERY NEEDED: venv swap failed after code swap, "
                    "and rolling the prior venv back ALSO failed. The prior venv "
                    f"is parked at {old_venv} — move it back to {venv_dst} by "
                    "hand to restore the prior install.",
                    phase="install",
                    retryable=False,
                ) from None
        raise BuildError(
            "venv swap failed after code swap; rolled back to the prior install "
            "(code+venv treated as one transaction)",
            phase="install",
            retryable=False,
        )


class _PipHandler(FetchHandler):
    """`pip` — install a VERSION-PINNED PyPI package into an isolated per-tool venv
    with a stripped env, run the manifest's smoke gate, and only then return an
    exec_ctx pointing at the venv python. Rides the same proven substrate as
    `_GitHandler` (confirm gate, venv, stripped env, fail-closed smoke, atomic
    swap, source_digest binding). Integrity-honest: a missing `version_spec` is
    refused (unpinned 'latest'); the requirement must be a plain pinned PyPI
    package (no direct URL/VCS/local path/markers/extras)."""

    method = "pip"

    def capabilities(self) -> set[str]:
        return {"network", "subprocess", "venv_write"}

    def _resolve_pin(self, install_block: dict[str, Any]) -> tuple[str, str]:
        package = install_block.get("package")
        if not package or not str(package).strip():
            raise FetchError(
                "pip install missing 'package'", phase="fetch", retryable=False
            )
        package = str(package).strip()
        if package.startswith("-"):
            raise FetchError(
                f"pip package {package!r} begins with '-'; refused (option-injection)",
                phase="fetch",
                retryable=False,
            )
        if any(c in package for c in (" ", "\t", "\r", "\n", "\x00")):
            raise FetchError(
                f"pip package {package!r} contains whitespace/control characters; "
                "refused (argv-injection / requirement-smuggling vector)",
                phase="fetch",
                retryable=False,
            )
        spec = normalize_version_spec(install_block.get("version_spec"))
        if spec is None:
            raise FetchError(
                f"pip install of {package!r} has no 'version_spec'; installing "
                "'latest' is an unpinned moving target with no artifact hash — "
                "refused. Pin to an exact '==<version>' (or a bounded range).",
                phase="fetch",
                retryable=False,
            )
        if spec.startswith("-"):
            raise FetchError(
                f"pip version_spec {spec!r} begins with '-'; refused (option-injection)",
                phase="fetch",
                retryable=False,
            )
        if any(c in spec for c in ("\r", "\n", "\x00")):
            raise FetchError(
                f"pip version_spec {spec!r} contains a control character; refused",
                phase="fetch",
                retryable=False,
            )
        if not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?", package):
            raise FetchError(
                f"pip package {package!r} is not a plain PEP 503 distribution name; "
                "refused (only a pinned PyPI package — no URLs, VCS, local paths, "
                "or extras).",
                phase="fetch",
                retryable=False,
            )
        try:
            from packaging.requirements import (  # noqa: PLC0415
                InvalidRequirement,
                Requirement,
            )
        except Exception as exc:  # pragma: no cover - packaging is ubiquitous
            raise FetchError(
                "cannot validate pip requirement (packaging unavailable); refused",
                phase="fetch",
                retryable=False,
            ) from exc
        try:
            req = Requirement(pip_install_argument(package, spec))
        except InvalidRequirement as exc:
            raise FetchError(
                f"pip requirement for {package!r}{spec!r} is not a valid "
                f"name+version requirement; refused: {exc}",
                phase="fetch",
                retryable=False,
            ) from exc
        if req.url is not None:
            raise FetchError(
                f"pip requirement resolves to a direct URL/VCS/local install "
                f"({req.url!r}); refused — only a pinned PyPI package is allowed.",
                phase="fetch",
                retryable=False,
            )
        if req.marker is not None:
            raise FetchError(
                f"pip requirement carries an environment marker "
                f"({str(req.marker)!r}); refused (host-conditional install is a "
                "review-evasion vector).",
                phase="fetch",
                retryable=False,
            )
        if req.extras:
            raise FetchError(
                f"pip requirement requests extras {sorted(req.extras)!r}; refused "
                "(extras are not modeled — pin the concrete package).",
                phase="fetch",
                retryable=False,
            )
        return package, spec

    def resolve_source(self, doc: dict[str, Any]) -> dict[str, Any]:
        install_block = ((doc.get("runtime") or {}).get("install")) or {}
        package, spec = self._resolve_pin(install_block)
        return {"method": self.method, "package": package, "version_spec": spec}

    def _pip_install_package(
        self, venv_python: Path, requirement: str, child_env: dict[str, str]
    ) -> None:
        """`pip install "<package><version_spec>"` into the per-tool venv with the
        stripped env. `--isolated` ignores all pip config + PIP_* env vars; the
        explicit `--index-url` pins the registry; `--` guards a `-`-leading value."""
        res = subprocess.run(
            [
                str(venv_python), "-m", "pip", "install", "--isolated",
                "--index-url", "https://pypi.org/simple/",
                "--disable-pip-version-check", "--no-input", "--", requirement,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=_INSTALL_TIMEOUT_S,
            check=False,
            env=child_env,
        )
        if res.returncode != 0:
            raise BuildError(
                f"pip install {requirement!r} failed: "
                f"{res.stderr.decode('utf-8', 'replace')[-800:]}",
                phase="install",
                retryable=False,
                returncode=res.returncode,
            )

    def materialize(
        self, doc: dict[str, Any], *, approval_operator: str | None = None
    ) -> dict[str, Any]:
        runtime = doc.get("runtime") or {}
        if runtime.get("kind") != "python-module":
            raise UnsupportedManifestError(
                f"pip handler currently supports runtime.kind='python-module' "
                f"only, got {runtime.get('kind')!r}",
                phase="install",
                retryable=False,
            )
        install_block = runtime.get("install") or {}
        package, spec = self._resolve_pin(install_block)

        tool = doc.get("tool") or {}
        tool_id = tool.get("id")
        if not tool_id:
            raise ValidationError(
                "manifest missing tool.id", phase="validate", retryable=False
            )

        entrypoint = runtime.get("entrypoint") or {}
        command = list(entrypoint.get("command") or [])
        if not command:
            raise BuildError(
                "pip install requires runtime.entrypoint.command",
                phase="install",
                retryable=False,
            )

        root = _install_root()
        key = _cache_key(self.method, package, spec, None)
        final_dir = root / "installs" / tool_id
        staging_dir = root / "staging" / f"{tool_id}-{key}"
        venv_staging_dir = root / "venvs-staging" / f"{tool_id}-{key}"
        venv_dir = root / "venvs" / tool_id

        declared = _declared_env_names(doc)
        child_env = _fetched_child_env(declared, {})

        with _InstallLock(key):
            return self._materialize_locked(
                doc=doc, tool_id=tool_id, package=package, spec=spec,
                command=command, key=key, staging_dir=staging_dir,
                final_dir=final_dir, venv_staging_dir=venv_staging_dir,
                venv_dir=venv_dir, child_env=child_env,
                approval_operator=approval_operator,
            )

    def _materialize_locked(
        self, *, doc, tool_id, package, spec, command, key, staging_dir,
        final_dir, venv_staging_dir, venv_dir, child_env, approval_operator,
    ) -> dict[str, Any]:
        # 1. stage a tiny marker dir (the venv is the real artifact).
        _rmtree_safe(staging_dir)
        staging_dir.parent.mkdir(parents=True, exist_ok=True)
        staging_dir.mkdir(parents=True, exist_ok=True)
        (staging_dir / ".yep_pip_marker").write_text(
            f"pip:{package}{spec}", encoding="utf-8"
        )

        # 2. build the per-tool venv at a staging path (pip needed in it).
        try:
            venv_python_staging = _create_venv(venv_staging_dir, with_pip=True)
        except ManifestError:
            _rmtree_safe(staging_dir)
            raise

        # 3. pip install the EXACT approved requirement into the staging venv.
        requirement = pip_install_argument(package, spec)
        try:
            run_env = dict(child_env)
            run_env.pop("PYTHONPATH", None)
            self._pip_install_package(venv_python_staging, requirement, run_env)
        except ManifestError:
            _rmtree_safe(staging_dir)
            _rmtree_safe(venv_staging_dir)
            raise

        # 4. fail-closed smoke gate.
        smoke_exec_ctx = {
            "method": self.method,
            "module": None,
            "argv_prefix": [str(venv_python_staging)] + command[1:],
            "cwd": str(staging_dir),
            "capabilities": sorted(self.capabilities()),
        }
        smoke_env = dict(run_env)
        _run_smoke_gate_or_purge(
            doc=doc,
            tool_id=tool_id,
            key=key,
            smoke_exec_ctx=smoke_exec_ctx,
            smoke_env=smoke_env,
            purge_paths=[staging_dir, venv_staging_dir],
        )

        venv_python_final = _venv_python(venv_dir)
        exec_ctx = {
            "method": self.method,
            "module": None,
            "argv_prefix": [str(venv_python_final)] + command[1:],
            "cwd": str(final_dir),
            "capabilities": sorted(self.capabilities()),
            "venv_dir": str(venv_dir),
            "install_dir": str(final_dir),
            "staging_dir": str(staging_dir),
            "venv_staging_dir": str(venv_staging_dir),
            "source": {"method": self.method, "package": package, "version_spec": spec},
        }

        # 5. transactional swap staging → final.
        _transactional_swap(
            code_src=staging_dir, code_dst=final_dir,
            venv_src=venv_staging_dir, venv_dst=venv_dir,
        )

        # 6. local audit (best-effort).
        _write_audit_episode(
            {
                "tool_id": tool_id,
                "method": self.method,
                "package": package,
                "version_spec": spec,
                "pip_command": f"pip install {requirement}",
                "source_digest": source_digest(exec_ctx["source"]),
                "scopes_digest": scopes_digest(doc),
                "data_boundary_digest": data_boundary_digest(doc),
                "entrypoint_digest": entrypoint_digest(doc),
                "approval_operator": approval_operator,
                "install_dir": str(final_dir),
                "venv_dir": str(venv_dir),
            }
        )
        return exec_ctx


# Registered handlers. npm / url / container are deliberately UNregistered (and
# url / container are also refused up-front by the compatibility fence).
_INSTALL_HANDLERS: dict[str, InstallHandler] = {
    _PreinstalledHandler.method: _PreinstalledHandler(),
    _GitHandler.method: _GitHandler(),
    _PipHandler.method: _PipHandler(),
}


# ---------------------------------------------------------------------------
# Install-time credential provisioning (T6.2) — read manifest env[], store
# secrets in the OS keyring + config in the local file, skip already-stored.
# ---------------------------------------------------------------------------
#
# A value source for one declared env entry. Receives the entry context
# ({name, prompt, secret, tool_id, data_boundary}) and returns the value to
# store, or None to defer (leave unprovisioned). Tests inject one to avoid a
# real terminal; the default reads the TTY and fails non-blocking when headless.
EnvProvisionFn = Callable[[dict[str, Any]], "str | None"]


def _env_items(doc: dict[str, Any]) -> list[dict[str, Any]]:
    """The manifest's declared `env[]` entries (each {name, prompt, secret}), in
    prompt order, defensively normalized."""
    out: list[dict[str, Any]] = []
    for item in doc.get("env") or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if isinstance(name, str) and name:
            out.append(
                {
                    "name": name,
                    "prompt": item.get("prompt") or "",
                    "secret": bool(item.get("secret")),
                }
            )
    return out


def _default_env_prompt(ctx: dict[str, Any]) -> "str | None":
    """The default install-time prompter for one declared env entry. Reads the
    value from the terminal (hidden, via getpass, for secrets). Returns None on
    EOF/interrupt/empty — the entry is then DEFERRED, never forced. Never echoes
    or logs the value."""
    name = ctx["name"]
    secret = ctx["secret"]
    text = ctx.get("prompt") or ""
    try:
        print(f"\n  {name} — {text}", file=sys.stderr, flush=True)
    except Exception:
        pass
    try:
        if secret:
            import getpass

            val = getpass.getpass(
                f"  Enter {name} (input hidden; stored in the OS keyring): "
            )
        else:
            val = _read_confirm_line(
                f"  Enter {name} (non-secret config; stored in tool_config.toml): "
            )
    except (EOFError, KeyboardInterrupt):
        return None
    # input()/getpass() already drop the trailing newline; keep any inner
    # whitespace verbatim (some tokens are whitespace-sensitive). Empty ⇒ defer.
    return val if val else None


def _render_provision_banner(
    *, tool_id: str, version: Any, name: Any, data_boundary: dict[str, Any], n: int
) -> str:
    """The one-time banner shown before prompting for a tool's credentials —
    surfaces the data_boundary so the user knows where their cred may flow."""
    bar = "=" * 72
    lines = [
        "",
        bar,
        "  Local Yep — this tool needs credentials (stored locally only)",
        bar,
        f"  tool:          {tool_id} v{version}  ({name})",
        f"  needs:         {n} value(s)",
        f"  data_boundary: {json.dumps(data_boundary or {})}",
        "  Secrets go to your OS keyring; non-secret config to "
        "~/.local-yep/tool_config.toml.",
        "  Press Enter to skip any value (set it later: yepgent secrets set ...).",
        "-" * 72,
    ]
    return "\n".join(lines)


def _provision_env(
    doc: dict[str, Any],
    *,
    tool_id: str,
    prompt: EnvProvisionFn | None = None,
) -> dict[str, Any]:
    """Collect the manifest's declared `env[]` and store each value locally (T6.2).

    `secret:true` → the OS keyring; config → the plaintext tool-config file. Any
    name already provisioned in the store, or already present in `os.environ`, is
    SKIPPED so a re-install never re-prompts. Non-blocking: with no injected
    `prompt` and no interactive terminal, all unfilled entries are DEFERRED (the
    user runs `yepgent secrets set ...` later) rather than hanging an automated
    install.

    Returns {stored, skipped, deferred} lists of names. Storage failures (e.g.
    no keyring backend) defer that entry with guidance rather than raising — the
    tool is already installed; creds can be supplied later."""
    from local_yep import secrets as _secrets

    items = _env_items(doc)
    summary: dict[str, list[str]] = {"stored": [], "skipped": [], "deferred": []}
    if not items:
        return summary

    pending: list[dict[str, Any]] = []
    for item in items:
        name = item["name"]
        if _secrets.has_value(tool_id, name) or os.environ.get(name) is not None:
            summary["skipped"].append(name)
            continue
        pending.append(item)

    if not pending:
        return summary

    interactive = prompt is not None or _stdin_is_tty()
    if not interactive:
        # Headless / automated install: never block. Leave them for the CLI.
        summary["deferred"].extend(p["name"] for p in pending)
        return summary

    tool = doc.get("tool") or {}
    if prompt is None:
        try:
            print(
                _render_provision_banner(
                    tool_id=tool_id,
                    version=tool.get("version"),
                    name=tool.get("name"),
                    data_boundary=doc.get("data_boundary") or {},
                    n=len(pending),
                ),
                file=sys.stderr,
                flush=True,
            )
        except Exception:
            pass

    prompter = prompt if prompt is not None else _default_env_prompt
    data_boundary = doc.get("data_boundary") or {}
    for item in pending:
        ctx = dict(item)
        ctx["tool_id"] = tool_id
        ctx["data_boundary"] = data_boundary
        try:
            value = prompter(ctx)
        except Exception:
            value = None
        if not value:
            summary["deferred"].append(item["name"])
            continue
        try:
            if item["secret"]:
                _secrets.set_secret(tool_id, item["name"], value)
            else:
                _secrets.set_config(tool_id, item["name"], value)
            summary["stored"].append(item["name"])
        except _secrets.NoKeyringError as exc:
            try:
                print(f"  {item['name']}: {exc}", file=sys.stderr, flush=True)
            except Exception:
                pass
            summary["deferred"].append(item["name"])
        except Exception:
            summary["deferred"].append(item["name"])
    return summary


# ---------------------------------------------------------------------------
# Install — fence → validate → (confirm gate) → materialize → durable register
# ---------------------------------------------------------------------------


def install(
    doc_or_url: Any,
    *,
    confirm: ConfirmFn | None = None,
    approval: dict[str, Any] | None = None,
    provision_prompt: EnvProvisionFn | None = None,
) -> dict[str, Any]:
    """Compatibility-fence → validate → (local confirm gate for code-fetching) →
    dispatch to the install handler → register in the durable index. Idempotent
    on an already-approved identical pin (no re-prompt).

    `doc_or_url` may be a manifest dict or a URL string. Returns the public
    registry entry.

    Flow:
      1. resolve doc (fetch if URL)
      2. COMPATIBILITY FENCE (T4.7) — refuse we-run-a-service manifests
      3. schema validation (`install_manifest`)
      4. look up `_INSTALL_HANDLERS[method]`; no handler → refuse
      5. for code-fetching handlers: refuse empty scopes; resolve the source;
         if the durable index already holds this tool at the SAME approved pin →
         return idempotently with NO prompt (T4.5); else drive the LOCAL confirm
         gate (T4.6) before any clone/build
      6. handler.materialize(doc) → exec_ctx
      7. register the entry (carrying the approved-pin digests + approval source)
         and PERSIST the durable index.

    `approval` is accepted-but-ignored (back-compat shim) — proof comes only from
    `confirm`.
    """
    del approval  # accepted-but-ignored; proof comes only from `confirm`.
    if isinstance(doc_or_url, str):
        doc = fetch_manifest(doc_or_url)
    elif isinstance(doc_or_url, dict):
        doc = doc_or_url
    else:
        raise TypeError(
            f"install() takes dict or URL str, got {type(doc_or_url).__name__}"
        )

    # Compatibility fence (T4.7) — BEFORE schema validation so a we-run-a-service
    # shape is refused with a clear reason even if it would also fail the schema.
    _compatibility_fence(doc)

    vr = validate_manifest(doc)
    if not vr["ok"]:
        raise ValidationError(
            f"manifest failed schema validation: {vr['summary']}; "
            f"errors={vr['errors']}",
            phase="validate",
            retryable=False,
        )

    runtime = doc.get("runtime") or {}
    install_block = runtime.get("install") or {}
    method = install_block.get("method")
    handler = _INSTALL_HANDLERS.get(method)
    if handler is None:
        raise UnsupportedManifestError(
            f"no install handler registered for method {method!r} "
            f"(registered: {sorted(_INSTALL_HANDLERS)})",
            phase="install",
            retryable=False,
        )

    tool = doc.get("tool") or {}
    tool_id = tool.get("id")
    if not tool_id:
        raise ValidationError(
            "manifest missing tool.id", phase="validate", retryable=False
        )

    # Live-confirm gate (invariant #2) + durable idempotency (T4.5).
    approval_operator: str | None = None
    approved_source_digest: str | None = None
    if getattr(handler, "requires_confirmation", True):
        _require_scopes(doc, method=method)
        source = handler.resolve_source(doc)
        sdig = source_digest(source)
        tdig = tool_identity_digest(doc)
        prior = _INSTALLED.get(tool_id)
        if (
            prior
            and prior.get("approved_source_digest") == sdig
            and prior.get("tool_identity_digest") == tdig
        ):
            # Already approved at THIS exact pin (rehydrated from the durable
            # index across a restart, or installed earlier this session) → return
            # idempotently with NO prompt and NO re-materialize.
            return _public_entry(prior)
        approval_operator = _run_confirmation(doc, source=source, confirm=confirm)
        approved_source_digest = sdig

    exec_ctx = handler.materialize(doc, approval_operator=approval_operator)

    actions = doc.get("actions") or []
    actions_by_name = {a["name"]: a for a in actions if "name" in a}

    prior = _INSTALLED.get(tool_id)
    installed_at = (prior or {}).get("installed_at")
    if installed_at is None:
        installed_at = time.time()

    entry = {
        "tool_id": tool_id,
        "version": tool.get("version"),
        "name": tool.get("name"),
        "summary": tool.get("summary"),
        "module": exec_ctx.get("module"),
        "method": method,
        "entrypoint": (runtime.get("entrypoint") or {}),
        "exec_ctx": exec_ctx,
        "capabilities": exec_ctx.get("capabilities") or sorted(handler.capabilities()),
        "actions": actions_by_name,
        "scopes": doc.get("scopes") or [],
        "kill_switch": doc.get("kill_switch") or {},
        "data_boundary": doc.get("data_boundary") or {},
        "declared_env": _declared_env_names(doc),
        "verification_status": doc.get("verification_status"),
        "source": _source_summary(install_block),
        "pin_warnings": vr.get("pin_warnings") or [],
        "installed_at": installed_at,
        # Durable-index approval provenance (T4.5): the approved pin digest + the
        # tool-identity digest (for the no-re-prompt idempotency check), the
        # approval source, and the resolved venv path live in `exec_ctx`/`source`.
        "approved_source_digest": approved_source_digest,
        "tool_identity_digest": tool_identity_digest(doc),
        "approval_source": (
            approval_operator
            if approval_operator
            else ("preinstalled" if not getattr(handler, "requires_confirmation", True)
                  else None)
        ),
        "manifest": doc,
    }
    _INSTALLED[tool_id] = entry
    _persist_index()

    # Install-time credential provisioning (T6.2): prompt for the manifest's
    # declared env[] (secret → keyring, config → local file), skipping anything
    # already stored or already in os.environ. Best-effort + non-blocking — a
    # prompt/keyring hiccup must never undo an otherwise-successful install (the
    # user can fill creds later via `yepgent secrets set`).
    try:
        _provision_env(doc, tool_id=tool_id, prompt=provision_prompt)
    except Exception:
        pass

    return _public_entry(entry)


def _public_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Return the registry entry view suitable for the API surface — strips the
    raw manifest blob, surfaces the blast-radius fields + capabilities +
    pin_warnings + the durable approval provenance."""
    return {
        "tool_id": entry["tool_id"],
        "version": entry.get("version"),
        "name": entry.get("name"),
        "summary": entry.get("summary"),
        "module": entry.get("module"),
        "method": entry.get("method"),
        "actions": sorted((entry.get("actions") or {}).keys()),
        "scopes": entry.get("scopes") or [],
        "kill_switch": entry.get("kill_switch") or {},
        "data_boundary": entry.get("data_boundary") or {},
        "verification_status": entry.get("verification_status"),
        "source": entry.get("source") or {},
        "capabilities": entry.get("capabilities") or [],
        "pin_warnings": entry.get("pin_warnings") or [],
        "installed_at": entry.get("installed_at"),
        "approval_source": entry.get("approval_source"),
    }


def list_installed() -> list[dict[str, Any]]:
    return [
        _public_entry(e)
        for tid, e in _INSTALLED.items()
        if not str(tid).startswith("__staging__:")
    ]


def get_installed_auth(tool_id: str) -> dict[str, Any] | None:
    """Return the OAuth `auth` block for an installed tool (Model B), or None if
    the tool isn't installed or declares no auth. The CLI `yepgent tools auth`
    uses this to drive the flow without re-fetching the manifest."""
    entry = _INSTALLED.get(tool_id)
    if entry is None:
        return None
    return _manifest_auth(entry.get("manifest") or {})


def uninstall(tool_id: str) -> dict[str, Any]:
    """Remove a tool from the registry + the durable index. For fetched tools
    (git/pip) this also deletes the on-disk install dir + per-tool venv + the
    content-addressed cache/staging trees recorded in the exec_ctx."""
    entry = _INSTALLED.get(tool_id)
    if entry is None:
        return {"removed": False, "tool_id": tool_id}
    exec_ctx = entry.get("exec_ctx") or {}
    for key in (
        "install_dir", "venv_dir", "cache_dir", "staging_dir", "venv_staging_dir",
    ):
        path = exec_ctx.get(key)
        if path:
            _rmtree_safe(Path(path))
    cache_dir = exec_ctx.get("cache_dir")
    if cache_dir:
        try:
            _cache_marker_path(Path(cache_dir)).unlink(missing_ok=True)
        except OSError:
            pass
    del _INSTALLED[tool_id]
    _persist_index()
    # Purge the tool's locally-stored credentials (T6.2/T6.4): once the tool is
    # gone its keyring secrets + config are orphaned, so remove them. Best-effort
    # — a missing secrets module/keyring must not block the uninstall.
    purged: dict[str, Any] = {"secrets": [], "config": []}
    try:
        from local_yep import secrets as _secrets

        purged = _secrets.purge_tool(tool_id)
    except Exception:
        pass
    return {"removed": True, "tool_id": tool_id, "purged_credentials": purged}


# ---------------------------------------------------------------------------
# Invocation — template substitution + subprocess dispatch
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"\$\{(input|env)\.([A-Za-z_][A-Za-z0-9_.]*)\}")


def _resolve_path(root: dict[str, Any], dotted: str) -> Any:
    cur: Any = root
    for seg in dotted.split("."):
        if not isinstance(cur, dict) or seg not in cur:
            raise KeyError(f"${{input.{dotted}}} unresolved")
        cur = cur[seg]
    return cur


def _substitute(template: str, inputs: dict[str, Any], env: dict[str, str]) -> str:
    """Replace ${input.x} / ${env.X} tokens in a single argv string. Non-string
    substituted values are JSON-encoded so dicts/lists/numbers round-trip into
    argv positions."""

    def _repl(m: re.Match) -> str:
        ns, path = m.group(1), m.group(2)
        if ns == "input":
            try:
                v = _resolve_path(inputs, path)
            except KeyError as e:
                raise KeyError(str(e)) from e
        else:
            if path not in env:
                raise KeyError(f"${{env.{path}}} not set")
            v = env[path]
        return v if isinstance(v, str) else json.dumps(v)

    return _TOKEN_RE.sub(_repl, template)


def _render_argv(
    template: list[str], inputs: dict[str, Any], env: dict[str, str]
) -> list[str]:
    return [_substitute(s, inputs, env) for s in template]


# ---------------------------------------------------------------------------
# Child environment — non-secret allowlist, NEVER os.environ wholesale
# ---------------------------------------------------------------------------

_BASE_ENV_ALLOWLIST = (
    "PATH",
    "PATHEXT",
    "SystemRoot",
    "SystemDrive",
    "COMSPEC",
    "TEMP",
    "TMP",
    "NUMBER_OF_PROCESSORS",
    "OS",
    "PYTHONPATH",
)

_POSIX_ENV_ALLOWLIST = (
    "HOME",
    "LANG",
    "LC_ALL",
    "TMPDIR",
)


def _safe_base_env() -> dict[str, str]:
    """Allowlisted, non-secret base environment for the child subprocess. NEVER
    returns the parent's full environment — secret-bearing vars reach the child
    only via the manifest's declared `env[]`."""
    names = _BASE_ENV_ALLOWLIST
    if os.name != "nt":
        names = names + _POSIX_ENV_ALLOWLIST
    out: dict[str, str] = {}
    for name in names:
        val = os.environ.get(name)
        if val is not None:
            out[name] = val
    return out


def _store_env_resolver(tool_id: str) -> Callable[[str], str | None]:
    """Value source for a tool's declared `env[]` at call() time (T6.3): the
    LOCAL secret store (keyring secrets + plaintext config, namespaced by
    `tool_id`) first, then the process environment as a fallback. So a key the
    user provisioned into the keyring reaches the tool even when nothing is in
    the parent `os.environ`; an unprovisioned-but-exported var still works.

    The secret is injected only into the child's environment — never argv (the
    invocation transports forbid templating secrets into argv) and never logged.
    `local_yep.secrets` is imported lazily so the loader keeps importing on the
    free path where the optional `keyring` extra is absent."""

    def _resolve(name: str) -> str | None:
        try:
            from local_yep import secrets as _secrets

            val = _secrets.resolve(tool_id, name)
            if val is not None:
                return val
        except Exception:
            # A missing/unreadable store must never break a call — fall back.
            pass
        return os.environ.get(name)

    return _resolve


def _child_env(
    declared_env: list[str],
    explicit_env: dict[str, str],
    resolve: Callable[[str], str | None] | None = None,
) -> dict[str, str]:
    """Child env = `_safe_base_env()` ∪ {declared env[] vars resolved by
    `resolve`} ∪ explicit `env=`. os.environ is NEVER passed wholesale. This is
    the PREINSTALLED env: it KEEPS the inherited PYTHONPATH (a preinstalled tool
    resolves `python -m <module>` from the parent import root). Fetched tools use
    `_fetched_child_env` (which strips it).

    `resolve` maps a declared env NAME → its value (or None). It defaults to
    `os.environ.get`; `call()` passes a store-first resolver (T6.3) so secrets
    come from the keyring, not just the ambient environment."""
    env = _safe_base_env()
    _resolve = resolve if resolve is not None else os.environ.get
    for name in declared_env or ():
        val = _resolve(name)
        if val is not None:
            env[name] = val
    if explicit_env:
        env.update(explicit_env)
    return env


def _fetched_child_env(
    declared_env: list[str],
    explicit_env: dict[str, str],
    resolve: Callable[[str], str | None] | None = None,
) -> dict[str, str]:
    """Child env for a FETCHED tool (git/pip). Identical to `_child_env` EXCEPT
    the inherited PYTHONPATH is stripped — the parent PYTHONPATH could let the
    fetched tool import the host's own modules and defeat venv isolation. The
    handler sets the import path explicitly+minimally instead."""
    env = _child_env(declared_env, explicit_env, resolve=resolve)
    if "PYTHONPATH" not in (explicit_env or {}):
        env.pop("PYTHONPATH", None)
    return env


# ---------------------------------------------------------------------------
# InvocationStrategy registry — one strategy per actions[].invocation.kind
# ---------------------------------------------------------------------------


@runtime_checkable
class InvocationStrategy(Protocol):
    """Strategy for one `actions[].invocation.kind`. `invoke` builds the transport
    and returns the result envelope from `_run_subprocess`."""

    kind: str

    def invoke(
        self,
        *,
        exec_ctx: dict[str, Any],
        invocation: dict[str, Any],
        inputs: dict[str, Any],
        env_map: dict[str, str],
        timeout_s: int,
    ) -> dict[str, Any]:
        ...


def _base_argv_from_ctx(exec_ctx: dict[str, Any]) -> list[str]:
    """Resolve argv[0..] from the handler-produced exec_ctx — the
    interpreter-resolution seam (preinstalled = the manifest's entrypoint command;
    fetch handlers = the per-tool venv python)."""
    base_argv = list((exec_ctx or {}).get("argv_prefix") or [])
    if not base_argv:
        tool_id = (exec_ctx or {}).get("_tool_id", "?")
        raise InvocationError(
            f"tool {tool_id!r} has no exec_ctx argv_prefix (entrypoint.command)",
            phase="invoke",
            retryable=False,
        )
    return base_argv


class _SubcommandStrategy:
    """`subcommand` — argv = exec_ctx.argv_prefix + rendered argv_template, no
    stdin."""

    kind = "subcommand"

    def invoke(
        self,
        *,
        exec_ctx: dict[str, Any],
        invocation: dict[str, Any],
        inputs: dict[str, Any],
        env_map: dict[str, str],
        timeout_s: int,
    ) -> dict[str, Any]:
        argv_tpl = invocation.get("argv_template") or []
        base_argv = _base_argv_from_ctx(exec_ctx)
        argv = base_argv + _render_argv(argv_tpl, inputs, env_map)
        cwd = exec_ctx.get("cwd") or None
        return _run_subprocess(
            argv, stdin_bytes=None, cwd=cwd, timeout_s=timeout_s, env=env_map
        )


class _StdinJsonStrategy:
    """`stdin-json` — argv = exec_ctx.argv_prefix + rendered argv_template, with
    the inputs dict JSON-encoded on stdin."""

    kind = "stdin-json"

    def invoke(
        self,
        *,
        exec_ctx: dict[str, Any],
        invocation: dict[str, Any],
        inputs: dict[str, Any],
        env_map: dict[str, str],
        timeout_s: int,
    ) -> dict[str, Any]:
        argv_tpl = invocation.get("argv_template") or []
        base_argv = _base_argv_from_ctx(exec_ctx)
        argv = base_argv + _render_argv(argv_tpl, inputs, env_map)
        body = json.dumps(inputs).encode("utf-8")
        cwd = exec_ctx.get("cwd") or None
        return _run_subprocess(
            argv, stdin_bytes=body, cwd=cwd, timeout_s=timeout_s, env=env_map
        )


# http / mcp-tool transports are deliberately NOT registered (and are refused by
# the compatibility fence at install time) — Local Yep invokes a LOCAL subprocess.
_INVOCATIONS: dict[str, InvocationStrategy] = {
    _SubcommandStrategy.kind: _SubcommandStrategy(),
    _StdinJsonStrategy.kind: _StdinJsonStrategy(),
}


def call(
    tool_id: str,
    action_name: str,
    params: dict[str, Any] | None = None,
    *,
    timeout: int | None = None,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Invoke a registered action. Returns a structured result envelope.

    Exit 0 with JSON stdout → {ok, result: <parsed>}. Exit 0 with non-JSON stdout
    → {ok, result: {stdout: <raw>}}. Non-zero exit → raises InvocationError. The
    child runs with an allowlisted environment (never the parent's full env)."""
    entry = _registry_entry(tool_id)
    actions = entry["actions"]
    if action_name not in actions:
        raise LookupError(
            f"action {action_name!r} not in tool {tool_id!r}; "
            f"available: {sorted(actions)}"
        )
    action = actions[action_name]
    invocation = action.get("invocation") or {}
    kind = invocation.get("kind")
    strategy = _INVOCATIONS.get(kind)
    if strategy is None:
        raise InvocationError(
            f"actions[{action_name!r}].invocation.kind={kind!r} not supported "
            f"(registered: {sorted(_INVOCATIONS)})",
            phase="invoke",
            retryable=False,
        )

    inputs = deepcopy(params or {})
    explicit_env = dict(env or {})

    exec_ctx = dict(entry.get("exec_ctx") or {})
    exec_ctx.setdefault("_tool_id", tool_id)
    method = exec_ctx.get("method")

    # Declared env values come from the LOCAL secret store first (T6.3), with the
    # process environment as a fallback — so a user-cred wrapper runs off a key
    # the user stored in the keyring, with nothing in the parent os.environ.
    resolver = _store_env_resolver(tool_id)
    if method == _PreinstalledHandler.method:
        child_env = _child_env(
            entry.get("declared_env") or [], explicit_env, resolve=resolver
        )
    else:
        child_env = _fetched_child_env(
            entry.get("declared_env") or [], explicit_env, resolve=resolver
        )

    ctx_pp = exec_ctx.get("pythonpath")
    if ctx_pp:
        child_env["PYTHONPATH"] = ctx_pp

    # OAuth (Model B / T6.7): if the manifest declares an `auth` block, inject a
    # fresh access token (refreshed on expiry via the stored refresh token) into
    # the child env under `auth.access_token_env`. No valid token ⇒ a clear
    # "re-auth needed" error instead of a confusing downstream tool failure. The
    # token is set only in the env map — never argv, never logged.
    auth_block = _manifest_auth(entry.get("manifest") or {})
    if auth_block is not None:
        from local_yep.toolspace import oauth as _oauth

        if not _oauth.inject_into_env(tool_id, auth_block, child_env):
            raise InvocationError(
                f"re-auth needed for {tool_id!r}: no valid OAuth token "
                "(never authorized, or the refresh token expired/was revoked). "
                f"Run `yepgent tools auth {tool_id}`.",
                phase="invoke",
                retryable=False,
            )

    timeout_s = int(timeout) if timeout is not None else _DEFAULT_TIMEOUT_S

    return strategy.invoke(
        exec_ctx=exec_ctx,
        invocation=invocation,
        inputs=inputs,
        env_map=child_env,
        timeout_s=timeout_s,
    )


def _run_subprocess(
    argv: list[str],
    stdin_bytes: bytes | None,
    cwd: str | None,
    timeout_s: int,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    try:
        proc = subprocess.run(
            argv,
            input=stdin_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd,
            timeout=timeout_s,
            check=False,
            env=env,
        )
    except subprocess.TimeoutExpired as e:
        raise InvocationError(
            f"action timed out after {timeout_s}s: argv={argv!r}",
            phase="invoke",
            retryable=True,
        ) from e
    except FileNotFoundError as e:
        raise InvocationError(
            f"entrypoint binary not found: {argv[0]!r}",
            phase="invoke",
            retryable=False,
        ) from e

    stdout = proc.stdout.decode("utf-8", errors="replace")
    stderr = proc.stderr.decode("utf-8", errors="replace")
    if proc.returncode != 0:
        stderr_tail = stderr[-2000:]
        raise InvocationError(
            f"action failed: exit={proc.returncode}; "
            f"stderr={stderr_tail!r}; argv={argv!r}",
            phase="invoke",
            retryable=False,
            returncode=proc.returncode,
            stderr_tail=stderr_tail,
        )
    try:
        result = json.loads(stdout) if stdout.strip() else {}
    except json.JSONDecodeError:
        result = {"stdout": stdout}
    return {"ok": True, "result": result, "stderr": stderr or None}


# ---------------------------------------------------------------------------
# Thin MCP action surface (ported from src/tools/manifest.py)
# ---------------------------------------------------------------------------
#
# A small dispatcher: validate / install / list_installed / call / uninstall.
# Every action returns a {ok, ...} dict; on error it returns
# {ok: False, where: <action>, error: <type>:<msg>}.


def _ok(**payload: Any) -> dict[str, Any]:
    return {"ok": True, **payload}


def _err(where: str, exc: Exception) -> dict[str, Any]:
    return {"ok": False, "where": where, "error": f"{type(exc).__name__}: {exc}"}


def _resolve_doc(params: dict[str, Any]) -> dict[str, Any]:
    """Either params['doc'] or fetched from params['url']. Exactly one."""
    doc = params.get("doc")
    url = params.get("url")
    if (doc is None) == (url is None):
        raise ValueError("provide exactly one of `doc` or `url`")
    if doc is not None:
        if not isinstance(doc, dict):
            raise TypeError(f"`doc` must be a dict, got {type(doc).__name__}")
        return doc
    return fetch_manifest(url)


def _action_validate(params: dict[str, Any]) -> dict[str, Any]:
    doc = _resolve_doc(params)
    result = validate_manifest(doc)
    return _ok(**result)


def _action_install(params: dict[str, Any]) -> dict[str, Any]:
    doc = _resolve_doc(params)
    # The security proof for a code-fetching install comes from the loader's LOCAL
    # confirm gate (`install(..., confirm=...)`), NOT from any data threaded
    # through these params. We deliberately do NOT pass a confirm/approval dict
    # from `params`. A non-interactive (headless) install of a code-fetching tool
    # fails closed (ApprovalRequiredError → {ok: False} below).
    entry = install(doc)
    return _ok(installed=entry)


def _action_list_installed(_params: dict[str, Any]) -> dict[str, Any]:
    return _ok(tools=list_installed())


def _action_call(params: dict[str, Any]) -> dict[str, Any]:
    tool_id = params.get("tool_id")
    action = params.get("action")
    if not tool_id or not action:
        raise ValueError("`tool_id` and `action` are required")
    return _ok(**call(
        tool_id=tool_id,
        action_name=action,
        params=params.get("params") or {},
        timeout=params.get("timeout"),
        env=params.get("env"),
    ))


def _action_uninstall(params: dict[str, Any]) -> dict[str, Any]:
    tool_id = params.get("tool_id")
    if not tool_id:
        raise ValueError("`tool_id` is required")
    return _ok(**uninstall(tool_id))


_ACTIONS = {
    "validate": _action_validate,
    "install": _action_install,
    "list_installed": _action_list_installed,
    "call": _action_call,
    "uninstall": _action_uninstall,
}


def handle(action: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    """Dispatch one MCP action through the loader. Never raises — errors come back
    as ``{ok: False, where, error}``."""
    p = params or {}
    fn = _ACTIONS.get(action)
    if fn is None:
        return _err(
            "dispatch",
            ValueError(f"unknown action {action!r}; available: {sorted(_ACTIONS)}"),
        )
    try:
        return fn(p)
    except Exception as e:  # noqa: BLE001 — surface as an error envelope
        return _err(action, e)


# ---------------------------------------------------------------------------
# Test seam + import-time rehydrate
# ---------------------------------------------------------------------------


def _reset_for_tests() -> None:
    """Clear the in-memory registry (does NOT touch the on-disk index)."""
    _INSTALLED.clear()


__all__ = [
    "fetch_manifest",
    "validate_manifest",
    "validate_pin",
    "install",
    "uninstall",
    "list_installed",
    "call",
    "handle",
    "rehydrate",
    "build_confirm_context",
    "scopes_digest",
    "data_boundary_digest",
    "entrypoint_digest",
    "source_digest",
    "tool_identity_digest",
    "sweep_trash",
    "ConfirmFn",
    "FetchHandler",
    "SmokeRunner",
    "ManifestError",
    "FetchError",
    "PaymentRequiredError",
    "ValidationError",
    "BuildError",
    "SmokeError",
    "InvocationError",
    "UnsupportedManifestError",
    "ApprovalRequiredError",
]


# Rehydrate the durable install index on import so a restart sees previously
# approved tools without re-prompting (T4.5). Best-effort: a corrupt/missing
# index must never break import.
try:  # pragma: no cover - exercised indirectly via rehydrate() tests
    rehydrate()
except Exception:
    pass
