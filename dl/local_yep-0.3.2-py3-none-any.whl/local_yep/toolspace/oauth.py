"""Local OAuth 2.0 flow runner for installed tools (PLAN.md §6 / P5, Model B).

Gives an installed tool an OAuth token entirely locally: the user authorizes in
their own browser, a temporary ``127.0.0.1`` loopback server captures the auth
code (Authorization Code + **PKCE**), the code is exchanged for tokens, and the
refresh + access tokens land in the OS keyring (via :mod:`local_yep.secrets`).
At call time the access token is refreshed-on-expiry and injected into the
tool's environment. Nothing leaves the machine except the user's own calls to
the provider's token endpoint.

Decisions baked in (PLAN.md §6, resolved 2026-06-25):
  * **Client = user-supplied.** The user creates their *own* Google Cloud (or
    other provider) OAuth client and supplies ``client_id`` / ``client_secret``.
    This sidesteps provider app-verification gates for sensitive scopes — their
    app stays in testing mode, fine for personal use — and keeps Local Yep out
    of the OAuth data-controller seat. A pack never ships a shared client.
  * **Request mechanism = the manifest ``auth`` block** (T6.5). The loader routes
    a manifest with an ``auth`` block here instead of an env-paste.

The manifest ``auth`` block (a Local Yep extension, forward-compatible with the
anticipated install-manifest v0.5 ``auth`` block)::

    "auth": {
      "type": "oauth2",                 // only supported flow type
      "provider": "google",             // informational
      "authorize_url": "https://accounts.google.com/o/oauth2/v2/auth",
      "token_url": "https://oauth2.googleapis.com/token",
      "device_code_url": "https://oauth2.googleapis.com/device/code",  // optional
      "scopes": ["https://www.googleapis.com/auth/calendar.readonly"],
      "client": "user-supplied",        // only supported model
      "redirect": "loopback",           // only supported redirect
      "access_token_env": "GOOGLE_ACCESS_TOKEN"  // env var the token is injected as
    }

Security: a shipped/public client secret is non-confidential (desktop apps);
PKCE + loopback mitigate. No token (access/refresh) is ever printed or logged.
HTTP/browser/loopback are behind injectable seams so the flow is unit-testable
against a mocked token endpoint with no real network or browser.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets as _rand  # stdlib CSPRNG — NOT local_yep.secrets (the cred store)
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Callable

from local_yep import secrets as credstore  # the local keyring-backed store

_HTTP_TIMEOUT_S = 30
#: Refresh a little BEFORE the real expiry so a token never expires mid-call.
_EXPIRY_SKEW_S = 60
#: Device-code polling backstop so a never-authorized flow can't loop forever.
_DEVICE_MAX_WAIT_S = 600


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class OAuthError(RuntimeError):
    """An OAuth flow failed. ``code`` carries the provider's ``error`` token
    (e.g. ``invalid_grant``, ``authorization_pending``, ``slow_down``) when one
    was returned, so callers can branch without string-parsing."""

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------------
# Token model + per-tool persistence (keyring via the secret store)
# ---------------------------------------------------------------------------

# Reserved store keys for a tool's OAuth material. They are NOT SCREAMING_SNAKE
# env names, so they can never collide with a manifest's declared env[] names
# (and the env resolver never injects them — the access token is injected
# separately by `inject_into_env`).
_K_CLIENT_ID = "__oauth_client_id__"
_K_CLIENT_SECRET = "__oauth_client_secret__"
_K_ACCESS = "__oauth_access_token__"
_K_REFRESH = "__oauth_refresh_token__"
_K_EXPIRES = "__oauth_expires_at__"
_K_SCOPE = "__oauth_scope__"


@dataclass
class OAuthTokens:
    """Resolved tokens. ``expires_at`` is an absolute epoch second."""

    access_token: str
    refresh_token: str | None
    expires_at: float
    scope: str | None = None

    @classmethod
    def from_response(cls, resp: dict[str, Any], *, now: float, prior_refresh: str | None = None) -> "OAuthTokens":
        """Build from a token-endpoint JSON response. A refresh response often
        omits ``refresh_token`` — fall back to the prior one so we don't lose
        the ability to refresh again."""
        access = resp.get("access_token")
        if not access:
            raise OAuthError("token response missing access_token", code=resp.get("error"))
        expires_in = resp.get("expires_in")
        try:
            expires_at = now + float(expires_in) if expires_in is not None else now + 3600.0
        except (TypeError, ValueError):
            expires_at = now + 3600.0
        return cls(
            access_token=str(access),
            refresh_token=resp.get("refresh_token") or prior_refresh,
            expires_at=expires_at,
            scope=resp.get("scope"),
        )

    def is_expired(self, *, now: float, skew: float = _EXPIRY_SKEW_S) -> bool:
        return now >= (self.expires_at - skew)


def store_client(tool_id: str, client_id: str, client_secret: str | None) -> None:
    """Persist the user-supplied OAuth client. ``client_id`` is an identifier
    (config); ``client_secret`` is stored as a secret (it is non-confidential for
    a public desktop client, but treated as secret for defense in depth)."""
    credstore.set_config(tool_id, _K_CLIENT_ID, client_id)
    if client_secret:
        credstore.set_secret(tool_id, _K_CLIENT_SECRET, client_secret)


def load_client(tool_id: str) -> tuple[str | None, str | None]:
    return (
        credstore.get_config(tool_id, _K_CLIENT_ID),
        credstore.get_secret(tool_id, _K_CLIENT_SECRET),
    )


def has_client(tool_id: str) -> bool:
    return bool(credstore.get_config(tool_id, _K_CLIENT_ID))


def store_tokens(tool_id: str, tokens: OAuthTokens) -> None:
    """Persist tokens: access + refresh as keyring secrets; expiry + scope as
    config metadata (not sensitive)."""
    credstore.set_secret(tool_id, _K_ACCESS, tokens.access_token)
    if tokens.refresh_token:
        credstore.set_secret(tool_id, _K_REFRESH, tokens.refresh_token)
    credstore.set_config(tool_id, _K_EXPIRES, repr(float(tokens.expires_at)))
    if tokens.scope:
        credstore.set_config(tool_id, _K_SCOPE, tokens.scope)


def load_tokens(tool_id: str) -> OAuthTokens | None:
    access = credstore.get_secret(tool_id, _K_ACCESS)
    if not access:
        return None
    raw_exp = credstore.get_config(tool_id, _K_EXPIRES)
    try:
        expires_at = float(raw_exp) if raw_exp is not None else 0.0
    except (TypeError, ValueError):
        expires_at = 0.0
    return OAuthTokens(
        access_token=access,
        refresh_token=credstore.get_secret(tool_id, _K_REFRESH),
        expires_at=expires_at,
        scope=credstore.get_config(tool_id, _K_SCOPE),
    )


def forget_tokens(tool_id: str) -> None:
    """Drop a tool's stored tokens (keeps the client so a re-auth is one step)."""
    credstore.delete_secret(tool_id, _K_ACCESS)
    credstore.delete_secret(tool_id, _K_REFRESH)
    credstore.delete_config(tool_id, _K_EXPIRES)
    credstore.delete_config(tool_id, _K_SCOPE)


# ---------------------------------------------------------------------------
# HTTP seam (token endpoint) — injectable for tests
# ---------------------------------------------------------------------------


def _post_form(url: str, data: dict[str, str]) -> dict[str, Any]:
    """POST application/x-www-form-urlencoded and parse a JSON response. On a 4xx
    the provider returns a JSON ``{error, error_description}`` body — parse it and
    raise :class:`OAuthError` carrying ``error`` so callers (device-code polling,
    refresh) can branch. Never logs the form data (it carries secrets)."""
    body = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT_S) as resp:
            return json.loads(resp.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8") or "{}")
        except Exception:
            payload = {}
        raise OAuthError(
            f"token endpoint returned HTTP {e.code}: {payload.get('error_description') or payload.get('error') or e.reason}",
            code=payload.get("error"),
        ) from e
    except urllib.error.URLError as e:
        raise OAuthError(f"could not reach token endpoint: {e.reason}") from e


PostFn = Callable[[str, dict[str, str]], dict[str, Any]]


# ---------------------------------------------------------------------------
# PKCE + authorize URL
# ---------------------------------------------------------------------------


def generate_pkce() -> tuple[str, str]:
    """Return ``(code_verifier, code_challenge)`` for PKCE S256 (RFC 7636)."""
    verifier = _rand.token_urlsafe(64)[:128]  # 43..128 chars, URL-safe
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def build_authorize_url(
    auth: dict[str, Any],
    *,
    client_id: str,
    redirect_uri: str,
    code_challenge: str,
    state: str,
) -> str:
    """Construct the provider authorize URL (Authorization Code + PKCE)."""
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": " ".join(auth.get("scopes") or []),
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        # Google needs these to mint a refresh token on the first consent.
        "access_type": "offline",
        "prompt": "consent",
    }
    sep = "&" if "?" in auth["authorize_url"] else "?"
    return auth["authorize_url"] + sep + urllib.parse.urlencode(params)


# ---------------------------------------------------------------------------
# Token exchange + refresh
# ---------------------------------------------------------------------------


def exchange_code(
    auth: dict[str, Any],
    *,
    client_id: str,
    client_secret: str | None,
    code: str,
    code_verifier: str,
    redirect_uri: str,
    post: PostFn = _post_form,
    now: Callable[[], float] = time.time,
) -> OAuthTokens:
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_verifier": code_verifier,
    }
    if client_secret:
        data["client_secret"] = client_secret
    resp = post(auth["token_url"], data)
    return OAuthTokens.from_response(resp, now=now())


def refresh_tokens(
    auth: dict[str, Any],
    *,
    client_id: str,
    client_secret: str | None,
    refresh_token: str,
    post: PostFn = _post_form,
    now: Callable[[], float] = time.time,
) -> OAuthTokens:
    data = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": client_id,
    }
    if client_secret:
        data["client_secret"] = client_secret
    resp = post(auth["token_url"], data)
    return OAuthTokens.from_response(resp, now=now(), prior_refresh=refresh_token)


# ---------------------------------------------------------------------------
# Loopback capture (real implementation) + the orchestrated flows
# ---------------------------------------------------------------------------


def _capture_code_via_loopback(state: str) -> tuple[str, Callable[[], str]]:
    """Bind a one-shot ``127.0.0.1:<ephemeral>`` server. Returns
    ``(redirect_uri, wait)`` where ``wait()`` blocks until the browser redirects
    back, validates ``state``, and returns the auth ``code`` (raising
    :class:`OAuthError` on a provider error or a state mismatch)."""
    result: dict[str, str] = {}
    done = threading.Event()

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - stdlib signature
            qs = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(qs)
            if "error" in params:
                result["error"] = params["error"][0]
            elif params.get("state", [None])[0] != state:
                result["error"] = "state_mismatch"
            else:
                result["code"] = params.get("code", [""])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            ok = "code" in result
            self.wfile.write(
                b"<html><body style='font-family:sans-serif'>"
                + (b"<h2>Authorization complete.</h2>" if ok
                   else b"<h2>Authorization failed.</h2>")
                + b"<p>You can close this tab and return to the terminal.</p>"
                + b"</body></html>"
            )
            done.set()

        def log_message(self, *a: Any) -> None:  # silence stdlib request logging
            pass

    server = HTTPServer(("127.0.0.1", 0), _Handler)
    port = server.server_address[1]
    redirect_uri = f"http://127.0.0.1:{port}/"

    def wait() -> str:
        try:
            while not done.is_set():
                server.handle_request()
        finally:
            server.server_close()
        if result.get("code"):
            return result["code"]
        raise OAuthError(
            f"authorization failed: {result.get('error', 'no code returned')}",
            code=result.get("error"),
        )

    return redirect_uri, wait


CaptureFn = Callable[[str], "tuple[str, Callable[[], str]]"]


def run_loopback_flow(
    auth: dict[str, Any],
    *,
    client_id: str,
    client_secret: str | None,
    post: PostFn = _post_form,
    open_browser: Callable[[str], Any] = webbrowser.open,
    capture: CaptureFn = _capture_code_via_loopback,
    now: Callable[[], float] = time.time,
    emit: Callable[[str], Any] = lambda _m: None,
) -> OAuthTokens:
    """Full Authorization-Code + PKCE loopback flow. Opens the system browser,
    captures the code on a local loopback server, exchanges it for tokens.
    Network / browser / server are injectable seams (tests pass fakes)."""
    verifier, challenge = generate_pkce()
    state = _rand.token_urlsafe(24)
    redirect_uri, wait = capture(state)
    url = build_authorize_url(
        auth,
        client_id=client_id,
        redirect_uri=redirect_uri,
        code_challenge=challenge,
        state=state,
    )
    emit("Opening your browser to authorize… (if it doesn't open, visit the URL printed below)")
    try:
        open_browser(url)
    except Exception:
        pass
    emit(url)
    code = wait()
    return exchange_code(
        auth,
        client_id=client_id,
        client_secret=client_secret,
        code=code,
        code_verifier=verifier,
        redirect_uri=redirect_uri,
        post=post,
        now=now,
    )


def run_device_code_flow(
    auth: dict[str, Any],
    *,
    client_id: str,
    client_secret: str | None,
    post: PostFn = _post_form,
    emit: Callable[[str], Any] = print,
    sleep: Callable[[float], Any] = time.sleep,
    now: Callable[[], float] = time.time,
) -> OAuthTokens:
    """Headless fallback: RFC 8628 Device Authorization Grant. Prints a code +
    URL for the user to enter on another device, then polls the token endpoint."""
    device_url = auth.get("device_code_url")
    if not device_url:
        raise OAuthError("this tool's auth block has no device_code_url for headless auth")
    dc = post(device_url, {"client_id": client_id, "scope": " ".join(auth.get("scopes") or [])})
    user_code = dc.get("user_code")
    verification = dc.get("verification_url") or dc.get("verification_uri")
    emit(f"\nTo authorize, visit {verification} and enter code: {user_code}\n")
    interval = float(dc.get("interval") or 5)
    device_code = dc.get("device_code")
    deadline = now() + _DEVICE_MAX_WAIT_S
    while now() < deadline:
        sleep(interval)
        try:
            resp = post(
                auth["token_url"],
                {
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                    "device_code": device_code,
                    "client_id": client_id,
                    **({"client_secret": client_secret} if client_secret else {}),
                },
            )
            return OAuthTokens.from_response(resp, now=now())
        except OAuthError as e:
            if e.code == "authorization_pending":
                continue
            if e.code == "slow_down":
                interval += 5
                continue
            raise
    raise OAuthError("device-code authorization timed out (no approval within the wait window)")


# ---------------------------------------------------------------------------
# Runtime access-token resolution (T6.7) — refresh-on-expiry
# ---------------------------------------------------------------------------


def get_access_token(
    tool_id: str,
    auth: dict[str, Any],
    *,
    post: PostFn | None = None,
    now: Callable[[], float] = time.time,
) -> str | None:
    """Return a currently-valid access token for ``tool_id``, refreshing on
    expiry via the stored refresh token. Returns ``None`` when there are no
    stored tokens or a refresh fails (caller surfaces "re-auth needed"). Never
    logs a token.

    ``post`` is resolved at call time (default :func:`_post_form`) so a runtime
    refresh follows a monkeypatched seam in tests and the real endpoint in prod."""
    post = post or _post_form
    tokens = load_tokens(tool_id)
    if tokens is None:
        return None
    if not tokens.is_expired(now=now()):
        return tokens.access_token
    if not tokens.refresh_token:
        return None
    client_id, client_secret = load_client(tool_id)
    if not client_id:
        return None
    try:
        refreshed = refresh_tokens(
            auth,
            client_id=client_id,
            client_secret=client_secret,
            refresh_token=tokens.refresh_token,
            post=post,
            now=now,
        )
    except OAuthError:
        return None
    store_tokens(tool_id, refreshed)
    return refreshed.access_token


def inject_into_env(
    tool_id: str,
    auth: dict[str, Any],
    env: dict[str, str],
    *,
    post: PostFn | None = None,
    now: Callable[[], float] = time.time,
) -> bool:
    """Inject a fresh access token into ``env`` under ``auth.access_token_env``.
    Returns True on success, False if no valid token could be resolved (the
    loader turns False into a clear "re-auth needed" error). The token is set
    only in the child env map — never argv, never logged."""
    env_name = auth.get("access_token_env")
    if not env_name:
        return False
    token = get_access_token(tool_id, auth, post=post, now=now)
    if not token:
        return False
    env[env_name] = token
    return True
