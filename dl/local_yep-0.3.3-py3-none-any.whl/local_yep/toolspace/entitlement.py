"""Client-side premium entitlement (PLAN.md §4 · T4.9 / T4.11-client).

This module is the *client half* of Local Yep's single, honest paywall. It
loads a signed entitlement (``~/.local-yep/license.json``), verifies it against
a **bundled Ed25519 public key**, and answers three questions for the toolspace
loader:

* :func:`is_premium_host` — is this manifest URL served from our gated
  premium host (and therefore eligible for an ``Authorization`` header)?
* :func:`authorize_header` — the ``Authorization: Bearer <jwt>`` header to send
  with a *premium* fetch, **only** when a valid (or within-grace) entitlement
  exists; otherwise ``{}``.
* :func:`entitled_ids` — the set of tool/pack ids the entitlement grants.

Design invariants (decided scope):

* **The paywall is server-side only.** This client adds *no local DRM*. Free
  tools install with no entitlement, no network, and no crypto. Already-installed
  tools run offline forever. Only a *new premium install* needs a live (or
  within-grace) entitlement, and even then enforcement happens at the server's
  ``402/403`` — this module merely attaches the bearer token it already has.
* **Crypto is an OPTIONAL extra.** Ed25519 verification is a *lazy* import of
  the ``[pro]`` extra (``cryptography`` or ``PyNaCl``). When the extra is
  absent the FREE path is wholly unaffected — :func:`is_premium_host` still
  works, :func:`authorize_header` returns ``{}`` for free hosts, and for a
  premium host it degrades with a clear "install ``local-yep[pro]``" message
  rather than crashing.
* **30-day offline grace.** A token that has just expired is honored for
  :data:`OFFLINE_GRACE_DAYS` days so a brief lapse / offline period never breaks
  a premium install; past the grace window it is refused with a clear
  "license expired / offline" error.

----------------------------------------------------------------------------
JWT ENTITLEMENT CONTRACT (Ed25519 / EdDSA) — minted by P3-SERVER
----------------------------------------------------------------------------
The server (premium-manifest webhook, PLAN.md T4.10) mints exactly what this
module verifies. The token is a **compact JWS** (``header.payload.signature``,
each segment base64url **without** padding):

``header``  (JSON)::

    {"alg": "EdDSA", "typ": "JWT"}

``payload`` (JSON) — the claim set::

    {
      "iss": "premium.toolspace.yepgent.com",  # issuer (informational)
      "sub": "<buyer id>",        # LemonSqueezy customer/license subject
      "plan": "pro",              # plan/tier name (informational)
      "ent": ["pack:zen", "tool:foo"],  # entitled tool/pack ids (the grant)
      "iat": 1719000000,          # issued-at  (unix seconds)
      "exp": 1721592000           # expiry     (unix seconds) — REQUIRED
    }

``signature`` = Ed25519 over the ASCII bytes ``base64url(header) + "." +
base64url(payload)``, produced with the SERVER's **private** key. This client
verifies it with the matching :data:`BUNDLED_PUBLIC_KEY_B64` public key.

Only ``exp`` is structurally required for a token to be usable; ``ent`` defaults
to the empty grant if missing. Claim JSON is serialized with sorted keys and
compact separators so the signer and this verifier agree byte-for-byte.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

log = logging.getLogger("local_yep.toolspace.entitlement")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

#: The gated premium toolspace host. Manifest URLs served from this host (or a
#: subdomain of it) are the ONLY ones that ever receive an ``Authorization``
#: header. The free static registry (toolspace-site / Netlify) is NOT premium
#: and is fetched with no auth. Override for staging/tests via the
#: ``LOCAL_YEP_PREMIUM_HOSTS`` env var (comma-separated host list).
DEFAULT_PREMIUM_HOST = "premium.toolspace.yepgent.com"

#: Offline grace window: a token whose ``exp`` has passed is still honored for
#: this many days (so a brief offline period / renewal lag never blocks a
#: premium install). Past the window the entitlement is refused.
OFFLINE_GRACE_DAYS = 30
OFFLINE_GRACE_SECONDS = OFFLINE_GRACE_DAYS * 86400

#: JWT wire constants (see the module-level contract docstring).
JWT_ALG = "EdDSA"
JWT_TYP = "JWT"

#: The bundled Ed25519 PUBLIC key (base64; raw 32 bytes), used to verify the
#: entitlement. The matching PRIVATE key is **server/ops-only and never in this
#: repo** — it lives with the premium-manifest webhook that mints tokens. Empty
#: in the open-source tree.
#:
#: **Stamping this constant is what makes a build enforceable.** When it is
#: non-empty it is the ONLY key consulted: the ``LOCAL_YEP_TOOLSPACE_PUBKEY``
#: env var and the installer-written ``~/.local-yep/entitlement_pubkey`` file
#: are ignored (see :func:`_resolve_public_key`). Those two host-supplied lanes
#: exist for unstamped builds — a dev checkout, a test, the alpha — and while
#: they are in play the entitlement is advisory, not enforced, because the same
#: user who supplies the key can mint the token it verifies.
#:
#: With no public key from ANY source, tokens cannot be verified locally and
#: premium installs are refused (the free path is unaffected).
BUNDLED_PUBLIC_KEY_B64 = ""

#: Clear, actionable message surfaced when a premium install is attempted but
#: the optional crypto extra is not installed.
PRO_EXTRA_HINT = (
    "Premium tools require the optional crypto extra. "
    "Install it with: pip install local-yep[pro]"
)

# Environment-variable seams (ops/tests):
_ENV_PREMIUM_HOSTS = "LOCAL_YEP_PREMIUM_HOSTS"
_ENV_PUBKEY = "LOCAL_YEP_TOOLSPACE_PUBKEY"
_ENV_LICENSE_FILE = "LOCAL_YEP_LICENSE_FILE"


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class CryptoUnavailable(RuntimeError):
    """Raised when no Ed25519 backend (the ``[pro]`` extra) is importable."""


class InvalidLicense(ValueError):
    """Raised when a license token is malformed or its signature is invalid."""


# ---------------------------------------------------------------------------
# Crypto backend — LAZY import of the optional ``[pro]`` extra
# ---------------------------------------------------------------------------
# A backend is a SimpleNamespace exposing three callables operating on RAW
# 32-byte Ed25519 keys:
#   generate() -> (private_bytes, public_bytes)
#   sign(private_bytes, message_bytes) -> signature_bytes
#   verify(public_bytes, message_bytes, signature_bytes) -> bool
# Nothing here is imported at module load; ``_get_backend`` resolves it on first
# use and caches the result. Monkeypatch ``_get_backend`` in tests to simulate
# the extra being absent.

_BACKEND: SimpleNamespace | None = None


def _try_cryptography() -> SimpleNamespace | None:
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey,
            Ed25519PublicKey,
        )
    except Exception:  # pragma: no cover - exercised via the pynacl/none paths
        return None

    def generate() -> tuple[bytes, bytes]:
        sk = Ed25519PrivateKey.generate()
        return sk.private_bytes_raw(), sk.public_key().public_bytes_raw()

    def sign(private_bytes: bytes, message: bytes) -> bytes:
        return Ed25519PrivateKey.from_private_bytes(private_bytes).sign(message)

    def verify(public_bytes: bytes, message: bytes, signature: bytes) -> bool:
        try:
            Ed25519PublicKey.from_public_bytes(public_bytes).verify(signature, message)
            return True
        except InvalidSignature:
            return False
        except Exception:
            return False

    return SimpleNamespace(name="cryptography", generate=generate, sign=sign, verify=verify)


def _try_pynacl() -> SimpleNamespace | None:
    try:
        from nacl.exceptions import BadSignatureError
        from nacl.signing import SigningKey, VerifyKey
    except Exception:
        return None

    def generate() -> tuple[bytes, bytes]:
        sk = SigningKey.generate()
        return bytes(sk), bytes(sk.verify_key)

    def sign(private_bytes: bytes, message: bytes) -> bytes:
        return SigningKey(private_bytes).sign(message).signature

    def verify(public_bytes: bytes, message: bytes, signature: bytes) -> bool:
        try:
            VerifyKey(public_bytes).verify(message, signature)
            return True
        except BadSignatureError:
            return False
        except Exception:
            return False

    return SimpleNamespace(name="pynacl", generate=generate, sign=sign, verify=verify)


def _get_backend() -> SimpleNamespace:
    """Return the cached Ed25519 backend, or raise :class:`CryptoUnavailable`.

    Prefers ``cryptography``; falls back to ``PyNaCl``. Tests simulate the
    ``[pro]`` extra being absent by monkeypatching this function to raise.
    """
    global _BACKEND
    if _BACKEND is not None:
        return _BACKEND
    backend = _try_cryptography() or _try_pynacl()
    if backend is None:
        raise CryptoUnavailable(PRO_EXTRA_HINT)
    _BACKEND = backend
    return backend


def crypto_available() -> bool:
    """True if an Ed25519 backend (the ``[pro]`` extra) is importable."""
    try:
        _get_backend()
        return True
    except CryptoUnavailable:
        return False


def reset_cache() -> None:
    """Drop the cached crypto backend. Test/ops hook; harmless in production."""
    global _BACKEND
    _BACKEND = None


def generate_keypair() -> tuple[bytes, bytes]:
    """Return a fresh ``(private_bytes, public_bytes)`` raw Ed25519 keypair.

    Convenience for the server scaffold (key generation) and tests. Requires the
    ``[pro]`` extra; raises :class:`CryptoUnavailable` otherwise.
    """
    return _get_backend().generate()


# ---------------------------------------------------------------------------
# base64url + compact-JWS helpers
# ---------------------------------------------------------------------------

def _b64u_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _b64u_decode(seg: str) -> bytes:
    pad = "=" * (-len(seg) % 4)
    return base64.urlsafe_b64decode(seg + pad)


def _json_segment(obj: dict) -> bytes:
    # Sorted keys + compact separators => deterministic, signer/verifier-agreed.
    return json.dumps(obj, separators=(",", ":"), sort_keys=True).encode("utf-8")


def encode_jwt(claims: dict, private_key: bytes) -> str:
    """Mint a compact EdDSA JWT for ``claims`` (SERVER/test side).

    Requires the PRIVATE key — users never hold one, so this is a no-op risk in
    the shipped client. Co-located with :func:`decode_jwt` so the exact wire
    format (header, canonical JSON, base64url-without-padding, signing input) is
    defined in one place and the server mints precisely what we verify.
    """
    backend = _get_backend()
    seg_h = _b64u_encode(_json_segment({"alg": JWT_ALG, "typ": JWT_TYP}))
    seg_p = _b64u_encode(_json_segment(claims))
    signing_input = f"{seg_h}.{seg_p}".encode("ascii")
    sig = backend.sign(private_key, signing_input)
    return f"{seg_h}.{seg_p}.{_b64u_encode(sig)}"


def decode_jwt(token: str, public_key: bytes) -> dict:
    """Verify ``token`` against ``public_key`` and return its claims.

    Verifies structure (3 segments), ``alg == EdDSA`` and the Ed25519 signature.
    Does **not** check ``exp`` — expiry/grace is applied by
    :func:`entitlement_status` so the offline-grace policy lives in one place.

    Raises :class:`InvalidLicense` on any malformation or signature failure, and
    :class:`CryptoUnavailable` if the crypto extra is missing.
    """
    parts = token.split(".")
    if len(parts) != 3:
        raise InvalidLicense("token is not a compact JWS (expected 3 segments)")
    seg_h, seg_p, seg_s = parts
    try:
        header = json.loads(_b64u_decode(seg_h))
    except Exception as exc:  # noqa: BLE001
        raise InvalidLicense("undecodable JWT header") from exc
    if not isinstance(header, dict) or header.get("alg") != JWT_ALG:
        raise InvalidLicense(f"unexpected JWT alg: {header.get('alg') if isinstance(header, dict) else header!r}")
    backend = _get_backend()  # may raise CryptoUnavailable
    signing_input = f"{seg_h}.{seg_p}".encode("ascii")
    try:
        signature = _b64u_decode(seg_s)
    except Exception as exc:  # noqa: BLE001
        raise InvalidLicense("undecodable JWT signature") from exc
    if not backend.verify(public_key, signing_input, signature):
        raise InvalidLicense("JWT signature verification failed")
    try:
        claims = json.loads(_b64u_decode(seg_p))
    except Exception as exc:  # noqa: BLE001
        raise InvalidLicense("undecodable JWT payload") from exc
    if not isinstance(claims, dict):
        raise InvalidLicense("JWT payload is not a claim object")
    return claims


# ---------------------------------------------------------------------------
# Configuration resolution (env-overridable seams)
# ---------------------------------------------------------------------------

def _premium_hosts() -> set[str]:
    env = os.environ.get(_ENV_PREMIUM_HOSTS, "").strip()
    if env:
        return {h.strip().lower() for h in env.split(",") if h.strip()}
    return {DEFAULT_PREMIUM_HOST}


def _host_of(url: str) -> str:
    if not url:
        return ""
    # Tolerate bare host strings (no scheme) as well as full URLs.
    candidate = url if ("://" in url or url.startswith("//")) else "//" + url
    return (urlsplit(candidate).hostname or "").lower()


def _read_home_pubkey() -> str:
    """The public key written into the Local Yep home by the installer.

    Returns ``""`` when the file is absent or unreadable — a missing key is a
    normal state (free core needs none), not an error. Imported lazily so this
    module never forces the home layout to exist and tests can monkeypatch it.
    """
    try:
        from local_yep import home

        return home.ENTITLEMENT_PUBKEY.read_text(encoding="utf-8").strip()
    except (FileNotFoundError, OSError, ImportError):
        return ""


def _resolve_public_key() -> bytes | None:
    """The Ed25519 public key to verify an entitlement against, or ``None``.

    :data:`BUNDLED_PUBLIC_KEY_B64` — the key a release build was stamped with —
    **wins outright when it is set**. It is deliberately not one option among
    several: the key a signed build verifies against must not be swappable by
    the machine running it. This module also exports :func:`generate_keypair`
    and :func:`encode_jwt`, so a user-substitutable verification key means any
    user can mint themselves an entitlement in four lines and every claim in it
    is believed. Trust has to be anchored in the artifact, not in the host.

    When nothing is stamped (the open-source tree, a dev checkout, a test), the
    two host-supplied lanes apply in order, first non-empty winning:

    1. ``LOCAL_YEP_TOOLSPACE_PUBKEY`` — the ops/test override.
    2. ``~/.local-yep/entitlement_pubkey`` — written by the installer. This is
       the durable lane: unlike an ``export`` appended to a shell profile, a
       file is read the same way from cron, systemd, an IDE terminal, or a
       shell that never sources ``~/.profile``.
    """
    bundled = BUNDLED_PUBLIC_KEY_B64.strip()
    if bundled:
        return _decode_public_key(bundled)
    src = os.environ.get(_ENV_PUBKEY, "").strip() or _read_home_pubkey()
    if not src:
        return None
    return _decode_public_key(src)


def _decode_public_key(text: str) -> bytes | None:
    text = text.strip()
    pad = "=" * (-len(text) % 4)
    for decoder in (base64.urlsafe_b64decode, base64.b64decode):
        try:
            raw = decoder(text + pad)
        except Exception:
            continue
        if len(raw) == 32:  # raw Ed25519 public key
            return raw
    return None


def _license_path() -> Path:
    env = os.environ.get(_ENV_LICENSE_FILE, "").strip()
    if env:
        return Path(env)
    # Imported lazily/dynamically so the home path can be monkeypatched in tests
    # and so importing this module never forces the home layout to exist.
    from local_yep import home

    return home.LICENSE_JSON


def _read_license_token() -> str | None:
    """Return the compact JWT from ``license.json``, or ``None`` if absent.

    The file may be the bare compact JWT string, or a JSON wrapper carrying it
    under ``jwt`` / ``token`` / ``license`` / ``license_jwt``.
    """
    try:
        raw = _license_path().read_text(encoding="utf-8").strip()
    except (FileNotFoundError, OSError):
        return None
    if not raw:
        return None
    if raw[0] in "{[":
        try:
            obj = json.loads(raw)
        except Exception:
            return None
        if isinstance(obj, dict):
            for key in ("jwt", "token", "license", "license_jwt"):
                val = obj.get(key)
                if isinstance(val, str) and val.strip():
                    return val.strip()
        return None
    return raw


# ---------------------------------------------------------------------------
# Entitlement evaluation
# ---------------------------------------------------------------------------

# State machine for an evaluated entitlement:
#   active    — verified, not expired                          → valid
#   grace     — verified, expired but within the offline grace → valid
#   expired   — verified, expired past the grace window        → invalid
#   invalid   — present but malformed / bad signature          → invalid
#   absent    — no license file                                → invalid
#   no_pubkey — no public key bundled to verify against        → invalid
#   no_crypto — the [pro] crypto extra is not installed         → invalid
_VALID_STATES = frozenset({"active", "grace"})


@dataclass(frozen=True)
class EntitlementStatus:
    """Result of evaluating the local entitlement."""

    state: str
    valid: bool
    claims: dict = field(default_factory=dict)
    reason: str = ""
    token: str | None = None

    @property
    def ids(self) -> set[str]:
        if not self.valid:
            return set()
        ent = self.claims.get("ent", [])
        return {str(x) for x in ent} if isinstance(ent, (list, tuple, set)) else set()


def _now() -> int:
    return int(time.time())


def entitlement_status() -> EntitlementStatus:
    """Load, verify and classify the local entitlement (no network).

    Reads ``license.json`` fresh on every call (cheap; keeps tests + a swapped
    license deterministic). Applies the 30-day offline grace to ``exp``.
    """
    token = _read_license_token()
    if not token:
        return EntitlementStatus(
            state="absent", valid=False,
            reason="no entitlement found (purchase required for premium tools)",
        )

    public_key = _resolve_public_key()
    if public_key is None:
        return EntitlementStatus(
            state="no_pubkey", valid=False, token=token,
            reason="no entitlement public key bundled; cannot verify premium license",
        )

    try:
        claims = decode_jwt(token, public_key)
    except CryptoUnavailable:
        return EntitlementStatus(
            state="no_crypto", valid=False, token=token, reason=PRO_EXTRA_HINT,
        )
    except InvalidLicense as exc:
        return EntitlementStatus(
            state="invalid", valid=False, token=token,
            reason=f"invalid license: {exc}",
        )

    exp = claims.get("exp")
    if not isinstance(exp, (int, float)) or isinstance(exp, bool):
        return EntitlementStatus(
            state="invalid", valid=False, claims=claims, token=token,
            reason="license is missing a valid 'exp' claim",
        )

    now = _now()
    if now <= exp:
        return EntitlementStatus(state="active", valid=True, claims=claims, token=token)
    if now <= exp + OFFLINE_GRACE_SECONDS:
        days_over = int((now - exp) // 86400)
        return EntitlementStatus(
            state="grace", valid=True, claims=claims, token=token,
            reason=(f"license expired {days_over}d ago; honored within the "
                    f"{OFFLINE_GRACE_DAYS}-day offline grace"),
        )
    return EntitlementStatus(
        state="expired", valid=False, claims=claims, token=token,
        reason=("license expired / offline: past the "
                f"{OFFLINE_GRACE_DAYS}-day offline grace — renew or reconnect"),
    )


# ---------------------------------------------------------------------------
# Public API (consumed by the loader's fetch_manifest)
# ---------------------------------------------------------------------------

def is_premium_host(url: str) -> bool:
    """True if ``url`` is served from a configured premium toolspace host.

    Pure URL logic — never touches crypto or the filesystem — so it is always
    safe, even when the ``[pro]`` extra is absent. Matches the exact host or any
    subdomain of a configured premium host.
    """
    host = _host_of(url)
    if not host:
        return False
    return any(host == h or host.endswith("." + h) for h in _premium_hosts())


def premium_block_reason(url: str) -> str | None:
    """Why a premium fetch to ``url`` would be sent with NO bearer, or ``None``.

    ``None`` means an ``Authorization`` header *would* be attached (premium host
    + valid/within-grace entitlement). For a free host returns ``None`` too
    (no auth is expected, nothing is "blocked"). Otherwise returns a clear,
    user-facing reason (missing crypto extra, no/expired entitlement, …).
    """
    if not is_premium_host(url):
        return None
    if not crypto_available():
        return PRO_EXTRA_HINT
    status = entitlement_status()
    return None if status.valid else status.reason


def authorize_header(url: str) -> dict[str, str]:
    """Return ``{"Authorization": "Bearer <jwt>"}`` for an entitled premium fetch.

    Returns ``{}`` (no header) when:

    * ``url`` is not a premium host (the FREE path — static manifests fetch with
      no auth, always, regardless of crypto availability), or
    * the ``[pro]`` crypto extra is absent (degrades with a logged hint), or
    * no valid (or within-grace) entitlement exists.

    Never raises — a premium-tool problem must not break the free core.
    """
    if not is_premium_host(url):
        return {}
    if not crypto_available():
        log.warning("Premium tool at %s: %s", _host_of(url), PRO_EXTRA_HINT)
        return {}
    status = entitlement_status()
    if status.valid and status.token:
        if status.state == "grace":
            log.info("Premium entitlement: %s", status.reason)
        return {"Authorization": f"Bearer {status.token}"}
    log.warning("No usable entitlement for %s: %s", _host_of(url), status.reason)
    return {}


def entitled_ids() -> set[str]:
    """The set of tool/pack ids the current entitlement grants (``set()`` if none)."""
    return entitlement_status().ids
