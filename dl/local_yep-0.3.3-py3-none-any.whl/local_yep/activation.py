"""Optional product-level activation gate (gated alpha / beta).

By default Local Yep's free core is **ungated** — this gate is OFF. When turned
on (a gated alpha/beta build), Local Yep refuses to run without a valid
entitlement: the ``gent`` launcher won't start and the SessionStart hook
withholds identity, both pointing the user at ``yepgent license activate``.

Turning it on (pick one):

* Set :data:`REQUIRE_ACTIVATION` to ``True`` in a release build, **or**
* ship ``YEPGENT_REQUIRE_ACTIVATION=1`` in the user environment.

The env var, when present, wins over the constant — so an alpha distribution can
flip it without a code change, and CI/tests/free installs stay ungated by
default. The gate reuses :mod:`local_yep.toolspace.entitlement` (offline JWT
verify + 30-day grace), so it needs the bundled/`LOCAL_YEP_TOOLSPACE_PUBKEY`
public key and the ``[pro]`` crypto extra; a misconfigured gated build fails
closed with a clear message rather than silently letting everyone in.

The license commands themselves (``yepgent license …``) are NEVER gated — that
would be a chicken-and-egg lockout.
"""
from __future__ import annotations

import os
from typing import NamedTuple, Optional

#: Open-source default: the product is NOT gated. Flip to True in a gated
#: alpha/beta release build (or set the env var below).
REQUIRE_ACTIVATION = False

_ENV_REQUIRE = "YEPGENT_REQUIRE_ACTIVATION"
_TRUTHY = {"1", "true", "yes", "on"}


class ActivationResult(NamedTuple):
    ok: bool
    required: bool
    state: str
    message: str


def activation_required(environ: Optional[dict] = None) -> bool:
    """Whether this build/run requires activation.

    The environment may only ever **tighten** this gate, never loosen it.

    A build that ships with ``REQUIRE_ACTIVATION = True`` is a gated build and
    stays gated whatever the environment says. The earlier "env wins over the
    constant" rule meant a single ``YEPGENT_REQUIRE_ACTIVATION=0`` un-gated a
    paid build on the user's own box — the gate could be switched off by the
    party it exists to gate.

    When the constant is ``False`` (the open-source default, an ungated free
    core) the env var can still turn the gate **on**: that is how the alpha
    installers gate a tester's machine without a special build.
    """
    if REQUIRE_ACTIVATION:
        return True
    env = environ if environ is not None else os.environ
    val = env.get(_ENV_REQUIRE)
    if val is not None and val.strip() != "":
        return val.strip().lower() in _TRUTHY
    return False


def _gate_message(detail: str) -> str:
    return (
        "=========== LOCAL YEP - ACTIVATION REQUIRED ===========\n"
        "This is a gated build; it needs a valid activation to run.\n\n"
        "Activate the token you were issued, or claim a purchase:\n"
        "    yepgent license activate <token>\n"
        "    yepgent license claim <key>\n"
        "    yepgent license status\n\n"
        f"Current: {detail}\n"
        "========================================================"
    )


def check(environ: Optional[dict] = None) -> ActivationResult:
    """Evaluate the activation gate (fail-closed when required). Never raises.

    Returns ``ok=True`` immediately when activation isn't required (the default).
    When required, ``ok`` is True only for a valid (active or within-grace)
    entitlement; otherwise ``message`` carries the user-facing notice.
    """
    if not activation_required(environ):
        return ActivationResult(True, required=False, state="not_required", message="")
    try:
        from local_yep.toolspace import entitlement

        st = entitlement.entitlement_status()
    except Exception as exc:  # noqa: BLE001 - a gated build must still fail closed clearly
        return ActivationResult(
            False, required=True, state="error",
            message=_gate_message(f"could not evaluate entitlement ({exc})"),
        )
    if st.valid:
        return ActivationResult(True, required=True, state=st.state, message="")
    return ActivationResult(
        False, required=True, state=st.state,
        message=_gate_message(st.reason or f"entitlement state: {st.state}"),
    )
