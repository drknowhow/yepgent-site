"""The ``~/.local-yep/`` home: path constants + idempotent bootstrap.

This is the single shared layout that sections §1/§2/§3/§4 all build into
(see PLAN.md "Cross-section dependencies"). Every other module resolves paths
through the constants here — never by re-deriving ``~/.local-yep`` itself — so
the scheme stays in one place.

Layout (all under :data:`HOME`):

    memory.db        SQLite store: facts / episodes / reflections + FTS5  (§2)
    events.db        SQLite activity ledger — what the agent did, when     (§8)
    tools.db         local cache of *installed* tools only                (§4)
    agent.toml       configurable identity layer (name, owner, preset)    (§3)
    identity.md      rendered identity overlay                            (§3)
    spine.md         frozen ethical spine — READ-ONLY at runtime          (§3)
    presets/         installed voice presets                             (§3/§4)
    installed.json   durable install index (durable _INSTALLED)           (§4)
    license.json     entitlement JWT (only file fetched over the network) (§4)
    version          plain-text version marker stamped at bootstrap       (§1)
    integrity-failure.txt  full detail of the last FAILED check     (§1)

Invariant: memory is 100% local. Nothing here phones home; ``bootstrap`` only
creates directories and empty seed files on the local filesystem.

``bootstrap`` is **idempotent and never clobbering**: re-running it leaves any
existing file untouched (so a user's ``agent.toml`` / DB survive a second
``yepgent init``). The actual schema/content of the DBs and TOML are owned by §2
and §3; here we only guarantee the directory tree and inert placeholders exist.
"""

from __future__ import annotations

from pathlib import Path

try:
    # platformdirs is a declared core dependency. We do not *use* a per-OS
    # config dir for the home — the product contract is a single, predictable
    # `~/.local-yep` on every platform — but importing it lazily-tolerantly
    # keeps `import local_yep.home` working even in a stripped environment.
    import platformdirs as _platformdirs  # noqa: F401
except Exception:  # pragma: no cover - platformdirs is a hard dep in practice
    _platformdirs = None


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------

#: The Local Yep home. Always ``<user-home>/.local-yep`` on every OS so the
#: location is predictable and documentable; we deliberately do NOT use a
#: platform-specific data dir. ``Path.home()`` is cross-platform (never a
#: hardcoded ``~``).
HOME: Path = Path.home() / ".local-yep"

#: SQLite memory store (§2). Created empty here; schema applied by §2.
MEMORY_DB: Path = HOME / "memory.db"

#: SQLite local tool catalog of installed tools only (§4).
TOOLS_DB: Path = HOME / "tools.db"

#: Configurable identity layer (§3) — name, owner, preset, voice dials.
AGENT_TOML: Path = HOME / "agent.toml"

#: Rendered identity overlay (§3).
IDENTITY_MD: Path = HOME / "identity.md"

#: Frozen ethical spine (§3). READ-ONLY at runtime.
SPINE_MD: Path = HOME / "spine.md"

#: Installed voice presets (§3/§4).
PRESETS_DIR: Path = HOME / "presets"

#: Durable on-disk install index (§4) — the persisted ``_INSTALLED``.
INSTALLED_JSON: Path = HOME / "installed.json"

#: Per-tool NON-SECRET config + secret-name registry (§6 / P5). Secret *values*
#: live in the OS keyring; this TOML file holds only plaintext config and the
#: names of stored secrets (see :mod:`local_yep.secrets`).
TOOL_CONFIG_TOML: Path = HOME / "tool_config.toml"

#: Entitlement JWT (§4). The only file ever delivered over the network.
LICENSE_JSON: Path = HOME / "license.json"

#: Ed25519 PUBLIC key (base64) used to verify the entitlement in
#: :data:`LICENSE_JSON`. Written by the installer so verification does not
#: depend on a shell-profile ``export`` surviving — a login shell that never
#: sources the profile (cron, systemd, an IDE terminal, ``~/.profile`` under
#: interactive bash) would otherwise leave a perfectly good token unverifiable.
#: PUBLIC key only: it can verify a token, never mint one.
ENTITLEMENT_PUBKEY: Path = HOME / "entitlement_pubkey"

#: Activity ledger (§8) — an append-only, prunable record of what the agent
#: did. Deliberately SEPARATE from ``memory.db``: activity is high-volume and
#: time-ordered, memory is curated and semantically recalled, and mixing them
#: would pollute the recall corpus. Nothing in :mod:`local_yep.memory` reads it.
EVENTS_DB: Path = HOME / "events.db"

#: Full detail from the most recent FAILED integrity check (§1). The tamper
#: banner is truncated to 8 lines and reaches a human only through the agent's
#: paraphrase, so the actionable detail was previously unrecoverable. Written on
#: failure only — deliberately NOT created by :func:`bootstrap`, so its presence
#: means something actually failed.
INTEGRITY_FAILURE: Path = HOME / "integrity-failure.txt"

#: Plain-text version marker stamped by :func:`bootstrap`.
VERSION: Path = HOME / "version"


def _package_version() -> str:
    """Best-effort current package version for the ``version`` marker."""
    try:
        from local_yep import __version__

        return str(__version__)
    except Exception:  # pragma: no cover - defensive
        return "0.0.0"


def _touch_dir(path: Path) -> bool:
    """Create ``path`` as a directory if absent. Return True if created."""
    if path.exists():
        return False
    path.mkdir(parents=True, exist_ok=True)
    return True


def _touch_empty_file(path: Path) -> bool:
    """Create ``path`` as an empty file if absent, never clobbering.

    Return True if the file was created. Existing files (including non-empty
    ones a user or another section has populated) are left byte-for-byte
    untouched.
    """
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive create: if a parallel process beat us to it, treat as
    # "already exists" rather than clobbering.
    try:
        with open(path, "x", encoding="utf-8"):
            pass
    except FileExistsError:
        return False
    return True


def bootstrap() -> Path:
    """Idempotently create the ``~/.local-yep/`` home and return its path.

    Creates the directory tree and inert placeholder files only. Safe to call
    repeatedly (e.g. on every ``yepgent init`` / hook invocation): anything that
    already exists is left untouched — a user's populated ``agent.toml`` or a
    real ``memory.db`` survives a re-run intact.

    The empty ``.db`` placeholders are valid: an empty file is a legal empty
    SQLite database, so §2 can open and apply its schema on first use. The
    ``version`` marker is (re)written only when missing, never overwritten —
    ``yepgent upgrade`` owns version stamping.

    No network access. No clobbering. Returns :data:`HOME`.
    """
    _touch_dir(HOME)
    _touch_dir(PRESETS_DIR)

    # Inert placeholder files. Real content is owned by §2 (DB schema) and §3
    # (agent.toml / identity.md / spine.md). We only guarantee existence.
    for f in (
        MEMORY_DB,
        TOOLS_DB,
        AGENT_TOML,
        INSTALLED_JSON,
    ):
        _touch_empty_file(f)

    # Stamp the version marker only if absent (never clobber an existing one).
    if not VERSION.exists():
        VERSION.write_text(_package_version() + "\n", encoding="utf-8")

    return HOME
