"""System-integrity verification — tamper-evident, fail-closed (product guard).

Local Yep is a product: the frozen ethical spine, the operative behaviors, the
tool recipes, and the authored preset voices define *what the agent is*. This
module verifies, at every launch and every session start, that those bundled
"system" files have not been modified, and refuses to operate if they have.

Trust model (stated honestly — see also PLAN R2 / Rule 1):

* The check is **tamper-evident and fail-closed**, NOT tamper-proof. It runs on
  the user's own machine, so a determined user with code access can ultimately
  patch the verifier out — the universal client-side limit.
* What it stops cleanly: casual/accidental edits, and "just edit a system file
  to change the rules / re-hash the manifest." The manifest is **signed**
  (Ed25519); forging it requires the private key, which never ships. The trust
  root — the public key — is embedded in *code* here (:data:`PUBKEY_HEX`), so
  swapping it is itself a code patch, not a data edit.

How it works: a signed ``_integrity/manifest.json`` maps each protected file to
its SHA-256. At runtime we (1) verify the manifest's signature against the
embedded public key (dependency-free :mod:`local_yep._ed25519`), then (2) hash
each listed file and compare. Any failure ⇒ not intact. The launcher refuses to
start and the SessionStart hook withholds identity and shows a restart notice.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
import time
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import NamedTuple, Optional

from local_yep import _ed25519

#: Trust root: the hex Ed25519 PUBLIC key the release manifest is signed under.
#: Embedded in code on purpose — replacing it is a code patch (the accepted
#: client-side limit), not a mere data edit. Set by ``integrity_tool.py keygen``.
PUBKEY_HEX: str = "bda40c0f990f177514cc063bfba74c9eb4915d1f5067c5c5cf94cc8e9a1623d5"

INTEGRITY_DIRNAME = "_integrity"
MANIFEST_NAME = "manifest.json"
SIG_NAME = "manifest.sig"
MANIFEST_VERSION = "1"

#: Fixed protected files (package-relative, POSIX). Presets are discovered
#: dynamically below so adding a preset only requires a re-sign.
_FIXED_PROTECTED = (
    "identity/spine.md",
    "templates/behaviors.md",
    "templates/tool_recipes.md",
)


class IntegrityResult(NamedTuple):
    ok: bool
    failures: tuple[str, ...]


class IntegrityError(RuntimeError):
    """Raised by :func:`assert_intact` when the system files are not intact."""


def package_root() -> Path:
    """Absolute path to the installed ``local_yep`` package directory."""
    return Path(__file__).resolve().parent


def protected_files(root: Optional[Path] = None) -> list[str]:
    """The package-relative POSIX paths the manifest covers (sorted, unique).

    Used by the signing tool to BUILD the manifest. Runtime verification trusts
    the (signed) manifest's own file list, not this enumeration.
    """
    root = root or package_root()
    rels: set[str] = set()
    for rel in _FIXED_PROTECTED:
        if (root / rel).is_file():
            rels.add(rel)
    presets = root / "presets"
    if presets.is_dir():
        # Cover the full authored surface of every bundled preset: the .toml
        # configs AND the voice/sample prose that is injected into identity
        # verbatim (an unsigned voice.md would be the easy identity swap).
        for pattern in ("*.toml", "voice.md", "sample.txt"):
            for f in presets.rglob(pattern):
                if f.is_file():
                    rels.add(f.relative_to(root).as_posix())
    return sorted(rels)


def _sha256_file(path: Path) -> str:
    # Hash newline-normalized bytes so the check is stable across line-ending
    # conversion (git autocrlf, cross-OS checkouts, wheel builds). Every
    # protected file is text; a pure CRLF/LF change is not meaningful tampering.
    data = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    return hashlib.sha256(data).hexdigest()


def build_manifest(root: Optional[Path] = None) -> bytes:
    """Serialize the canonical manifest bytes (what gets signed and verified)."""
    root = root or package_root()
    files = {rel: _sha256_file(root / rel) for rel in protected_files(root)}
    doc = {"version": MANIFEST_VERSION, "algo": "sha256", "files": files}
    return (json.dumps(doc, indent=2, sort_keys=True) + "\n").encode("utf-8")


#: Cap on how many files an *unsigned* manifest may claim before we stop
#: comparing. A real release manifest lists ~30; anything vastly larger is a
#: malformed or hostile file, not something to spend a session-start on.
_UNSIGNED_MAX_FILES = 512

#: Characters allowed through into a user-facing failure line. Manifest keys are
#: attacker-controlled once the signature has failed, and the tamper banner is
#: read by a human *and* injected into the agent's context — so control codes,
#: ANSI escapes and newlines are stripped rather than forwarded.
_DISPLAY_SAFE = re.compile(r"[^A-Za-z0-9._/\- ]")


def _display(rel: object, limit: int = 120) -> str:
    """Render a manifest-supplied path safely for a banner line."""
    out = _DISPLAY_SAFE.sub("?", str(rel))
    return out if len(out) <= limit else out[:limit] + "..."


def _clean_line(value: object, limit: int = 100) -> str:
    """Strip control characters from a locally-sourced string for display."""
    out = "".join(c if c.isprintable() else "?" for c in str(value))
    return out if len(out) <= limit else out[:limit] + "..."


def _safe_rel(rel: object) -> bool:
    """True if ``rel`` is a plain package-relative POSIX path.

    Guards the file loop against a manifest pointing outside the package
    (``../``, an absolute path, a Windows drive). The signed path never needs
    this; the unsigned advisory path reads attacker-controlled keys, and the
    check is free, so both get it.
    """
    if not isinstance(rel, str) or not rel:
        return False
    if rel.startswith(("/", "\\")) or ":" in rel or "\\" in rel:
        return False
    if any(not c.isprintable() for c in rel):
        return False
    return not any(part in ("..", "") for part in rel.split("/"))


def _manifest_files(manifest_bytes: bytes) -> dict:
    """Parse and shape-check the manifest's ``files`` mapping."""
    files = json.loads(manifest_bytes)["files"]
    if not isinstance(files, dict):
        raise ValueError("manifest 'files' is not an object")
    return files


def _compare_files(root: Path, files: dict) -> list[str]:
    """Hash every listed file; one failure line per discrepancy."""
    failures: list[str] = []
    for rel, expected in sorted(files.items(), key=lambda kv: str(kv[0])):
        if not _safe_rel(rel):
            failures.append(f"invalid path in manifest: {_display(rel)}")
            continue
        fp = root / rel
        shown = _display(rel)
        if not fp.is_file():
            failures.append(f"missing: {shown}")
            continue
        try:
            if _sha256_file(fp) != expected:
                failures.append(f"modified: {shown}")
        except OSError as exc:
            failures.append(f"unreadable: {shown} ({_clean_line(exc, 60)})")
    return failures


def _unsigned_manifest_detail(root: Path, manifest_bytes: bytes) -> list[str]:
    """Advisory per-file detail for a manifest whose signature did NOT verify.

    The signature is the trust boundary: once it fails, nothing in the manifest
    is evidence of anything. We report the comparison anyway, because it splits
    two situations that otherwise produce an identical, silent banner:

    * **some files differ** — a stale manifest, a partial download, or a sync
      tool that rewrote a file; manifest and payload simply disagree.
    * **every file matches** — the manifest was REGENERATED to match files that
      were edited. That is what tampering looks like when whoever edited them
      could re-hash (:func:`build_manifest` needs no key) but could not re-sign.
      Reporting only "signature invalid" hides precisely this case, because the
      loop that would name the edited file never runs.

    Every line is prefixed ``(unverified)``: a lead for a human, never a
    verdict, and never to be mistaken for signed evidence.
    """
    try:
        files = _manifest_files(manifest_bytes)
    except Exception:  # noqa: BLE001 - any parse failure is itself the signal
        return ["(unverified) manifest is not readable JSON — truncated or corrupt"]
    if not files:
        return ["(unverified) manifest lists no files"]
    if len(files) > _UNSIGNED_MAX_FILES:
        return [
            f"(unverified) manifest lists {len(files)} files — implausible, not compared"
        ]
    diffs = _compare_files(root, files)
    if not diffs:
        return [
            f"(unverified) all {len(files)} files listed match this manifest — "
            "consistent with a manifest regenerated after the files were edited",
        ]
    shown = [f"(unverified) {d}" for d in diffs[:5]]
    if len(diffs) > 5:
        shown.append(f"(unverified) ...and {len(diffs) - 5} more")
    return shown


def _verify_once(
    root: Optional[Path] = None,
    *,
    manifest_bytes: Optional[bytes] = None,
    sig_hex: Optional[str] = None,
    pubkey_hex: Optional[str] = None,
) -> IntegrityResult:
    """One full pass over the manifest and the files it covers. Never raises.

    Returns ``IntegrityResult(ok, failures)``. ``ok`` is True only when the
    manifest signature verifies AND every listed file is present and unchanged.
    Callers want :func:`verify`, which confirms a failing pass with a second
    read before reporting it. The keyword args are seams for tests; production
    reads the bundled files.
    """
    root = root or package_root()
    idir = root / INTEGRITY_DIRNAME

    if manifest_bytes is None:
        mp = idir / MANIFEST_NAME
        if not mp.is_file():
            return IntegrityResult(False, ("integrity manifest missing",))
        try:
            manifest_bytes = mp.read_bytes()
        except OSError as exc:
            return IntegrityResult(False, (f"manifest unreadable: {exc}",))

    if sig_hex is None:
        sp = idir / SIG_NAME
        if not sp.is_file():
            return IntegrityResult(False, ("integrity signature missing",))
        try:
            sig_hex = sp.read_text(encoding="utf-8").strip()
        except OSError as exc:
            return IntegrityResult(False, (f"signature unreadable: {exc}",))

    pk_hex = pubkey_hex if pubkey_hex is not None else PUBKEY_HEX
    try:
        pubkey = bytes.fromhex(pk_hex)
        sig = bytes.fromhex(sig_hex)
    except ValueError:
        return IntegrityResult(False, ("integrity key/signature malformed",))

    if not _ed25519.verify(pubkey, manifest_bytes, sig):
        # Do NOT return here without the per-file comparison. The signature is
        # the trust boundary, so the result stays not-ok either way — but a bare
        # "signature invalid" is the one failure shape that never names the file
        # that changed, which is exactly the shape a re-hashed tamper produces.
        failures = ["manifest signature invalid (forged, corrupted, or unsigned build)"]
        failures.extend(_unsigned_manifest_detail(root, manifest_bytes))
        return IntegrityResult(False, tuple(failures))

    try:
        files = _manifest_files(manifest_bytes)
    except Exception as exc:  # noqa: BLE001
        return IntegrityResult(False, (f"manifest unreadable: {exc}",))

    failures = _compare_files(root, files)
    return IntegrityResult(not failures, tuple(failures))


#: Pause between a failed pass and the confirming re-read. Long enough for a
#: stalled I/O path to settle, short enough that a real tamper still stops the
#: session immediately. Only ever paid on the failure path.
RECHECK_DELAY_S = 0.25


def verify(
    root: Optional[Path] = None,
    *,
    manifest_bytes: Optional[bytes] = None,
    sig_hex: Optional[str] = None,
    pubkey_hex: Optional[str] = None,
) -> IntegrityResult:
    """Verify the signed manifest and every file it covers. Never raises.

    A failure is **confirmed by a second, independent read** before it is
    reported. The verifier is deterministic — vendored Ed25519, SHA-256 over
    bytes — so it cannot fail on correct data. A single failing pass therefore
    means the data is wrong *or the read was*, and until now those two produced
    the same fail-closed session. A tester hit the second one on 2026-08-24: the
    check failed on a box whose 27 protected files were byte-perfect before and
    after, inside a window with logged local I/O instability.

    Re-reading costs nothing in security. Tampering is a property of the bytes on
    disk, so a modified file fails both passes; the second read can only forgive
    a discrepancy that has already stopped existing. It costs nothing in the
    happy path either — a passing check never reaches the retry.

    Returns the ``IntegrityResult`` of whichever pass decided.
    """
    root = root or package_root()
    first = _verify_once(
        root, manifest_bytes=manifest_bytes, sig_hex=sig_hex, pubkey_hex=pubkey_hex
    )
    if first.ok:
        return first

    time.sleep(RECHECK_DELAY_S)
    second = _verify_once(
        root, manifest_bytes=manifest_bytes, sig_hex=sig_hex, pubkey_hex=pubkey_hex
    )
    if second.ok:
        transient_report(first.failures)
    return second


def transient_report(failures: tuple[str, ...]) -> Optional[Path]:
    """Append a recovered-on-re-read event to ``integrity-transient.log``.

    Deliberately NOT ``integrity-failure.txt``: the existence of that file means
    "this install is broken", and a check that passed on re-read is not that.
    This log appends rather than overwrites, because one line is noise and a
    column of them is a disk going bad — which is worth a user seeing.

    Best-effort by design: the guard must never fail because a log could not be
    written, so errors are swallowed and ``None`` is returned.
    """
    try:
        from local_yep import __version__, home

        path = home.INTEGRITY_FAILURE.with_name("integrity-transient.log")
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        detail = "; ".join(failures) or "(unspecified)"
        line = (
            f"{stamp}\tv{__version__}\tpy{sys.version.split()[0]}\t"
            f"{_clean_line(detail, 400)}\n"
        )
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(line)
        return path
    except Exception:  # noqa: BLE001 - never let logging break the gate
        return None


@lru_cache(maxsize=1)
def check() -> IntegrityResult:
    """Process-cached verification of the installed package (fail-closed).

    Any internal error is converted to a not-intact result rather than raised,
    so callers (hook, launcher) get a clean verdict. Cached per process; each
    hook/launcher invocation is a fresh process.
    """
    try:
        return verify()
    except Exception as exc:  # noqa: BLE001 - never let the guard itself throw
        return IntegrityResult(False, (f"integrity check error: {exc}",))


def assert_intact() -> None:
    """Raise :class:`IntegrityError` (with the tamper message) if not intact."""
    result = check()
    if not result.ok:
        raise IntegrityError(tamper_message(result))


def _pipx_source() -> Optional[str]:
    """What pipx recorded as this install's source, if pipx manages this copy.

    ``package_or_url`` is a plain name for a PyPI install and a filesystem path
    or URL for a hosted wheel. That distinction is the whole point: it decides
    whether ``pipx reinstall`` is a real remediation or a dead end.
    """
    try:
        for parent in package_root().parents:
            meta = parent / "pipx_metadata.json"
            if meta.is_file():
                doc = json.loads(meta.read_text(encoding="utf-8"))
                src = (doc.get("main_package") or {}).get("package_or_url")
                return str(src) if src else None
    except Exception:  # noqa: BLE001 - advisory only, never fatal
        return None
    return None


def _from_pypi(src: Optional[str]) -> bool:
    """True only if pipx resolved this install from a plain PyPI name."""
    if not src:
        return False
    s = src.strip()
    if s.lower().endswith((".whl", ".tar.gz", ".zip")):
        return False
    return "/" not in s and "\\" not in s


def _restore_lines() -> str:
    """Remediation matched to how this copy was actually installed.

    A hosted-wheel install is recorded by pipx from the (usually temporary) path
    it was installed from, so ``pipx reinstall`` cannot resolve it. Printing that
    command anyway sends the one user who most needs help down a dead end.
    """
    src = _pipx_source()
    if _from_pypi(src):
        return (
            "To restore and re-enable, then restart your session:\n"
            "    pipx reinstall local-yep\n"
            "    (or: pip install --force-reinstall --no-deps local-yep)"
        )
    if src:
        return (
            "To restore and re-enable, RE-RUN THE INSTALLER you used\n"
            "(install.sh / install.ps1, or your hosted install command),\n"
            "then restart your session.\n"
            "    `pipx reinstall` will NOT work for this copy: it did not come\n"
            "    from PyPI, and the source pipx recorded may no longer exist:\n"
            f"      {_clean_line(src)}"
        )
    return (
        "To restore and re-enable, then restart your session:\n"
        "  - installed from PyPI?  pipx reinstall local-yep\n"
        "  - installed via install.sh / install.ps1 or a hosted wheel?\n"
        "    re-run that installer — `pipx reinstall` will not find it."
    )


def failure_report(result: IntegrityResult) -> Optional[Path]:
    """Write COMPLETE failure detail to ``~/.local-yep/integrity-failure.txt``.

    The banner truncates to 8 lines and reaches a human only through the agent's
    paraphrase; this file is the untruncated, machine-written record to read
    directly or attach to a bug report. Best-effort by design — the guard must
    never fail because a log could not be written, so errors are swallowed and
    ``None`` is returned.
    """
    try:
        from local_yep import __version__, home

        src = _pipx_source()
        stamp = datetime.now().astimezone().isoformat(timespec="seconds")
        unknown = "(not pipx-managed, or unrecorded)"
        lines = [
            "Local Yep — integrity check FAILED",
            f"  when     : {stamp}",
            f"  version  : {__version__}",
            f"  python   : {sys.version.split()[0]} ({sys.platform})",
            f"  package  : {package_root()}",
            f"  pipx src : {_clean_line(src) if src else unknown}",
            "",
            f"Failures ({len(result.failures)}):",
        ]
        lines += [f"  - {f}" for f in result.failures] or ["  - (unspecified)"]
        lines += [
            "",
            "Lines marked (unverified) come from a manifest whose signature did",
            "NOT verify. They are a lead, not evidence — an unsigned manifest can",
            "claim anything. In particular, if every listed file 'matches', read",
            "that as a sign the manifest was regenerated, NOT as an all-clear.",
            "",
        ]
        path = home.INTEGRITY_FAILURE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines), encoding="utf-8")
        return path
    except Exception:  # noqa: BLE001 - never let logging break the gate
        return None


def tamper_message(
    result: IntegrityResult, *, report_path: Optional[Path] = None
) -> str:
    """The loud, user-facing 'disabled — restore & restart' notice."""
    shown = list(result.failures[:8])
    detail = "\n".join(f"    - {f}" for f in shown) or "    - (unspecified)"
    more = (
        "" if len(result.failures) <= 8
        else f"\n    …and {len(result.failures) - 8} more"
    )
    report = (
        f"\nFull detail written to:\n    {report_path}\n" if report_path else ""
    )
    return (
        "============ LOCAL YEP — INTEGRITY CHECK FAILED ============\n"
        "Protected system files have been modified or are missing, so\n"
        "Local Yep is DISABLED to protect product integrity.\n\n"
        f"Detected:\n{detail}{more}\n"
        f"{report}\n"
        f"{_restore_lines()}\n\n"
        "If you changed these files intentionally, re-sign the manifest with\n"
        "your release key (scripts/integrity_tool.py sign) — silent edits to\n"
        "the system are not permitted.\n"
        "==========================================================="
    )
