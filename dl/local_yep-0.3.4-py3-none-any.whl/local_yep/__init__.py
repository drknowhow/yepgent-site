"""Local Yep — a Claude-Code-native, local-first agent framework.

A named, personable agent with a persistent recall->reflect memory loop,
installed into the user's own Claude Code (the way C3 is). Memory is stored
100% locally (SQLite at ``~/.local-yep/memory.db``); nothing in the package's
core paths touches the network.

This top-level module is intentionally light: importing ``local_yep`` must not
pull in heavy or optional dependencies (numpy, the memory backend, the MCP
SDK). Submodules import what they need lazily so that, e.g., ``yepgent --help``
runs before the memory or MCP layers exist.
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.3.4"
